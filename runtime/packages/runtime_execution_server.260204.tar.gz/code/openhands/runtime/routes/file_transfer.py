import os
import shutil
import tempfile
import time
from collections.abc import Callable
from typing import Optional
from zipfile import ZipFile

from fastapi import APIRouter, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from starlette.background import BackgroundTask

from openhands.core.logger import openhands_logger as logger
from openhands.runtime.action_execution.executor.executor import ActionExecutor


def create_file_transfer_router(
    get_client: Callable[[], Optional[ActionExecutor]],
) -> APIRouter:
    """Create a router for upload/download endpoints.

    These endpoints are used to move files in/out of the sandbox runtime.
    """

    router = APIRouter()

    @router.post('/upload_file')
    async def upload_file(
        file: UploadFile, destination: str = '/', recursive: bool = False
    ):
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')

        # Treat file uploads as runtime activity. Large uploads can take long
        # enough that the idle timer may expire mid-transfer if we don't refresh
        # activity while streaming bytes.
        client.start_idle_timer()
        client.last_execution_time = time.time()

        def _copyfileobj_with_activity(
            src,
            dst,
            chunk_size: int = 8 * 1024 * 1024,
            refresh_every_s: float = 5.0,
        ) -> None:
            # Throttle refresh so we don't spam start_idle_timer on fast disks.
            next_refresh = time.monotonic() + refresh_every_s
            while True:
                chunk = src.read(chunk_size)
                if not chunk:
                    break
                dst.write(chunk)

                now = time.monotonic()
                if now >= next_refresh:
                    # Treat upload streaming as runtime activity by periodically
                    # refreshing the client's idle timer while bytes are uploaded.
                    client.last_execution_time = time.time()
                    client.start_idle_timer()
                    next_refresh = now + refresh_every_s

        try:
            if not os.path.isabs(destination):
                raise HTTPException(
                    status_code=400, detail='Destination must be an absolute path'
                )

            # Ensure the destination directory exists
            full_dest_path = destination
            if not os.path.exists(full_dest_path):
                os.makedirs(full_dest_path, exist_ok=True)

            # Sanitize filename to prevent path traversal attacks
            safe_filename = os.path.basename(file.filename or '')
            if not safe_filename:
                raise HTTPException(
                    status_code=400, detail='Invalid filename'
                )

            # For recursive uploads, we expect a zip file
            if recursive or safe_filename.endswith('.zip'):
                if not safe_filename.endswith('.zip'):
                    raise HTTPException(
                        status_code=400, detail='Recursive uploads must be zip files'
                    )

                zip_path = os.path.join(full_dest_path, safe_filename)
                with open(zip_path, 'wb') as buffer:
                    _copyfileobj_with_activity(file.file, buffer)

                # Extract the zip file
                shutil.unpack_archive(zip_path, full_dest_path)
                # Remove the zip file after extraction
                os.remove(zip_path)
                logger.debug(
                    'Uploaded file %s and extracted to %s', safe_filename, destination
                )
            else:
                # For single file uploads
                file_path = os.path.join(full_dest_path, safe_filename)
                with open(file_path, 'wb') as buffer:
                    _copyfileobj_with_activity(file.file, buffer)
                logger.debug('Uploaded file %s to %s', safe_filename, destination)

            return JSONResponse(
                content={
                    'filename': safe_filename,
                    'destination': destination,
                    'recursive': recursive,
                },
                status_code=200,
            )
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @router.post('/write_file_stream')
    async def write_file_stream(
        request: Request, destination: str = '/', filename: str = 'upload.bin'
    ):
        """Stream a raw request body directly into a file on disk.

        This endpoint intentionally accepts a raw byte stream instead of multipart/form-data.
        That avoids multipart parsing/encoding overhead and allows an upstream proxy (e.g.,
        OAIS) to pipe bytes directly from external storage (such as S3) into the runtime
        without buffering the entire payload in memory.
        """
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')

        client.start_idle_timer()
        client.last_execution_time = time.time()

        if not os.path.isabs(destination):
            raise HTTPException(
                status_code=400, detail='Destination must be an absolute path'
            )

        safe_name = os.path.basename(filename) or 'upload.bin'
        full_dest_path = destination
        os.makedirs(full_dest_path, exist_ok=True)
        file_path = os.path.join(full_dest_path, safe_name)

        refresh_every_s = 5.0
        next_refresh = time.monotonic() + refresh_every_s

        try:
            with open(file_path, 'wb') as out:
                async for chunk in request.stream():
                    if not chunk:
                        continue
                    out.write(chunk)

                    now = time.monotonic()
                    if now >= next_refresh:
                        # Treat upload streaming as runtime activity by periodically
                        # refreshing the client's idle timer while bytes are uploaded.
                        client.last_execution_time = time.time()
                        client.start_idle_timer()
                        next_refresh = now + refresh_every_s

            logger.debug('write_file_stream: wrote %s to %s', safe_name, destination)
            return JSONResponse(
                content={'filename': safe_name, 'destination': destination},
                status_code=200,
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @router.get('/download_files')
    def download_file(path: str):
        # This endpoint preserves the existing behavior:
        # - It only accepts absolute filesystem paths.
        # - It creates and returns a ZIP archive of the target path (recursively for
        #   directories), even when the target is a single file.
        logger.debug('Downloading files')
        try:
            if not os.path.isabs(path):
                raise HTTPException(status_code=400, detail='Path must be an absolute path')

            if not os.path.exists(path):
                raise HTTPException(status_code=404, detail='File not found')

            with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as temp_zip:
                with ZipFile(temp_zip, 'w') as zipf:
                    if os.path.isfile(path):
                        # If path is a single file, add just that file to the zip.
                        zipf.write(path, arcname=os.path.basename(path))
                    else:
                        # If path is a directory, walk it and add all contained files.
                        for root, _, files in os.walk(path):
                            for file in files:
                                file_path = os.path.join(root, file)
                                zipf.write(
                                    file_path, arcname=os.path.relpath(file_path, path)
                                )

                return FileResponse(
                    path=temp_zip.name,
                    media_type='application/zip',
                    filename=f'{os.path.basename(path)}.zip',
                    background=BackgroundTask(lambda: os.unlink(temp_zip.name)),
                )
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    return router
