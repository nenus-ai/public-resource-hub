from __future__ import annotations

import os
import sys
from collections.abc import Callable
from typing import Optional, Any

from fastapi import APIRouter

from openhands import __version__
from openhands.runtime.action_execution.executor.executor import ActionExecutor
from openhands.shared.runtime_capabilities import (
    CAPABILITIES_PROTOCOL_VERSION,
    CORE_CAPABILITIES,
    KNOWN_CAPABILITIES,
    CAP_FILE_MANAGER_V1,
    CAP_FILE_TRANSFER_V1,
    CAP_LIST_FILES_V1,
    CAP_WORKSPACE_STATUS_V1,
    CAP_WORKSPACE_MODE_V1,
    CAP_IDLE_LIFE_V1,
    CAP_VSCODE_V1,
    CAP_MCP_UPDATE_V1,
)


def create_capabilities_router(
    get_client: Callable[[], Optional[ActionExecutor]],
) -> APIRouter:
    """Create a router that exposes feature/capability negotiation.

    This endpoint is intended for OpenHands backend to probe and gate UI features.
    """

    router = APIRouter()

    @router.get('/capabilities')
    async def capabilities() -> dict[str, Any]:
        # Client can be None early in startup; still return the static capabilities.
        _ = get_client()

        capabilities_map: dict[str, bool] = {k: False for k in KNOWN_CAPABILITIES}
        for k in CORE_CAPABILITIES:
            capabilities_map[k] = True

        # This runtime version includes these routers.
        capabilities_map[CAP_LIST_FILES_V1] = True
        capabilities_map[CAP_FILE_MANAGER_V1] = True
        capabilities_map[CAP_FILE_TRANSFER_V1] = True
        capabilities_map[CAP_WORKSPACE_STATUS_V1] = True
        capabilities_map[CAP_WORKSPACE_MODE_V1] = True
        capabilities_map[CAP_IDLE_LIFE_V1] = True
        capabilities_map[CAP_VSCODE_V1] = True

        # MCP update is only meaningful on non-Windows (MCP is disabled on Windows).
        capabilities_map[CAP_MCP_UPDATE_V1] = sys.platform != 'win32'

        build = {
            'version': __version__,
            'commit': os.getenv('OPENHANDS_BUILD_COMMIT')
            or os.getenv('GIT_COMMIT')
            or os.getenv('GIT_SHA'),
        }

        return {
            'protocol_version': CAPABILITIES_PROTOCOL_VERSION,
            'core_capabilities': sorted(CORE_CAPABILITIES),
            'capabilities': capabilities_map,
            'build': build,
        }

    return router
