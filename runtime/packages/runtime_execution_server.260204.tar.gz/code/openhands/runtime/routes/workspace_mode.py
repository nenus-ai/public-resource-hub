from collections.abc import Awaitable, Callable
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from openhands.core.logger import openhands_logger as logger
from openhands.shared.workspace_state import WorkspaceStateName


class WorkspaceModeRequest(BaseModel):
    state: WorkspaceStateName
    reason: str | None = None


def create_workspace_mode_router(
    *,
    set_override: Callable[[WorkspaceStateName, str | None], Awaitable[None]],
    clear_override: Callable[[], Awaitable[None]],
    get_workspace_state_payload: Callable[[], Awaitable[dict[str, Any]]],
) -> APIRouter:
    """Create a router for workspace mode override endpoints.

    The runtime server uses this to temporarily override the workspace state
    returned by `/workspace_state` and to gate new commands.
    """

    router = APIRouter()

    @router.post('/workspace_mode')
    async def set_workspace_mode(req: WorkspaceModeRequest):
        logger.info(
            'set_workspace_mode: setting override (state=%s, reason=%s)',
            req.state,
            req.reason,
        )
        await set_override(req.state, req.reason)
        return await get_workspace_state_payload()

    @router.delete('/workspace_mode')
    async def clear_workspace_mode():
        await clear_override()
        return await get_workspace_state_payload()

    return router
