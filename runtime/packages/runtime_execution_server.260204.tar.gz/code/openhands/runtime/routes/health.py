import time
from collections.abc import Callable
from typing import Optional

from fastapi import APIRouter

from openhands.core.logger import openhands_logger as logger
from openhands.runtime.action_execution.executor.executor import ActionExecutor
from openhands.runtime.utils.system_stats import get_system_stats


def create_health_router(
    get_client: Callable[[], Optional[ActionExecutor]],
) -> APIRouter:
    """Create a router that exposes health + runtime info endpoints.

    This is used by the sandbox runtime server (action_execution_server.py).
    """

    router = APIRouter()

    @router.get('/server_info')
    async def get_server_info():
        client = get_client()
        assert client is not None

        current_time = time.time()
        uptime = current_time - client.start_time
        idle_time = current_time - client.last_execution_time

        response = {
            'uptime': uptime,
            'idle_time': idle_time,
            'idle_life': client.idle_life,
            'resources': get_system_stats(),
        }
        logger.info('Server info endpoint response: %s', response)
        return response

    @router.get('/alive')
    async def alive():
        client = get_client()
        if client is None or not client.initialized:
            return {'status': 'not initialized'}
        return {'status': 'ok'}

    return router
