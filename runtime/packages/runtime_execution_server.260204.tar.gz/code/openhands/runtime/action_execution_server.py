"""
This is the main file for the runtime client.
It is responsible for executing actions received from OpenHands backend and producing observations.

NOTE: this will be executed inside the docker sandbox.
"""

import argparse
import asyncio
import logging
import os
import sys
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from mcpm import MCPRouter, RouterConfig
from mcpm.router.router import logger as mcp_router_logger
from pydantic import BaseModel
from starlette.exceptions import HTTPException as StarletteHTTPException
from uvicorn import run

from openhands.core.logger import openhands_logger as logger
from openhands.runtime.action_execution.auth import SESSION_API_KEY, verify_api_key
from openhands.runtime.action_execution.executor.executor import ActionExecutor
from openhands.runtime.action_execution.monitoring.registry import (
    get_running_registry,
)
from openhands.runtime.action_execution.services.async_tasks import (
    AsyncActionService,
    get_async_runners,
    get_task_store,
)
from openhands.runtime.file_viewer_server import start_file_viewer_server
from openhands.runtime.plugins import ALL_PLUGINS, Plugin
from openhands.runtime.routes.async_actions import create_async_actions_router
from openhands.runtime.routes.capabilities import create_capabilities_router
from openhands.runtime.routes.file_manager import create_file_manager_router
from openhands.runtime.routes.file_transfer import create_file_transfer_router
from openhands.runtime.routes.health import create_health_router
from openhands.runtime.routes.idle_life import create_idle_life_router
from openhands.runtime.routes.list_files import create_list_files_router
from openhands.runtime.routes.mcp_update import create_mcp_update_router
from openhands.runtime.routes.vscode import create_vscode_router
from openhands.runtime.routes.workspace_mode import create_workspace_mode_router
from openhands.runtime.routes.workspace_status import create_workspace_status_router
from openhands.runtime.utils import find_available_tcp_port
from openhands.shared.runtime_constants import DEFAULT_MAX_SLOTS
from openhands.shared.workspace_state import WorkspaceStateName

# Set MCP router logger to the same level as the main logger
mcp_router_logger.setLevel(logger.getEffectiveLevel())

# Stop escalation delays (seconds). Configurable via env for tuning UX vs. reliability.
STOP_CTRL_C_DELAY_SECONDS = float(os.environ.get('STOP_CTRL_C_DELAY_SECONDS', '0.7'))
STOP_SIGQUIT_DELAY_SECONDS = float(os.environ.get('STOP_SIGQUIT_DELAY_SECONDS', '0.7'))
STOP_SIGTERM_DELAY_SECONDS = float(os.environ.get('STOP_SIGTERM_DELAY_SECONDS', '1.2'))
STOP_SIGKILL_DELAY_SECONDS = float(os.environ.get('STOP_SIGKILL_DELAY_SECONDS', '0.5'))

if sys.platform == 'win32':
    pass


class WorkspaceModeOverride(BaseModel):
    state: WorkspaceStateName | None = None
    reason: str | None = None


_WORKSPACE_MODE_OVERRIDE = WorkspaceModeOverride()
_WORKSPACE_MODE_OVERRIDE_LOCK = asyncio.Lock()

ASYNC_TASK_TTL_SECONDS = int(os.environ.get('ASYNC_TASK_TTL_SECONDS', '60'))
# Safety valve for leaked async tasks that never reach a terminal state.
# If a task stays non-terminal longer than this, we will best-effort cancel
# its runner and evict it from the in-memory task store to prevent unbounded
# memory growth.
ASYNC_TASK_MAX_AGE_SECONDS = int(os.environ.get('ASYNC_TASK_MAX_AGE_SECONDS', '3600'))
_TASK_STORE = get_task_store()


# Tracks the asyncio Task running the async action for cancellation purposes.
_ASYNC_RUNNERS = get_async_runners()


_RUNNING_REGISTRY = get_running_registry()

_ASYNC_ACTION_SERVICE = AsyncActionService(
    _TASK_STORE,
    _ASYNC_RUNNERS,
    _RUNNING_REGISTRY,
    ttl_seconds=ASYNC_TASK_TTL_SECONDS,
)

ROOT_GID = 0


if __name__ == '__main__':
    logger.warning('Starting Action Execution Server')

    parser = argparse.ArgumentParser()
    parser.add_argument('port', type=int, help='Port to listen on')
    parser.add_argument('--working-dir', type=str, help='Working directory')
    parser.add_argument('--plugins', type=str, help='Plugins to initialize', nargs='+')
    parser.add_argument(
        '--username', type=str, help='User to run as', default='openhands'
    )
    parser.add_argument('--user-id', type=int, help='User ID to run as', default=1000)
    parser.add_argument(
        '--browsergym-eval-env',
        type=str,
        help='BrowserGym environment used for browser evaluation',
        default=None,
    )

    # example: python client.py 8000 --working-dir /workspace --plugins JupyterRequirement
    args = parser.parse_args()

    # Start the file viewer server in a separate thread
    logger.info('Starting file viewer server')
    _file_viewer_port = find_available_tcp_port(
        min_port=args.port + 1, max_port=min(args.port + 1024, 65535)
    )
    server_url, _ = start_file_viewer_server(port=_file_viewer_port)
    logger.info(f'File viewer server started at {server_url}')

    plugins_to_load: list[Plugin] = []
    if args.plugins:
        for plugin in args.plugins:
            if plugin not in ALL_PLUGINS:
                raise ValueError(f'Plugin {plugin} not found')
            # vscode is loaded in background via _init_vscode_async(), not here
            if plugin != 'vscode':
                plugins_to_load.append(ALL_PLUGINS[plugin]())  # type: ignore

    client: ActionExecutor | None = None
    mcp_router: MCPRouter | None = None
    MCP_ROUTER_PROFILE_PATH = os.path.join(
        os.path.dirname(__file__), 'mcp', 'config.json'
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        global client, mcp_router
        logger.info('Initializing ActionExecutor...')
        idle_life = int(
            os.environ.get('SANDBOX_IDLE_LIFE', '90000')  # 25 hours in seconds
        )
        client = ActionExecutor(
            plugins_to_load,
            work_dir=args.working_dir,
            username=args.username,
            user_id=args.user_id,
            browsergym_eval_env=args.browsergym_eval_env,
            idle_life=idle_life,
        )
        await client.ainit()
        logger.info('ActionExecutor initialized.')

        # Start idle timer if idle_life is set
        if idle_life and idle_life > 0:
            client.start_idle_timer()
            logger.info(f'Started idle timer with delay={idle_life}s')

        # Check if we're on Windows
        is_windows = sys.platform == 'win32'

        # Initialize and mount MCP Router (skip on Windows)
        if is_windows:
            logger.info('Skipping MCP Router initialization on Windows')
            mcp_router = None
        else:
            logger.info('Initializing MCP Router...')
            mcp_router = MCPRouter(
                profile_path=MCP_ROUTER_PROFILE_PATH,
                router_config=RouterConfig(
                    api_key=SESSION_API_KEY,
                    auth_enabled=bool(SESSION_API_KEY),
                ),
            )
            allowed_origins = ['*']
            sse_app = await mcp_router.get_sse_server_app(
                allow_origins=allowed_origins, include_lifespan=False
            )

        # Only mount SSE app if MCP Router is initialized (not on Windows)
        if mcp_router is not None:
            # Check for route conflicts before mounting
            main_app_routes = {route.path for route in app.routes}
            sse_app_routes = {route.path for route in sse_app.routes}
            conflicting_routes = main_app_routes.intersection(sse_app_routes)

            if conflicting_routes:
                logger.error(f'Route conflicts detected: {conflicting_routes}')
                raise RuntimeError(
                    f'Cannot mount SSE app - conflicting routes found: {conflicting_routes}'
                )

            app.mount('/', sse_app)
            logger.info(
                f'Mounted MCP Router SSE app at root path with allowed origins: {allowed_origins}'
            )

            # Additional debug logging
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug('Main app routes:')
                for route in main_app_routes:
                    logger.debug(f'  {route}')
                logger.debug('MCP SSE server app routes:')
                for route in sse_app_routes:
                    logger.debug(f'  {route}')

        yield

        # Clean up & release the resources
        logger.info('Shutting down MCP Router...')
        if mcp_router:
            try:
                await mcp_router.shutdown()
                logger.info('MCP Router shutdown successfully.')
            except Exception as e:
                logger.error(f'Error shutting down MCP Router: {e}', exc_info=True)
        else:
            logger.info('MCP Router instance not found for shutdown.')

        logger.info('Closing ActionExecutor...')
        if client:
            try:
                await client.close()
                logger.info('ActionExecutor closed successfully.')
            except Exception as e:
                logger.error(f'Error closing ActionExecutor: {e}', exc_info=True)
        else:
            logger.info('ActionExecutor instance not found for closing.')
        logger.info('Shutdown complete.')

    app = FastAPI(lifespan=lifespan)

    # Feature/capability negotiation for clients.
    app.include_router(create_capabilities_router(lambda: client))

    # Split out lightweight status endpoints to keep this file manageable.
    app.include_router(create_health_router(lambda: client))

    # Split out file manager endpoints to keep this file manageable.
    app.include_router(create_file_manager_router(lambda: client))

    # Split out file transfer endpoints (/upload_file, /write_file_stream, /download_files).
    app.include_router(create_file_transfer_router(lambda: client))

    # Split out async action endpoints (/execute_action, /actions/*, /stop_all).
    app.include_router(
        create_async_actions_router(
            get_client=lambda: client,
            async_action_service=_ASYNC_ACTION_SERVICE,
            task_store=_TASK_STORE,
            get_workspace_state_payload=lambda: _get_workspace_state_payload(),
        )
    )

    async def _set_workspace_mode_override(
        state: WorkspaceStateName, reason: str | None
    ) -> None:
        logger.debug(
            'set_workspace_mode: waiting for _WORKSPACE_MODE_OVERRIDE_LOCK (state=%s)',
            state,
        )
        async with _WORKSPACE_MODE_OVERRIDE_LOCK:
            logger.info(
                'set_workspace_mode: lock acquired, setting override (state=%s, reason=%s)',
                state,
                reason,
            )
            _WORKSPACE_MODE_OVERRIDE.state = state
            _WORKSPACE_MODE_OVERRIDE.reason = reason or f'{state} (override)'

    async def _clear_workspace_mode_override() -> None:
        logger.debug('clear_workspace_mode: waiting for _WORKSPACE_MODE_OVERRIDE_LOCK')
        async with _WORKSPACE_MODE_OVERRIDE_LOCK:
            logger.info('clear_workspace_mode: lock acquired, clearing override')
            _WORKSPACE_MODE_OVERRIDE.state = None
            _WORKSPACE_MODE_OVERRIDE.reason = None

    # Split out workspace_mode endpoints while keeping override logic here.
    app.include_router(
        create_workspace_mode_router(
            set_override=_set_workspace_mode_override,
            clear_override=_clear_workspace_mode_override,
            get_workspace_state_payload=lambda: _get_workspace_state_payload(),
        )
    )

    async def _get_session_pool_summary() -> dict[str, Any]:
        return await client.session_pool.summary() if client is not None else {}

    # Split out workspace_state + running_commands endpoints.
    app.include_router(
        create_workspace_status_router(
            get_workspace_state_payload=lambda: _get_workspace_state_payload(),
            list_active_commands=lambda: _RUNNING_REGISTRY.list_active(),
            get_session_pool_summary=_get_session_pool_summary,
            get_registry_entry=lambda task_id: _RUNNING_REGISTRY.get(task_id),
        )
    )

    # Split out MCP update endpoint.
    app.include_router(
        create_mcp_update_router(
            get_client=lambda: client,
            get_mcp_router=lambda: mcp_router,
            profile_path=MCP_ROUTER_PROFILE_PATH,
        )
    )

    # Split out idle_life endpoint.
    app.include_router(create_idle_life_router(get_client=lambda: client))

    # Split out VSCode-specific endpoint(s).
    app.include_router(create_vscode_router(get_client=lambda: client))

    # TODO below 3 exception handlers were recommended by Sonnet.
    # Are these something we should keep?
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.exception('Unhandled exception occurred:')
        return JSONResponse(
            status_code=500,
            content={'detail': 'An unexpected error occurred. Please try again later.'},
        )

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException):
        logger.error(f'HTTP exception occurred: {exc.detail}')
        return JSONResponse(status_code=exc.status_code, content={'detail': exc.detail})

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ):
        logger.error(f'Validation error occurred: {exc}')
        return JSONResponse(
            status_code=422,
            content={
                'detail': 'Invalid request parameters',
                'errors': str(exc.errors()),
            },
        )

    @app.middleware('http')
    async def authenticate_requests(request: Request, call_next):
        if request.url.path != '/alive' and request.url.path != '/server_info':
            try:
                verify_api_key(request.headers.get('X-Session-API-Key'))
            except HTTPException as e:
                return JSONResponse(
                    status_code=e.status_code, content={'detail': e.detail}
                )
        response = await call_next(request)
        return response

    # ================================
    # Workspace state + running command monitoring
    # ================================

    async def _get_workspace_state_payload() -> dict[str, Any]:
        # Runtime can be queried before startup finished (avoid 502s)
        if client is None:
            return {
                'state': WorkspaceStateName.STARTING,
                'accepting_user_actions': False,
                'blocked_reason': 'Runtime initializing',
                'running_summary': 'initializing',
                'running_count': 0,
                'max_slots': DEFAULT_MAX_SLOTS,
                'slots': {
                    'running': 0,
                    'stopping': 0,
                    'available': DEFAULT_MAX_SLOTS,
                    'max': DEFAULT_MAX_SLOTS,
                },
                'running_commands': [],
            }

        summary = await client.session_pool.summary()
        running = summary.get('running', 0)
        stopping = summary.get('stopping', 0)
        max_size = summary.get('max_size', DEFAULT_MAX_SLOTS)
        available = max(0, int(max_size) - int(running) - int(stopping))

        logger.debug(
            '_get_workspace_state_payload: waiting for _WORKSPACE_MODE_OVERRIDE_LOCK'
        )
        async with _WORKSPACE_MODE_OVERRIDE_LOCK:
            logger.debug(
                '_get_workspace_state_payload: lock acquired, reading override state'
            )
            override_state = _WORKSPACE_MODE_OVERRIDE.state
            override_reason = _WORKSPACE_MODE_OVERRIDE.reason

        # Mode override takes precedence
        if override_state is not None:
            state_name = override_state
        else:
            if running == 0 and stopping == 0:
                state_name = WorkspaceStateName.READY
            elif running + stopping < max_size:
                state_name = WorkspaceStateName.BUSY_SLOTS_AVAILABLE
            else:
                state_name = WorkspaceStateName.BUSY_SLOTS_EXHAUSTED

        accepting = state_name in (
            WorkspaceStateName.READY,
            WorkspaceStateName.BUSY_SLOTS_AVAILABLE,
        )
        active = await _RUNNING_REGISTRY.list_active()
        if override_reason is not None:
            blocked_reason = override_reason
        elif accepting:
            blocked_reason = None
        elif state_name == WorkspaceStateName.BUSY_SLOTS_EXHAUSTED:
            blocked_reason = 'All command slots are busy'
        else:
            blocked_reason = 'Workspace is not accepting new commands'

        payload = {
            'state': state_name,
            'accepting_user_actions': accepting,
            'blocked_reason': blocked_reason,
            'running_summary': 'idle' if len(active) == 0 else f'{len(active)} running',
            'running_count': int(running),
            'running_commands': active,
            'max_slots': int(max_size),
            'slots': {
                'running': int(running),
                'stopping': int(stopping),
                'available': int(available),
                'max': int(max_size),
            },
            # Debug: registry vs pool counts (for drift visibility)
            'running_registry_count': len(active),
            'running_pool_count': int(running),
        }
        return payload

    # Split out file listing endpoint used by the UI.
    app.include_router(create_list_files_router(get_client=lambda: client))

    logger.debug(f'Starting action execution API on port {args.port}')
    run(app, host='0.0.0.0', port=args.port)
