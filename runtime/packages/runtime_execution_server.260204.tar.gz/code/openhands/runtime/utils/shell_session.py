from __future__ import annotations

import re
from typing import Callable, Protocol

from openhands.events.action import CmdRunAction
from openhands.events.observation import ErrorObservation
from openhands.events.observation.commands import CmdOutputObservation


ShellObservation = CmdOutputObservation | ErrorObservation


class ShellSession(Protocol):
    """Minimal interface that ActionExecutor expects from a shell session.

    Implementations can be backed by tmux+bash, PowerShell, SSH, etc.
    """

    @property
    def cwd(self) -> str: ...

    def execute(
        self, action: CmdRunAction, log_callback: Callable[[str], None] | None = None
    ) -> ShellObservation: ...

    def close(self) -> None: ...

    # Health/restart hooks (best-effort; used by the session pool)
    def is_healthy(self) -> bool: ...

    def restart(self) -> None: ...

    # Stop escalation primitives (used by ActionExecutor.stop_task)
    def interrupt(self) -> None: ...

    def quit(self) -> None: ...

    def terminate(self) -> None: ...

    def kill(self) -> None: ...


def is_background_command(command: str) -> bool:
    """Detect background/daemonizing commands (&/nohup/disown).

    Kept as a standalone helper so ActionExecutor is not coupled to BashSession.
    """

    c = (command or "").strip()
    if not c:
        return False

    c_lower = c.lower()

    if c_lower.startswith("nohup "):
        return True
    if c_lower.startswith("disown") or " disown" in c_lower:
        return True

    # trailing '&' (but not '&&')
    if c.endswith("&") and not c.endswith("&&"):
        return True

    # standalone '&' token anywhere (avoid '&&' and '&>' redirection)
    if re.search(r"(^|[;\s])&(?![&>])(\s|$)", c):
        return True

    return False
