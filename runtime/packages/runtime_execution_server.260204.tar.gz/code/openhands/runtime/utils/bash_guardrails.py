import re
from typing import Callable

from openhands.runtime.utils.process_listing import _list_python_processes


# Matches dangerous pkill commands that indiscriminately target all Python processes,
# such as `pkill -f python` or `sudo pkill -9 -f "python"`.
#
# This pattern is applied to individual commands after `split_bash_commands()` has
# separated any command chains. It allows optional `sudo` and optional `-9`,
# requires `-f`/`--full`, and requires a bare `python` argument (optionally quoted).
_DANGEROUS_PKILL_PYTHON_RE = re.compile(
    r"""(?x)
^\s*
(?=.*(?:^|\s)(?:--full\b|-(?!-)[^\s]*f[^\s]*))
(?:sudo\s+)?(?:\S*/)?pkill\b
(?:\s+-[^\s]+)*
\s+
(?:
  \"python(?:\d+(?:\.\d+)*)?(?:\.exe)?\"|
  'python(?:\d+(?:\.\d+)*)?(?:\.exe)?'|
   python(?:\d+(?:\.\d+)*)?(?:\.exe)?
)
(?:\s*(?:\#.*)?)?$
"""
)


def should_block_dangerous_pkill_python(
    *, commands: list[str], is_input: bool
) -> bool:
    if is_input:
        return False
    return any(_DANGEROUS_PKILL_PYTHON_RE.search((c or "").strip()) for c in commands)


def dangerous_pkill_python_error_message(
    *,
    list_python_processes: Callable[[], str] = _list_python_processes,
) -> str:
    proc_list = list_python_processes()
    return (
        "ERROR: Cannot use `pkill -f python` because it can kill ALL python processes "
        "(including the agent/runtime) and interrupt the session.\n\n"
        "Please specify which exact command / PID you want to kill.\n"
        "Current running python processes (PID + args):\n"
        f"{proc_list}\n\n"
        "Safer alternatives:\n"
        "  • kill <PID>\n"
        "  • lsof -i :<port>   (find what holds a port)\n"
        '  • pkill -f "python <your_script>.py"   (narrow pattern only)\n'
    )
