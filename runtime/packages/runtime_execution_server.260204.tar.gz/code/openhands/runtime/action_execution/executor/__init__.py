"""Core runtime executor implementation."""
