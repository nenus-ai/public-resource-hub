from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any

from openhands.core.logger import openhands_logger as logger
from openhands.runtime.utils.shell_session import ShellSession


class SlotStatus(str, Enum):
    IDLE = 'IDLE'
    RUNNING = 'RUNNING'
    STOPPING = 'STOPPING'
    BROKEN = 'BROKEN'


@dataclass
class SessionSlot:
    slot_id: str
    bash_session: ShellSession
    status: SlotStatus = SlotStatus.IDLE
    current_task_id: str | None = None
    current_command: str | None = None
    started_at: float | None = None


class SessionPool:
    """Bounded pool of independent shell sessions (slots)."""

    def __init__(self, create_session_fn, max_size: int = 5) -> None:
        self._create_session_fn = create_session_fn
        self._max_size = max_size
        self._lock = asyncio.Lock()
        self._slots: list[SessionSlot] = []

    @property
    def max_size(self) -> int:
        return self._max_size

    async def ensure_min_slots(self, n: int) -> None:
        logger.debug(f"SessionPool.ensure_min_slots: waiting for lock (n={n})")
        async with self._lock:
            logger.debug(
                f"SessionPool.ensure_min_slots: lock acquired (n={n}, current_slots={len(self._slots)})"
            )
            while len(self._slots) < n and len(self._slots) < self._max_size:
                logger.debug(
                    f"SessionPool.ensure_min_slots: creating new slot (current={len(self._slots)}, target={n})"
                )
                self._slots.append(self._new_slot(len(self._slots)))
            logger.debug(
                f"SessionPool.ensure_min_slots: lock released (final_slots={len(self._slots)})"
            )

    def _new_slot(self, index: int) -> SessionSlot:
        slot_id = f"S{index}"

        try:
            sess = self._create_session_fn(slot_id)  # type: ignore[misc]
        except TypeError:
            sess = self._create_session_fn()

        if hasattr(sess, 'slot_id'):
            setattr(sess, 'slot_id', slot_id)

        return SessionSlot(slot_id=slot_id, bash_session=sess)

    async def acquire(self) -> SessionSlot | None:
        logger.debug('SessionPool.acquire: attempting to acquire a slot')
        start = time.monotonic()
        restart_failures = 0

        while True:
            slot_to_restart: SessionSlot | None = None

            logger.debug('SessionPool.acquire: waiting for lock')
            async with self._lock:
                logger.debug(
                    f"SessionPool.acquire: lock acquired (total_slots={len(self._slots)})"
                )
                for s in self._slots:
                    if s.status == SlotStatus.IDLE:
                        s.status = SlotStatus.RUNNING
                        logger.debug(
                            f"SessionPool.acquire: found idle slot {s.slot_id}, marking as RUNNING"
                        )
                        return s

                for s in self._slots:
                    if s.status == SlotStatus.BROKEN:
                        s.status = SlotStatus.RUNNING
                        slot_to_restart = s
                        logger.debug(
                            f"SessionPool.acquire: found broken slot {s.slot_id}, will restart outside lock"
                        )
                        break

                if slot_to_restart is None:
                    if len(self._slots) < self._max_size:
                        logger.debug(
                            f"SessionPool.acquire: creating new slot (current={len(self._slots)}, max={self._max_size})"
                        )
                        s = self._new_slot(len(self._slots))
                        s.status = SlotStatus.RUNNING
                        self._slots.append(s)
                        logger.debug(
                            f"SessionPool.acquire: created and acquired new slot {s.slot_id}"
                        )
                        return s

                    logger.debug(
                        f"SessionPool.acquire: session pool exhausted (slots={len(self._slots)}, max={self._max_size})"
                    )
                    return None

            logger.debug(
                f"SessionPool.acquire: restarting broken slot {slot_to_restart.slot_id}"
            )
            try:
                restart = getattr(slot_to_restart.bash_session, 'restart', None)
                if restart is None:
                    raise RuntimeError('bash_session.restart is not available')

                await asyncio.wait_for(asyncio.to_thread(restart), timeout=3.0)
                logger.debug(
                    'SessionPool.acquire: successfully restarted slot %s',
                    slot_to_restart.slot_id,
                )
                return slot_to_restart

            except asyncio.CancelledError:
                raise

            except Exception:
                logger.warning(
                    'SessionPool.acquire: failed to restart broken session slot %s, marking as BROKEN',
                    slot_to_restart.slot_id,
                    exc_info=True,
                )
                restart_failures += 1
                async with self._lock:
                    slot_to_restart.status = SlotStatus.BROKEN

                if time.monotonic() - start > 5.0:
                    logger.error(
                        'SessionPool.acquire: giving up after repeated restart failures (failures=%d)',
                        restart_failures,
                    )
                    return None

                await asyncio.sleep(min(0.2 * restart_failures, 1.0))

    async def release(self, slot_id: str) -> None:
        logger.debug(f'SessionPool.release: waiting for lock (slot_id={slot_id})')
        async with self._lock:
            for s in self._slots:
                if s.slot_id == slot_id:
                    # keep BROKEN so acquire() can restart it
                    if s.status != SlotStatus.BROKEN:
                        s.status = SlotStatus.IDLE
                    s.current_task_id = None
                    s.current_command = None
                    s.started_at = None
                    logger.debug(
                        f'SessionPool.release: slot {slot_id} marked as IDLE and released'
                    )
                    return
            logger.warning(f'SessionPool.release: slot {slot_id} not found in pool')

    # helper to mark a slot broken
    async def mark_broken(self, slot_id: str, reason: str | None = None) -> None:
        """Mark a slot as BROKEN so the next acquire() will restart it."""
        logger.debug(
            'SessionPool.mark_broken: waiting for lock (slot_id=%s, reason=%s)',
            slot_id,
            reason,
        )
        async with self._lock:
            for s in self._slots:
                if s.slot_id == slot_id:
                    s.status = SlotStatus.BROKEN
                    s.current_task_id = None
                    s.current_command = None
                    s.started_at = None
                    logger.warning(
                        'SessionPool.mark_broken: slot %s marked as BROKEN (reason=%s)',
                        slot_id,
                        reason,
                    )
                    return
            logger.warning('SessionPool.mark_broken: slot %s not found in pool', slot_id)

    async def mark_stopping(self, slot_id: str) -> None:
        logger.debug(
            f'SessionPool.mark_stopping: waiting for lock (slot_id={slot_id})'
        )
        async with self._lock:
            for s in self._slots:
                if s.slot_id == slot_id:
                    s.status = SlotStatus.STOPPING
                    logger.debug(
                        f'SessionPool.mark_stopping: slot {slot_id} marked as STOPPING'
                    )
                    return
            logger.warning(f'SessionPool.mark_stopping: slot {slot_id} not found in pool')

    async def get_slot(self, slot_id: str) -> SessionSlot | None:
        logger.debug(f'SessionPool.get_slot: waiting for lock (slot_id={slot_id})')
        async with self._lock:
            for s in self._slots:
                if s.slot_id == slot_id:
                    return s
            return None

    async def summary(self) -> dict[str, Any]:
        async with self._lock:
            running = sum(1 for s in self._slots if s.status == SlotStatus.RUNNING)
            stopping = sum(1 for s in self._slots if s.status == SlotStatus.STOPPING)
            idle = sum(1 for s in self._slots if s.status == SlotStatus.IDLE)
            return {
                'max_size': self._max_size,
                'total_slots': len(self._slots),
                'running': running,
                'stopping': stopping,
                'idle': idle,
            }
