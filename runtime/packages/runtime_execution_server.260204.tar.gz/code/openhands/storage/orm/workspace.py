# openhands/storage/orm/workspace.py

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    String, ForeignKey, DateTime, func, Boolean,
    Text, Enum as SAEnum, JSON
)
from sqlalchemy.orm import relationship, Mapped, mapped_column

from openhands.storage.db import Base
from openhands.storage.data_models.workspace_metadata import (
    WorkspaceStatus, ProjectType, RequirementsType
)
from sqlalchemy import CheckConstraint

class WorkspaceUserConversationORM(Base):
    __tablename__ = "oais_workspace_user_conversation"

    workspace_id: Mapped[str] = mapped_column(
        String(32),
        ForeignKey("oais_workspaces.id", ondelete="CASCADE"),
        primary_key=True,
    )
    user_id: Mapped[str] = mapped_column(
        String(32),
        ForeignKey("oais_users.id", ondelete="CASCADE"),
        primary_key=True,
    )
    conversation_id: Mapped[str] = mapped_column(
        String(32), nullable=False, default=lambda: uuid.uuid4().hex
    )

    # Reverse relationship: many to one
    workspace: Mapped["WorkspaceORM"] = relationship(
        "WorkspaceORM",
        back_populates="workspace_user_conversations",  # Pay attention to complex numbers
    )


class WorkspaceORM(Base):
    __tablename__ = "oais_workspaces"

    id: Mapped[str] = mapped_column(
        String(32), primary_key=True, default=lambda: uuid.uuid4().hex
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("oais_users.id", ondelete="CASCADE"), nullable=False, index=True)
    visible: Mapped[str] = mapped_column(String(32), default="self", nullable=False) # public: all people visible
    description: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False) # e.g., for soft deletion or archiving
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    repository: Mapped[Optional[str]] = mapped_column(Text)  # Git URL
    git_provider: Mapped[Optional[str]] = mapped_column(String(32), default="github")
    selected_branch: Mapped[Optional[str]] = mapped_column(String(128), default="main")
    workspace_path: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[Optional[WorkspaceStatus]] = mapped_column(
        SAEnum(WorkspaceStatus, name="ws_status_enum"),
        default=WorkspaceStatus.CREATING,
    )
    last_accessed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    last_modified_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    size_bytes: Mapped[Optional[int]]
    commit_hash: Mapped[Optional[str]] = mapped_column(String(40))
    tags: Mapped[Optional[list[str]]] = mapped_column(JSON)
    settings: Mapped[Optional[dict]] = mapped_column(JSON)

    ide_url: Mapped[Optional[str]] = mapped_column(Text)
    container_id: Mapped[Optional[str]] = mapped_column(String(36))
    snapshot_id: Mapped[Optional[str]] = mapped_column(String(36))

    project_type: Mapped[Optional[ProjectType]] = mapped_column(
        SAEnum(ProjectType, name="ws_project_type_enum"),
        default=ProjectType.GIT_REPO_URI,
    )
    requirements_type: Mapped[Optional[RequirementsType]] = mapped_column(
        SAEnum(RequirementsType, name="ws_req_type_enum"),
        default=RequirementsType.DYNAMIC,
    )
    requirements: Mapped[Optional[str]] = mapped_column(Text)


    project: Mapped[Optional["ProjectORM"]] = relationship(
        "ProjectORM",
        back_populates="workspace",
        uselist=False,  # Ensure one-on-one
        cascade="all, delete-orphan",
    )

    workspace_user_conversations: Mapped[list["WorkspaceUserConversationORM"]] = relationship(
        "WorkspaceUserConversationORM",
        back_populates="workspace",
        cascade="all, delete-orphan",
        lazy="selectin",  # or "select"，avoid N+1
    )

    # Define a many-to-one relationship with UserORM
    # A workspace belongs to one user
    user: Mapped["UserORM"] = relationship(
        "UserORM",
        back_populates="workspaces", # This will be added to UserORM
        lazy="joined" # Eagerly load user when querying workspaces
    )

    # Key: CHECK constraint
    __table_args__ = (
        CheckConstraint(
            "visible IN ('self', 'public')",  # Only these two values are legal
            name="ck_workspace_visible_scope"
        ),
    )

    def __repr__(self):
        return f"<WorkspaceORM(id='{self.id}', name='{self.name}', user_id='{self.user_id}'>"


class ProjectORM(Base):
    __tablename__ = "oais_projects"

    id: Mapped[str] = mapped_column(
        String(32), primary_key=True, default=lambda: uuid.uuid4().hex
    )

    # One on one foreign key: Unique constraint ensures no duplication
    workspace_id: Mapped[str] = mapped_column(
        String(32),
        ForeignKey("oais_workspaces.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    paper_uri: Mapped[Optional[str]] = mapped_column(Text)

    created_time: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_time: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )

    project_type: Mapped[ProjectType] = mapped_column(
        SAEnum(ProjectType, name="proj_type_enum")
    )
    uri: Mapped[str] = mapped_column(Text, nullable=False)
    requirements_type: Mapped[RequirementsType] = mapped_column(
        SAEnum(RequirementsType, name="proj_req_type_enum")
    )
    requirements: Mapped[str] = mapped_column(Text, nullable=False)

    container_id: Mapped[Optional[str]] = mapped_column(String(36))
    snapshot_id: Mapped[Optional[str]] = mapped_column(String(36))

    # Reverse one-on-one
    workspace: Mapped["WorkspaceORM"] = relationship(
        "WorkspaceORM",
        back_populates="project",
    )

    def __repr__(self) -> str:
        return f"<ProjectORM(id='{self.id}', name='{self.name}', workspace_id='{self.workspace_id}')>"
