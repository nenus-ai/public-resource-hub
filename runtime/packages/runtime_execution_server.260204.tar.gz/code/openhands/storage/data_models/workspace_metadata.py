# openhands/storage/data_models/workspace_metadata.py

from datetime import datetime
from enum import Enum
from typing import Optional
from uuid import uuid4

from pydantic import BaseModel, Field, ConfigDict

from openhands.integrations.service_types import ProviderType


class WorkspaceStatus(str, Enum):
    """Enumeration of possible workspace statuses."""
    RUNNING = 'RUNNING'
    STOPPED = 'STOPPED'
    CREATING = 'CREATING'
    DELETING = 'DELETING'
    ERROR = 'ERROR'


class ProjectType(str, Enum):
    """Project type enumeration."""
    GIT_REPO_URI = 'git_repo_uri'
    ZIP = 'zip'
    FOLDER = 'folder'


class RequirementsType(str, Enum):
    """Requirements type enumeration."""
    DYNAMIC = 'dynamic'
    STATIC = 'static'


class Project(BaseModel):
    """Project data model based on the provided specification."""
    id: str = Field(default_factory=lambda: str(uuid4()), description="UUID")
    name: str
    description: Optional[str] = None
    paper_uri: Optional[str] = None
    created_time: datetime = Field(default_factory=datetime.now)
    updated_time: datetime = Field(default_factory=datetime.now)
    project_type: ProjectType  # git_repo_uri, zip, folder
    uri: str = Field(description="the link of the git repo")
    requirements_type: RequirementsType  # dynamic, static
    requirements: str = Field(description="the requirement for this project to run")
    container_id: Optional[str] = Field(None, description="UUID")
    snapshot_id: Optional[str] = Field(None, description="Refers to a Snapshot")


class WorkspaceUserConversationMetadata(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    workspace_id: str = Field(
        ...,
        description='Unique identifier for the workspace'
    )

    user_id: str = Field(
        ...,
        description='The current user of this workspace'
    )

    conversation_id: str = Field(
        ...,
        description='The current conversation in this workspace'
    )


class WorkspaceMetadata(BaseModel):
    """Metadata for a workspace.

    This model represents the persistent metadata associated with a workspace,
    including repository information, user ownership, and workspace state.
    """
    model_config = ConfigDict(from_attributes=True)

    workspace_id: str = Field(
        ...,
        description='Unique identifier for the workspace'
    )

    visible: str = Field(
        ...,
        description='Visible range of this workspace'
    )

    user_id: str = Field(
        ...,
        description='ID of the user who owns this workspace'
    )

    repository: Optional[str] = Field(
        ...,
        description='Git repository URL or name (e.g., owner/repo)'
    )

    git_provider: ProviderType = Field(
        default=ProviderType.GITHUB,
        description='Git provider type (GitHub, GitLab, etc.)'
    )

    selected_branch: str = Field(
        default='main',
        description='Git branch currently checked out in the workspace'
    )

    workspace_name: str = Field(
        ...,
        description='Human-readable name for the workspace'
    )

    description: Optional[str] = Field(
        default=None,
        description='Optional description of the workspace purpose'
    )

    workspace_path: str = Field(
        ...,
        description='Local filesystem path to the workspace directory'
    )

    status: WorkspaceStatus = Field(
        default=WorkspaceStatus.CREATING,
        description='Current status of the workspace'
    )

    created_at: datetime = Field(
        ...,
        description='Timestamp when the workspace was created'
    )

    last_accessed_at: datetime = Field(
        ...,
        description='Timestamp when the workspace was last accessed'
    )

    last_modified_at: Optional[datetime] = Field(
        default_factory=datetime.now,
        description='Timestamp when the workspace was last modified'
    )

    size_bytes: Optional[int] = Field(
        default=None,
        description='Total size of the workspace in bytes'
    )

    commit_hash: Optional[str] = Field(
        default=None,
        description='Current commit hash of the repository'
    )

    tags: Optional[list[str]] = Field(
        default_factory=list,
        description='Optional tags for organizing workspaces'
    )

    settings: Optional[dict] = Field(
        default_factory=dict,
        description='Workspace-specific settings and preferences'
    )

    # New fields based on Project model and API specification
    ide_url: Optional[str] = Field(
        default=None,
        description='URL to open the IDE environment'
    )

    container_id: Optional[str] = Field(
        default=None,
        description='Container UUID for running workspace'
    )

    snapshot_id: Optional[str] = Field(
        default=None,
        description='Snapshot UUID for workspace state'
    )

    project_type: ProjectType = Field(
        default=ProjectType.GIT_REPO_URI,
        description='Type of project'
    )

    requirements_type: RequirementsType = Field(
        default=RequirementsType.DYNAMIC,
        description='Requirements type'
    )

    requirements: Optional[str] = Field(
        default=None,
        description='Project requirements to run'
    )

    def update_last_accessed(self) -> None:
        """Update the last accessed timestamp to now."""
        self.last_accessed_at = datetime.utcnow()

    def update_last_modified(self) -> None:
        """Update the last modified timestamp to now."""
        self.last_modified_at = datetime.now()

    def is_running(self) -> bool:
        """Check if the workspace is in a running state."""
        return self.status == WorkspaceStatus.RUNNING

    def is_accessible(self) -> bool:
        """Check if the workspace is accessible for operations."""
        return self.status in {WorkspaceStatus.RUNNING, WorkspaceStatus.STOPPED}

    def get_container_launch_strategy(self) -> str:
        """
        The algorithm to launch the container for the project:
        If the container_id is not none and the container can be started, use the container
        Else start the container from the snapshot_id.
        """
        if self.container_id:
            return f"Use existing container: {self.container_id}"
        elif self.snapshot_id:
            return f"Start from snapshot: {self.snapshot_id}"
        else:
            return "Create new container from project source"


class WorkspaceCreateRequest(BaseModel):
    """Request model for creating a new workspace."""

    repository: str = Field(
        ...,
        description='Git repository URL or name',
        min_length=1
    )

    git_provider: ProviderType = Field(
        default=ProviderType.GITHUB,
        description='Git provider type'
    )

    selected_branch: Optional[str] = Field(
        default='main',
        description='Git branch to checkout'
    )

    workspace_name: Optional[str] = Field(
        default=None,
        description='Custom name for the workspace'
    )

    description: Optional[str] = Field(
        default=None,
        description='Description of the workspace'
    )

    tags: Optional[list[str]] = Field(
        default_factory=list,
        description='Tags for organizing the workspace'
    )

    settings: Optional[dict] = Field(
        default_factory=dict,
        description='Initial workspace settings'
    )


class WorkspaceUpdateRequest(BaseModel):
    """Request model for updating workspace metadata."""

    workspace_name: Optional[str] = Field(
        default=None,
        description='Updated name for the workspace'
    )

    description: Optional[str] = Field(
        default=None,
        description='Updated description'
    )

    tags: Optional[list[str]] = Field(
        default=None,
        description='Updated tags'
    )

    settings: Optional[dict] = Field(
        default=None,
        description='Updated settings'
    )

    status: Optional[WorkspaceStatus] = Field(
        default=None,
        description='Updated status'
    )


class WorkspaceListResponse(BaseModel):
    """Response model for listing workspaces."""

    workspaces: list[WorkspaceMetadata] = Field(
        ...,
        description='List of workspace metadata'
    )

    total: int = Field(
        ...,
        description='Total number of workspaces'
    )

    limit: int = Field(
        ...,
        description='Maximum number of results returned'
    )

    offset: int = Field(
        ...,
        description='Number of results skipped'
    )

    has_more: bool = Field(
        ...,
        description='Whether there are more results available'
    )
