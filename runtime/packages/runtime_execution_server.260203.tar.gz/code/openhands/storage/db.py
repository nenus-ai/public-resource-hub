# openhands/storage/db.py

import json
import os
import ssl
from contextlib import asynccontextmanager
from typing import Optional

import boto3
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.pool import NullPool

from openhands.storage.event_loop import equal_to_global_event_loop

# Path to store RDS CA bundle
RDS_CA_PATH = '/tmp/rds-ca-bundle.pem'
RDS_CA_URL = 'https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem'


def ensure_rds_ca_bundle():
    """Download RDS global CA bundle if not already present."""
    import urllib.request

    if not os.path.exists(RDS_CA_PATH):
        urllib.request.urlretrieve(RDS_CA_URL, RDS_CA_PATH)


def get_db_credentials(secret_name: str, region: str = 'us-west-1') -> dict:
    """Fetch database credentials from AWS Secrets Manager."""
    client = boto3.client('secretsmanager', region_name=region)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])


def build_database_url(secret_name: str, region: str = 'us-west-1') -> str:
    """Build SQLAlchemy asyncpg connection URL with Secrets Manager credentials."""
    # if DATABASE_URL provides, then use it directly
    if DATABASE_URL:
        return DATABASE_URL
    creds = get_db_credentials(secret_name, region)
    user = creds['username']
    password = creds['password']
    host = os.getenv('DB_HOST', 'localhost')
    port = os.getenv('DB_PORT', 5432)
    dbname = os.getenv('DB_NAME', 'postgres')
    return f'postgresql+asyncpg://{user}:{password}@{host}:{port}/{dbname}'


# --- Setup SQLAlchemy Engine ---
secret_name = os.getenv('DB_SECRET_NAME')  # e.g. "my-rds-secret"
region = os.getenv('AWS_REGION', 'us-west-1')
DATABASE_URL = os.getenv('DATABASE_URL')
if secret_name:
    DATABASE_URL = build_database_url(secret_name, region)
    ensure_rds_ca_bundle()
    ssl_context: Optional[ssl.SSLContext] = ssl.create_default_context(
        cafile=RDS_CA_PATH
    )
    connect_args = {'ssl': ssl_context}
else:
    ssl_context = None
    connect_args = {}
POOL_SIZE = int(os.getenv('DB_POOL_SIZE', '20'))
MAX_OVERFLOW = int(os.getenv('DB_MAX_OVERFLOW', '20'))

# IMPORTANT: do not create the engine at import time if DATABASE_URL isn't set.
# Many unit tests import server modules without needing a database; failing fast
# at import time makes testing (and some CLI tooling) unnecessarily brittle.
async_engine: Optional[AsyncEngine] = None
AsyncSessionLocal: Optional[async_sessionmaker[AsyncSession]] = None


def _ensure_global_engine() -> None:
    global async_engine, AsyncSessionLocal
    if async_engine is not None and AsyncSessionLocal is not None:
        return

    if not DATABASE_URL:
        raise ValueError('DATABASE_URL environment variable is not set.')

    async_engine = create_async_engine(
        DATABASE_URL,
        echo=False,
        connect_args=connect_args,  # Use SSL if RDS CA bundle is set
        pool_size=POOL_SIZE,
        max_overflow=MAX_OVERFLOW,
    )
    AsyncSessionLocal = async_sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )


# if the DATABASE_URL is set at import time, initialize the global engine immediately.
# This is the common case in production, and it ensures the engine is ready before any requests
# In testing, DATABASE_URL is often set later, so the engine will be initialized lazily on first use.
if DATABASE_URL:
    _ensure_global_engine()


@asynccontextmanager
async def create_async_session_local():
    """Get an async session for database operations."""
    # compare the current event loop with the one used to create the engine
    if not equal_to_global_event_loop():
        if not DATABASE_URL:
            raise ValueError('DATABASE_URL environment variable is not set.')
        # create a new engine and sessionmaker in the current event loop
        async_engine = create_async_engine(
            DATABASE_URL,
            echo=False,
            connect_args=connect_args,
            poolclass=NullPool,
        )
        current_AsyncSessionLocal = async_sessionmaker(
            async_engine,
            class_=AsyncSession,  # Explicitly use AsyncSession
            expire_on_commit=False,
        )
        """Get an async session for database operations."""
        try:
            async with current_AsyncSessionLocal() as session:
                yield session
        finally:
            await async_engine.dispose()

    else:
        _ensure_global_engine()
        assert AsyncSessionLocal is not None
        async with AsyncSessionLocal() as session:
            yield session


class Base(DeclarativeBase):
    pass


async def get_session() -> AsyncSession:
    """
    FastAPI specific dependency: An Asynchronous Session is automatically created for each request,
    And close the connection when the request ends.
    """
    async with create_async_session_local() as session:
        yield session
