from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class RunningCommandStatus(str, Enum):
    """Lifecycle state for a runtime command slot/task."""
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    STOPPING = "STOPPING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class RunningCommandEntry(BaseModel):
    """Single running command slot/task entry (monitoring API)."""
    model_config = ConfigDict(from_attributes=True)

    slot_id: str = Field(..., description="Slot/session identifier (e.g., S0..S4)")
    command: str = Field(..., description="Command string executed in that slot")
    task_id: str = Field(..., description="Runtime task_id backing the async execution")
    status: RunningCommandStatus = Field(..., description="Current running status")

    # Times are epoch seconds (UTC) to keep JSON payloads simple across boundaries.
    start_time: float = Field(..., description="When the command started (epoch seconds, UTC)")
    duration_seconds: float = Field(..., description="Elapsed duration (seconds)")

    pid: Optional[int] = Field(default=None, description="Best-effort PID of foreground process")
    last_output_time: Optional[float] = Field(
        default=None, description="Last time output was observed (epoch seconds, UTC)"
    )
    tail: Optional[str] = Field(
        default=None, description="Tail of recent output (best-effort, may be truncated)"
    )
