from pydantic import BaseModel, Field

class RuntimeCommitRequest(BaseModel):
    registry : str = Field(..., description="The container registry where the committed runtime image will be pushed.")
    repository: str = Field(..., description="The repository where the committed runtime image will be stored.")
    tag: str = Field(..., description="The tag for the committed runtime image.")
    message: str = Field(..., description="The commit message for the runtime image.")
    author: str = Field(..., description="The author of the commit.")

class RuntimeCommitResponse(BaseModel):
    container_id: str = Field(..., description="The ID of the container that was committed.")
    base_image: str = Field(..., description="The base image used for the committed runtime.")
    image_size_mb: int = Field(..., description="The size of the committed image in megabytes.")
