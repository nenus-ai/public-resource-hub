import os
import re
import tempfile
from enum import Enum
import threading
import time
from pathlib import Path
from urllib.parse import unquote
from typing import Any
from zipfile import ZipFile
import json

import httpcore
import httpx
from tenacity import retry, retry_if_exception, stop_after_attempt, wait_exponential

from openhands.core.config import OpenHandsConfig
from openhands.core.config.mcp_config import (
    MCPConfig,
    MCPSSEServerConfig,
    MCPStdioServerConfig,
)
from openhands.core.exceptions import (
    AgentRuntimeError,
    AgentRuntimeNotReadyError,
)
from openhands.core.logger import openhands_logger as logger
from openhands.shared.runtime_constants import DEFAULT_MAX_SLOTS
from openhands.events import EventStream
from openhands.events.action import (
    ActionConfirmationStatus,
    AgentThinkAction,
    BrowseInteractiveAction,
    BrowseURLAction,
    CmdRunAction,
    FileEditAction,
    FileReadAction,
    FileWriteAction,
    IPythonRunCellAction,
)
from openhands.events.action.action import Action
from openhands.events.action.files import FileEditSource
from openhands.events.action.mcp import MCPAction
from openhands.events.observation import (
    AgentThinkObservation,
    CmdOutputObservation,
    ErrorObservation,
    NullObservation,
    Observation,
    UserRejectObservation,
)
from openhands.events.stream import EventSource
from openhands.events.serialization import event_to_dict, observation_from_dict
from openhands.events.serialization.action import ACTION_TYPE_TO_CLASS
from openhands.integrations.provider import PROVIDER_TOKEN_TYPE
from openhands.runtime.action_execution.services.async_tasks import AsyncTaskStatus
from openhands.runtime.base import Runtime
from openhands.runtime.plugins import PluginRequirement
from openhands.runtime.utils.request import send_request
from openhands.utils.http_session import HttpSession
from openhands.utils.shutdown_listener import should_continue
from openhands.utils.tenacity_stop import stop_if_should_exit
from openhands.shared.runtime_capabilities import (
    CORE_CAPABILITIES,
    KNOWN_CAPABILITIES,
    CAPABILITIES_PROTOCOL_VERSION,
)


def _is_retryable_error(exception):
    return isinstance(
        exception, (httpx.RemoteProtocolError, httpcore.RemoteProtocolError, httpx.TimeoutException)
    )


class ActionExecutionClient(Runtime):
    """Base class for runtimes that interact with the action execution server.

    This class contains shared logic between DockerRuntime and RemoteRuntime
    for interacting with the HTTP server defined in action_execution_server.py.
    """

    def __init__(
        self,
        config: OpenHandsConfig,
        event_stream: EventStream,
        sid: str = 'default',
        plugins: list[PluginRequirement] | None = None,
        env_vars: dict[str, str] | None = None,
        status_callback: Any | None = None,
        attach_to_existing: bool = False,
        headless_mode: bool = True,
        user_id: str | None = None,
        git_provider_tokens: PROVIDER_TOKEN_TYPE | None = None,
    ):
        self.session = HttpSession()
        self.action_semaphore = threading.Semaphore(1)  # Ensure one action at a time
        # Tracks per-task abort flags so polling can exit immediately when cancelled.
        self._task_abort_flags: dict[str, threading.Event] = {}
        self._task_abort_lock = threading.Lock()
        # Protects _active_async_task_id reads/writes across polling + stop/cancel threads.
        self._active_task_lock = threading.Lock()
        # Best-effort pointer to the currently running async task (for Stop wiring in higher layers).
        self._active_async_task_id: str | None = None
        self._runtime_closed: bool = False
        self._vscode_token: str | None = None  # initial dummy value
        self._last_updated_mcp_stdio_servers: list[MCPStdioServerConfig] = []
        self._capabilities_loaded: bool = False
        self._capabilities: dict[str, bool] = {k: False for k in KNOWN_CAPABILITIES}
        for k in CORE_CAPABILITIES:
            self._capabilities[k] = True
        self._capabilities_protocol_version: int = 0
        self._capabilities_source: str = 'core'
        super().__init__(
            config,
            event_stream,
            sid,
            plugins,
            env_vars,
            status_callback,
            attach_to_existing,
            headless_mode,
            user_id,
            git_provider_tokens,
        )

    @property
    def action_execution_server_url(self) -> str:
        raise NotImplementedError('Action execution server URL is not implemented')

    @retry(
        retry=retry_if_exception(_is_retryable_error),
        stop=stop_after_attempt(5) | stop_if_should_exit(),
        wait=wait_exponential(multiplier=1, min=4, max=15),
    )
    def _send_action_server_request(
        self,
        method: str,
        url: str,
        **kwargs,
    ) -> httpx.Response:
        """Send a request to the action execution server.

        Args:
            method: HTTP method (GET, POST, etc.)
            url: URL to send the request to
            **kwargs: Additional arguments to pass to requests.request()

        Returns:
            Response from the server

        Raises:
            AgentRuntimeError: If the request fails
        """
        return send_request(self.session, method, url, **kwargs)

    @staticmethod
    def _get_http_status_code(exception: BaseException, *, max_depth: int = 6) -> int | None:
        """Best-effort HTTP status extraction from wrapped client errors.

        `send_request()` raises `RequestHTTPError` (a `httpx.HTTPStatusError`) and
        callers may wrap exceptions (e.g., `AgentRuntimeError`). Walk the exception
        chain to locate a `response.status_code`.
        """
        cur: BaseException | None = exception
        for _ in range(max_depth):
            if cur is None:
                break
            response = getattr(cur, 'response', None)
            status_code = getattr(response, 'status_code', None)
            if isinstance(status_code, int):
                return status_code
            nxt = getattr(cur, '__cause__', None) or getattr(cur, '__context__', None)
            if nxt is None or nxt is cur:
                break
            cur = nxt
        return None

    @staticmethod
    def _is_404(exception: BaseException) -> bool:
        status_code = ActionExecutionClient._get_http_status_code(exception)
        if status_code == 404:
            return True
        # Last-resort string fallback for wrapped/serialized errors.
        msg = str(exception)
        return '404' in msg and 'Not Found' in msg

    @staticmethod
    def _default_running_commands_payload() -> dict[str, Any]:
        return {
            'running_commands': [],
            'max_slots': DEFAULT_MAX_SLOTS,
        }

    @staticmethod
    def _default_workspace_state_payload() -> dict[str, Any]:
        """Fallback payload when the runtime doesn't support workspace state queries."""
        return {
            'state': 'UNSUPPORTED',
            'accepting_user_actions': True,
            'blocked_reason': None,
            'running_summary': 'Workspace state unsupported on this runtime version.',
            'running_count': 0,
            'running_commands': [],
            'max_slots': DEFAULT_MAX_SLOTS,
            'slots': {'running': 0, 'stopping': 0, 'available': DEFAULT_MAX_SLOTS, 'max': DEFAULT_MAX_SLOTS},
        }

    def _get(self, path: str, *, timeout: float = 10) -> dict[str, Any]:
        response = self._send_action_server_request(
            'GET',
            f'{self.action_execution_server_url}{path}',
            timeout=timeout,
        )
        assert response.is_closed
        out = response.json()
        assert isinstance(out, dict)
        return out

    def check_if_alive(self) -> None:
        response = self._send_action_server_request(
            'GET',
            f'{self.action_execution_server_url}/alive',
            timeout=5,
        )
        assert response.is_closed

    def _reset_to_core_capabilities(self) -> None:
        """Reset capabilities to core-only defaults."""
        self._capabilities = {k: False for k in KNOWN_CAPABILITIES}
        for k in CORE_CAPABILITIES:
            self._capabilities[k] = True
        self._capabilities_protocol_version = 0
        self._capabilities_source = 'core'

    def refresh_capabilities(self, *, force: bool = False) -> None:
        """Fetch and cache runtime capabilities from GET /capabilities.

        If the endpoint is missing (404), treat as legacy runtime and keep core defaults.
        This method is intentionally best-effort and must not break runtime startup.
        """

        if self._capabilities_loaded and not force:
            return

        try:
            data = self._get('/capabilities', timeout=5)
            protocol = data.get('protocol_version')
            capabilities = data.get('capabilities')

            if not isinstance(protocol, int) or protocol < 1:
                # Unknown response shape; keep core.
                self.log('debug', f'capabilities: invalid protocol_version={protocol}; using core defaults')
                self._capabilities_loaded = True
                self._capabilities_protocol_version = 0
                self._capabilities_source = 'core'
                return

            if protocol > CAPABILITIES_PROTOCOL_VERSION:
                # Server is newer than client. We can still use known keys.
                self.log('debug', f'capabilities: server protocol_version={protocol} newer than client={CAPABILITIES_PROTOCOL_VERSION}')

            if not isinstance(capabilities, dict):
                self.log('debug', 'capabilities: missing capabilities map; using core defaults')
                self._capabilities_loaded = True
                self._capabilities_protocol_version = protocol
                self._capabilities_source = 'core'
                return

            # Start from conservative defaults.
            merged: dict[str, bool] = {k: False for k in KNOWN_CAPABILITIES}
            for k in CORE_CAPABILITIES:
                merged[k] = True

            for k, v in capabilities.items():
                if k in merged:
                    merged[k] = bool(v)

            self._capabilities = merged
            self._capabilities_loaded = True
            self._capabilities_protocol_version = protocol
            self._capabilities_source = 'server'
            self.log('debug', f'capabilities loaded: source=server protocol={protocol}')

        except Exception as e:
            # Optional endpoint; older runtimes won't have it.
            # Reset to core-only defaults to avoid stale capabilities.
            # Client will handle retry, so always mark as not loaded.
            self._reset_to_core_capabilities()
            self.log('debug', f'capabilities: failed to fetch; using core defaults: {e}')
            self._capabilities_loaded = False

    def supports_capability(self, capability: str) -> bool:
        # Lazy-load in case runtime startup didn't fetch yet.
        if not self._capabilities_loaded:
            self.refresh_capabilities()
        return bool(self._capabilities.get(capability, False))

    def get_capabilities_snapshot(self) -> dict[str, Any]:
        """Return a JSON-serializable snapshot of negotiated capabilities."""

        # Always refresh capabilities to ensure we get the latest from the runtime.
        # The runtime might have been starting up during initial connect() and 
        # capabilities may not have been available then.
        self.refresh_capabilities(force=True)

        # If refresh failed (runtime not ready), raise exception for retry logic.
        if not self._capabilities_loaded:
            raise AgentRuntimeNotReadyError(
                'Runtime capabilities are not available yet (capabilities negotiation not complete). Please retry.'
            )
        return {
            'protocol_version': self._capabilities_protocol_version,
            'source': self._capabilities_source,
            'core_capabilities': sorted(CORE_CAPABILITIES),
            'capabilities': dict(self._capabilities),
        }

    def list_files(self, path: str | None = None) -> list[str]:
        """List files in the sandbox.

        If path is None, list files in the sandbox's initial working directory (e.g., /workspace).
        """

        try:
            data = {}
            if path is not None:
                data['path'] = path

            response = self._send_action_server_request(
                'POST',
                f'{self.action_execution_server_url}/list_files',
                json=data,
                timeout=10,
            )
            assert response.is_closed
            response_json = response.json()
            assert isinstance(response_json, list)
            return response_json
        except httpx.TimeoutException:
            raise TimeoutError('List files operation timed out')

    # ==========================================================
    # File Manager (metadata + safe mutations)
    # ==========================================================

    def list_files_metadata(self, path: str | None = None) -> dict[str, Any]:
        """List directory contents with metadata.

        Returns a dict: { "path": <requested path>, "entries": [ {name, path, is_dir, size, modified}, ... ] }
        """
        logger.debug("Action client list_files_metadata: path=%s", path or "/")
        try:
            payload: dict[str, Any] = {'path': path or ''}
            response = self._send_action_server_request(
                'POST',
                f'{self.action_execution_server_url}/file_manager/list',
                json=payload,
                timeout=30,
            )
            assert response.is_closed
            out = response.json()
            assert isinstance(out, dict)
            entry_count = len(out.get("entries", []))
            logger.debug("Action client list_files_metadata: received %d entries", entry_count)
            return out
        except httpx.TimeoutException:
            logger.error("Action client list_files_metadata: timeout for path=%s", path)
            raise TimeoutError('List files metadata operation timed out')

    def fm_mkdir(self, path: str) -> None:
        logger.debug("Action client fm_mkdir: path=%s", path)
        payload = {'path': path}
        response = self._send_action_server_request(
            'POST',
            f'{self.action_execution_server_url}/file_manager/mkdir',
            json=payload,
            timeout=30,
        )
        assert response.is_closed
        logger.debug("Action client fm_mkdir: completed for path=%s", path)

    def fm_delete(self, path: str, recursive: bool = False) -> None:
        logger.debug("Action client fm_delete: path=%s, recursive=%s", path, recursive)
        payload = {'path': path, 'recursive': recursive}
        response = self._send_action_server_request(
            'POST',
            f'{self.action_execution_server_url}/file_manager/delete',
            json=payload,
            timeout=60,
        )
        assert response.is_closed
        logger.debug("Action client fm_delete: completed for path=%s", path)

    def fm_move(self, src: str, dest: str) -> None:
        logger.debug("Action client fm_move: src=%s, dest=%s", src, dest)
        payload = {'src': src, 'dest': dest}
        response = self._send_action_server_request(
            'POST',
            f'{self.action_execution_server_url}/file_manager/move',
            json=payload,
            timeout=60,
        )
        assert response.is_closed
        logger.debug("Action client fm_move: completed src=%s -> dest=%s", src, dest)

    def download_path(self, path: str) -> tuple[Path, str]:
        """Download a file (raw) or folder (zipped) from the runtime.

        Returns: (local_temp_path, suggested_filename)
        """
        logger.debug("Action client download_path: path=%s", path)
        try:
            params = {"path": path}
            with self.session.stream(
                "GET",
                f"{self.action_execution_server_url}/file_manager/download",
                params=params,
                timeout=300,
            ) as response:
                # fail fast on non-2xx BEFORE writing bytes to a file
                if response.status_code < 200 or response.status_code >= 300:
                    # Read a small amount of the body to include in the error
                    try:
                        body = response.read()
                    except Exception:
                        body = b""

                    detail = ""
                    if body:
                        # Try JSON first, fallback to text
                        try:
                            data = json.loads(body.decode("utf-8", errors="replace"))
                            detail = data.get("detail") or str(data)
                        except Exception:
                            detail = body.decode("utf-8", errors="replace")

                    logger.error("Action client download_path: failed with status %d for path=%s",
                               response.status_code, path)
                    raise httpx.HTTPStatusError(
                        f"Download failed: {response.status_code} {response.reason_phrase}"
                        + (f" - {detail}" if detail else ""),
                        request=response.request,
                        response=response,
                    )

                def _parse_filename_from_content_disposition(v: str | None) -> str | None:
                    if not v:
                        return None

                    # RFC 5987 / RFC 6266 style: filename*=UTF-8''...
                    m_star = re.search(
                        r"filename\*\s*=\s*UTF-8''([^;]+)",
                        v,
                        flags=re.IGNORECASE,
                    )
                    if m_star and m_star.group(1):
                        raw = m_star.group(1).strip()
                        try:
                            return unquote(raw)
                        except Exception:
                            return raw

                    # Basic: filename="..." or filename=...
                    m = re.search(
                        r'filename\s*=\s*\"?([^\";]+)\"?',
                        v,
                        flags=re.IGNORECASE,
                    )
                    if m and m.group(1):
                        return m.group(1).strip()
                    return None

                def _sanitize_filename(name: str | None) -> str:
                    if not name:
                        return "download"
                    # Drop any path components; keep only a safe basename.
                    name = Path(name).name
                    # Strip control chars/newlines which can break headers/logs.
                    name = "".join(ch for ch in name if ch >= " " and ch != "\x7f")
                    name = name.replace("\n", "").replace("\r", "").strip()
                    if not name:
                        return "download"
                    return name[:255]

                cd = response.headers.get("content-disposition")
                filename = _sanitize_filename(
                    _parse_filename_from_content_disposition(cd)
                )

                suffix = Path(filename).suffix or ".bin"
                with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as temp_file:
                    bytes_written = 0
                    for chunk in response.iter_bytes():
                        temp_file.write(chunk)
                        bytes_written += len(chunk)
                    temp_file.flush()
                    logger.debug("Action client download_path: downloaded %s, size=%d", filename, bytes_written)
                    return Path(temp_file.name), filename

        except httpx.TimeoutException:
            raise TimeoutError("Download operation timed out")

    def set_workspace_mode(self, state: str, reason: str | None = None) -> dict[str, Any]:
        """Request runtime to enter a blocking mode (DRAINING/UPGRADING/MAINTENANCE/STOPPED).
        Safe actions remain allowed.
        """
        payload: dict[str, Any] = {"state": state}
        if reason is not None:
            payload["reason"] = reason

        try:
            response = self._send_action_server_request(
                "POST",
                f"{self.action_execution_server_url}/workspace_mode",
                json=payload,
                timeout=10,
            )
            assert response.is_closed
            out = response.json()
            assert isinstance(out, dict)
            return out
        except Exception as e:
            # Older action servers won't have /workspace_mode. Treat as a normal/unsupported response.
            if self._is_404(e):
                self.log('debug', 'set_workspace_mode: /workspace_mode not found on runtime (older server), ignoring')
                return {
                    'status': 'unsupported',
                    'state': state,
                    'reason': reason,
                }
            raise

    def clear_workspace_mode(self) -> dict[str, Any]:
        """Clear any maintenance/upgrade mode override and return to normal scheduling."""
        try:
            response = self._send_action_server_request(
                "DELETE",
                f"{self.action_execution_server_url}/workspace_mode",
                timeout=10,
            )
            assert response.is_closed
            out = response.json()
            assert isinstance(out, dict)
            return out
        except Exception as e:
            # Older action servers won't have /workspace_mode. Treat as a normal/unsupported response.
            if self._is_404(e):
                self.log('debug', 'clear_workspace_mode: /workspace_mode not found on runtime (older server), ignoring')
                return {
                    'status': 'unsupported',
                }
            raise

    def copy_from(self, path: str) -> Path:
        """Zip all files in the sandbox and return as a stream of bytes."""
        try:
            params = {'path': path}
            with self.session.stream(
                'GET',
                f'{self.action_execution_server_url}/download_files',
                params=params,
                timeout=30,
            ) as response:
                with tempfile.NamedTemporaryFile(
                    suffix='.zip', delete=False
                ) as temp_file:
                    for chunk in response.iter_bytes():
                        temp_file.write(chunk)
                    temp_file.flush()
                    return Path(temp_file.name)
        except httpx.TimeoutException:
            raise TimeoutError('Copy operation timed out')

    def copy_to(
        self, host_src: str, sandbox_dest: str, recursive: bool = False
    ) -> None:
        if not os.path.exists(host_src):
            raise FileNotFoundError(f'Source file {host_src} does not exist')

        temp_zip_path: str | None = None  # Define temp_zip_path outside the try block

        try:
            params = {'destination': sandbox_dest, 'recursive': str(recursive).lower()}
            file_to_upload = None
            upload_data = {}

            if recursive:
                # Create and write the zip file inside the try block
                with tempfile.NamedTemporaryFile(
                    suffix='.zip', delete=False
                ) as temp_zip:
                    temp_zip_path = temp_zip.name

                try:
                    with ZipFile(temp_zip_path, 'w') as zipf:
                        for root, _, files in os.walk(host_src):
                            for file in files:
                                file_path = os.path.join(root, file)
                                arcname = os.path.relpath(
                                    file_path, os.path.dirname(host_src)
                                )
                                zipf.write(file_path, arcname)

                    self.log(
                        'debug',
                        f'Opening temporary zip file for upload: {temp_zip_path}',
                    )
                    file_to_upload = open(temp_zip_path, 'rb')
                    upload_data = {'file': file_to_upload}
                except Exception as e:
                    # Ensure temp file is cleaned up if zipping fails
                    if temp_zip_path and os.path.exists(temp_zip_path):
                        os.unlink(temp_zip_path)
                    raise e  # Re-raise the exception after cleanup attempt
            else:
                file_to_upload = open(host_src, 'rb')
                upload_data = {'file': file_to_upload}

            params = {'destination': sandbox_dest, 'recursive': str(recursive).lower()}

            response = self._send_action_server_request(
                'POST',
                f'{self.action_execution_server_url}/upload_file',
                files=upload_data,
                params=params,
                timeout=300,
            )
            self.log(
                'debug',
                f'Copy completed: host:{host_src} -> runtime:{sandbox_dest}. Response: {response.text}',
            )
        finally:
            if file_to_upload:
                file_to_upload.close()

            # Cleanup the temporary zip file if it was created
            if temp_zip_path and os.path.exists(temp_zip_path):
                try:
                    os.unlink(temp_zip_path)
                except Exception as e:
                    self.log(
                        'error',
                        f'Failed to delete temporary zip file {temp_zip_path}: {e}',
                    )

    def write_file_stream(
        self,
        byte_iter: Any,
        sandbox_dest_dir: str,
        filename: str,
        *,
        timeout: float = 600,
    ) -> None:
        """Stream bytes into the runtime workspace without staging on disk.

        Args:
            byte_iter: An iterator yielding bytes (or memoryview/bytearray) chunks.
            sandbox_dest_dir: Absolute destination directory in the runtime.
            filename: Target filename (basename will be enforced by runtime).
        """
        params = {'destination': sandbox_dest_dir, 'filename': filename}

        # Use chunked transfer encoding; httpx will stream the iterator.
        response = self._send_action_server_request(
            'POST',
            f'{self.action_execution_server_url}/write_file_stream',
            params=params,
            content=byte_iter,
            timeout=timeout,
        )
        self.log(
            'debug',
            f'write_file_stream completed: runtime:{sandbox_dest_dir}/{filename}. Response: {response.text}',
        )

    def get_vscode_token(self) -> str:
        if self.vscode_enabled and self.runtime_initialized:
            if self._vscode_token is not None:  # cached value
                return self._vscode_token
            try:
                response = self._send_action_server_request(
                    'GET',
                    f'{self.action_execution_server_url}/vscode/connection_token',
                    timeout=10,
                )
                response_json = response.json()
                assert isinstance(response_json, dict)
                if response_json.get('token') is None:
                    return ''
                self._vscode_token = response_json['token']
                return response_json['token']
            except Exception as e:
                # Optional endpoint; older action servers may not provide VSCode integration.
                if self._is_404(e):
                    self.log('debug', 'get_vscode_token: endpoint not found on runtime (older server)')
                    return ''
                self.log('error', f'Error getting VSCode token: {e}')
                raise
        else:
            return ''

    def _poll_async_task(
        self,
        task_id: str,
        action: Action,
        request_timeout: float,
    ) -> Observation:

        poll_interval = 2.0
        log_poll_interval = 0.5  # Poll logs more frequently for real-time streaming
        assert action.timeout is not None
        deadline = time.time() + action.timeout + 10
        last_log_seq = -1  # Track sequence for incremental log fetching
        last_log_poll_time = 0.0
        abort_event = self._get_or_create_abort_event(task_id)
        with self._active_task_lock:
            self._active_async_task_id = task_id

        try:
            while True:
                current_time = time.time()
                # If higher-level stop triggered, exit polling immediately and best-effort cancel.
                if abort_event.is_set():
                    self._best_effort_cancel_task(task_id)
                    # Cancellation is a *normal* user interaction, not an error.
                    # Return a CmdOutputObservation marked as partial so:
                    #   1) The agent does NOT take another step / call the LLM.
                    #   2) The chat UI does NOT render a red error card.
                    cancelled = CmdOutputObservation(
                        content='\n[Cancelled by user]\n',
                        command=action.command
                        if isinstance(action, CmdRunAction)
                        else str(getattr(action, 'action', type(action).__name__)),
                        metadata={'exit_code': 130},
                        # Keep it visible in the terminal (cmd actions), but exclude from chat/LLM.
                        hidden=not isinstance(action, CmdRunAction),
                        is_partial=True,
                    )
                    cancelled._cause = action.id  # type: ignore[attr-defined]
                    return cancelled

                if not should_continue():
                    self._best_effort_cancel_task(task_id)
                    error_obs = ErrorObservation(
                        f'Runtime is shutting down; task {task_id} was aborted.',
                        error_id='AGENT_ERROR$RUNTIME_SHUTDOWN',
                    )
                    error_obs._cause = action.id  # type: ignore[attr-defined]
                    return error_obs

                if current_time > deadline:
                    # return a structured observation so the user gets an actionable message.
                    self._best_effort_cancel_task(task_id)
                    timeout_obs = ErrorObservation(
                        (
                            f'Task {task_id} did not finish within the requested timeout of {action.timeout}s. '
                            'Please double check the task. If this timeout is too small, consider increasing it and retrying.'
                        ),
                        error_id='AGENT_ERROR$RUNTIME_TASK_TIMEOUT',
                    )
                    timeout_obs._cause = action.id  # type: ignore[attr-defined]
                    return timeout_obs

                # Poll for incremental logs (more frequently)
                if current_time - last_log_poll_time >= log_poll_interval:
                    try:
                        # _poll_and_emit_logs returns the highest seq processed
                        new_seq = self._poll_and_emit_logs(task_id, action, last_log_seq)
                        if new_seq > last_log_seq:
                            last_log_seq = new_seq
                    except Exception as e:
                        self.log('debug', f'Log polling error for task {task_id}: {e}')
                    last_log_poll_time = current_time

                # Poll for task status (less frequently)
                status_response = self._send_action_server_request(
                    'GET',
                    f'{self.action_execution_server_url}/actions/{task_id}',
                    timeout=request_timeout,
                )
                status_json = status_response.json()
                status = status_json.get('status')
                self.log('info', f'Polling task {task_id}: status={status}')

                task_status: AsyncTaskStatus | None
                try:
                    task_status = AsyncTaskStatus(status)
                except Exception:
                    task_status = None

                if task_status in (AsyncTaskStatus.PENDING, AsyncTaskStatus.RUNNING, AsyncTaskStatus.STOPPING):
                    # Wait in an interruptible way so we can respond quickly to abort_event
                    abort_event.wait(timeout=poll_interval)
                    continue

                if status == 'completed':
                    result = status_json.get('result')
                    if result is None:
                        raise AgentRuntimeError(
                            f'Action server returned no result for completed task {task_id}'
                        )
                    result_obs = observation_from_dict(result)
                    result_obs._cause = action.id  # type: ignore[attr-defined]
                    return result_obs

                if status == 'cancelled':
                    cancelled = CmdOutputObservation(
                        content='\n[Cancelled]\n',
                        command=action.command
                        if isinstance(action, CmdRunAction)
                        else str(getattr(action, 'action', type(action).__name__)),
                        metadata={'exit_code': 130},
                        hidden=not isinstance(action, CmdRunAction),
                        is_partial=True,
                    )
                    cancelled._cause = action.id  # type: ignore[attr-defined]
                    return cancelled

                if status == 'failed':
                    # if the action server returned a structured result
                    # (CmdOutputObservation with exit_code != 0), return it so the UI
                    # marks the command as finished instead of "background running".
                    result = status_json.get('result')
                    if result is not None:
                        try:
                            result_obs = observation_from_dict(result)
                            result_obs._cause = action.id  # type: ignore[attr-defined]
                            return result_obs
                        except Exception as e:
                            self.log(
                                'debug',
                                f'Failed to parse result for failed task {task_id}: {e}',
                            )
                    # Before AgentRuntimeError was raised for any failed async task.
                    # That makes normal command failures (e.g. `cat missing_file`, segfaults,
                    # grep no matches, etc.) look like a fatal runtime error and can stop the agent.
                    #
                    # Instead, surface the failure as an ErrorObservation so the agent can continue
                    # and the UI can render the command as "finished (failed)".
                    error_message = status_json.get('error') or (
                        f'Action {task_id} failed without an error message'
                    )
                    error_obs = ErrorObservation(
                        error_message,
                        error_id='AGENT_ERROR$RUNTIME_TASK_FAILED',
                    )
                    error_obs._cause = action.id  # type: ignore[attr-defined]
                    return error_obs
                raise AgentRuntimeError(
                    f"Unknown task status '{status}' for task ID {task_id}"
                )
        finally:
            # Be defensive about task_id reuse / races: only clear the abort
            # flag if this poller is still the active task.
            with self._active_task_lock:
                if self._active_async_task_id == task_id:
                    self._active_async_task_id = None
            self._clear_abort_event(task_id)

    # Helpers
    def _get_or_create_abort_event(self, task_id: str) -> threading.Event:
        with self._task_abort_lock:
            evt = self._task_abort_flags.get(task_id)
            if evt is None:
                evt = threading.Event()
                self._task_abort_flags[task_id] = evt
            return evt

    def _clear_abort_event(self, task_id: str) -> None:
        with self._task_abort_lock:
            self._task_abort_flags.pop(task_id, None)

    def _best_effort_cancel_task(self, task_id: str) -> None:
        """Best-effort cancel call to runtime. Safe to call multiple times."""
        self.log('debug', f'_best_effort_cancel_task: attempting to cancel task {task_id}')
        try:
            self._send_action_server_request(
                'POST',
                f'{self.action_execution_server_url}/actions/{task_id}/cancel',
                timeout=10,
            )
            self.log(
                'debug',
                f'_best_effort_cancel_task: successfully sent cancel request for task {task_id} (/actions/{task_id}/cancel)',
            )
        except httpx.HTTPError as e:
            self.log('error', f'HTTP error during _best_effort_cancel_task for task {task_id}: {e}')
            self.log('debug', f'_best_effort_cancel_task: cancel failed for task {task_id}: {e}')
        except Exception as e:
            self.log('debug', f'_best_effort_cancel_task: cancel failed for task {task_id}: {e}')

    def cancel_task(self, task_id: str) -> None:
        """Public API: request cancellation of a runtime async task.

        This sets a shared abort flag (stops polling immediately) and calls runtime cancel endpoint.
        """
        self.log('info', f'cancel_task: cancelling task {task_id}')
        evt = self._get_or_create_abort_event(task_id)
        evt.set()
        self._best_effort_cancel_task(task_id)

    def cancel_active_task(self) -> None:
        """Cancel currently active async task if one is running."""
        with self._active_task_lock:
            active_tid = self._active_async_task_id
        if active_tid:
            self.log('info', f'cancel_active_task: cancelling active task {active_tid}')
            self.cancel_task(active_tid)
        else:
            self.log('debug', 'cancel_active_task: no active task to cancel')

    def get_running_commands(self) -> dict[str, Any]:
        """Fetch the runtime's running-commands registry (monitoring view)."""
        try:
            response = self._send_action_server_request(
                'GET',
                f'{self.action_execution_server_url}/running_commands',
                timeout=10,
            )
            assert response.is_closed
            out = response.json()
            assert isinstance(out, dict)
            return out
        except Exception as e:
            # Older action servers won't have /running_commands.
            if self._is_404(e):
                self.log('debug', 'get_running_commands: endpoint not found on runtime (older server)')
                return self._default_running_commands_payload()
            raise

    def get_running_command(self, task_id: str) -> dict[str, Any]:
        """Fetch single task status (including terminal states)."""
        try:
            return self._get(f'/running_commands/{task_id}')
        except Exception as e:
            # Endpoint might not exist on older servers; task may also be gone.
            if self._is_404(e):
                self.log('debug', f'get_running_command: task/endpoint not found (task_id={task_id}); returning empty payload')
                return {}
            raise

    def get_workspace_state(self) -> dict[str, Any]:
        """Fetch workspace state (READY/BUSY/... + accepting_user_actions + reason)."""
        try:
            response = self._send_action_server_request(
                'GET',
                f'{self.action_execution_server_url}/workspace_state',
                timeout=10,
            )
            assert response.is_closed
            out = response.json()
            assert isinstance(out, dict)
            return out
        except Exception as e:
            # Older action servers won't have /workspace_state.
            if self._is_404(e):
                self.log('debug', 'get_workspace_state: endpoint not found on runtime (older server)')
                return self._default_workspace_state_payload()
            raise

    def _poll_and_emit_logs(
        self,
        task_id: str,
        action: Action,
        after_seq: int,
    ) -> int:
        """Poll for incremental logs and emit partial observations.

        Args:
            task_id: The task ID to poll logs for
            action: The action being executed
            after_seq: Only fetch logs with seq > after_seq

        Returns:
            The highest sequence number processed, or after_seq if no new logs
        """
        highest_seq = after_seq
        try:
            # Only emit partial observations for CmdRunAction
            if not isinstance(action, CmdRunAction):
                return highest_seq

            logs_response = self._send_action_server_request(
                'GET',
                f'{self.action_execution_server_url}/actions/{task_id}/logs',
                params={'after_seq': after_seq},
                timeout=5,
            )
            if logs_response.status_code != 200:
                return highest_seq

            logs_json = logs_response.json()
            chunks = logs_json.get('chunks', [])

            for chunk in chunks:
                seq = chunk.get('seq', -1)
                content = chunk.get('content', '')

                # Track highest seq for return value
                if seq > highest_seq:
                    highest_seq = seq

                if not content:
                    continue

                # Create partial observation for streaming
                partial_obs = CmdOutputObservation(
                    content=content,
                    command=action.command,
                    is_partial=True,
                )
                partial_obs._cause = action.id  # type: ignore[attr-defined]

                # Emit to event stream for frontend
                self.event_stream.add_event(partial_obs, EventSource.AGENT)
                self.log('debug', f'Emitted partial log for task {task_id}: {len(content)} chars')

        except Exception as e:
            self.log('debug', f'Failed to poll/emit logs for task {task_id}: {e}')

        return highest_seq

    def send_action_for_execution(self, action: Action) -> Observation:
        if (
            isinstance(action, FileEditAction)
            and action.impl_source == FileEditSource.LLM_BASED_EDIT
        ):
            return self.llm_based_edit(action)

        # set timeout to default if not set
        if action.timeout is None:
            if isinstance(action, CmdRunAction) and action.blocking:
                raise RuntimeError('Blocking command with no timeout set')
            # We don't block the command if this is a default timeout action
            action.set_hard_timeout(self.config.sandbox.timeout, blocking=False)

        with self.action_semaphore:
            if not action.runnable:
                if isinstance(action, AgentThinkAction):
                    return AgentThinkObservation('Your thought has been logged.')
                return NullObservation('')
            if (
                hasattr(action, 'confirmation_state')
                and action.confirmation_state
                == ActionConfirmationStatus.AWAITING_CONFIRMATION
            ):
                return NullObservation('')
            raw_action_type = getattr(action, 'action', type(action).__name__)  # type: ignore[attr-defined]
            action_type = (
                raw_action_type.value if isinstance(raw_action_type, Enum) else str(raw_action_type)
            )
            if action_type not in ACTION_TYPE_TO_CLASS:
                raise ValueError(f'Action {action_type} does not exist.')
            if not hasattr(self, action_type):
                return ErrorObservation(
                    f'Action {action_type} is not supported in the current runtime.',
                    error_id='AGENT_ERROR$BAD_ACTION',
                )
            if (
                getattr(action, 'confirmation_state', None)
                == ActionConfirmationStatus.REJECTED
            ):
                return UserRejectObservation(
                    'Action has been rejected by the user! Waiting for further user input.'
                )

            assert action.timeout is not None

            # Using async-capable execution path with backward compatibility
            try:
                execution_action_body: dict[str, Any] = {
                    'action': event_to_dict(action),
                    'async_execution': True,
                }
                request_timeout = action.timeout + 10

                # Requesting async execution via header; backward compatible with runtimes that don't support it
                response = self._send_action_server_request(
                    'POST',
                    f'{self.action_execution_server_url}/execute_action',
                    json=execution_action_body,
                    timeout=request_timeout,
                    headers={'X-Async-Execution': 'true'},
                )
                assert response.is_closed
                output = response.json()

                # If the server returns a task_id, it's using the async execution path
                task_id: str | None = None
                if isinstance(output, dict):
                    task_id = output.get('task_id')

                # New Runtime
                if task_id:
                    initial_status = output.get('status')
                    self.log(
                        'info',
                        f'Async runtime accepted action {action.id}: task_id={task_id}, initial_status={initial_status}',
                    )
                    return self._poll_async_task(
                        task_id=task_id,
                        action=action,
                        request_timeout=request_timeout,
                    )

                # Backward compatible path for runtimes that don't support async execution
                obs = observation_from_dict(output)
                obs._cause = action.id  # type: ignore[attr-defined]
                return obs

            except httpx.TimeoutException:
                # return a recoverable observation rather than raising,
                # to avoid surfacing this as an unhandled exception in the chat UI.
                timeout_obs = ErrorObservation(
                    (
                        f'Runtime did not return execute_action within the requested timeout of {action.timeout}s. '
                        'Please double check the task. If this timeout is too small, consider increasing it and retrying.'
                    ),
                    error_id='AGENT_ERROR$RUNTIME_EXECUTE_ACTION_TIMEOUT',
                )
                timeout_obs._cause = action.id  # type: ignore[attr-defined]
                return timeout_obs


    def run(self, action: CmdRunAction) -> Observation:
        return self.send_action_for_execution(action)

    def run_ipython(self, action: IPythonRunCellAction) -> Observation:
        return self.send_action_for_execution(action)

    def read(self, action: FileReadAction) -> Observation:
        return self.send_action_for_execution(action)

    def write(self, action: FileWriteAction) -> Observation:
        return self.send_action_for_execution(action)

    def edit(self, action: FileEditAction) -> Observation:
        return self.send_action_for_execution(action)

    def browse(self, action: BrowseURLAction) -> Observation:
        return self.send_action_for_execution(action)

    def browse_interactive(self, action: BrowseInteractiveAction) -> Observation:
        return self.send_action_for_execution(action)

    def get_mcp_config(
        self, extra_stdio_servers: list[MCPStdioServerConfig] | None = None
    ) -> MCPConfig:
        import sys

        # Check if we're on Windows - MCP is disabled on Windows
        if sys.platform == 'win32':
            # Return empty MCP config on Windows
            self.log('debug', 'MCP is disabled on Windows, returning empty config')
            return MCPConfig(sse_servers=[], stdio_servers=[])

        # Add the runtime as another MCP server
        updated_mcp_config = self.config.mcp.model_copy()

        # Get current stdio servers
        current_stdio_servers: list[MCPStdioServerConfig] = list(
            updated_mcp_config.stdio_servers
        )
        if extra_stdio_servers:
            current_stdio_servers.extend(extra_stdio_servers)

        # Check if there are any new servers using the __eq__ operator
        new_servers = [
            server
            for server in current_stdio_servers
            if server not in self._last_updated_mcp_stdio_servers
        ]

        self.log(
            'debug',
            f'adding {len(new_servers)} new stdio servers to MCP config: {new_servers}',
        )

        # Only send update request if there are new servers
        if new_servers:
            # Use a union of current servers and last updated servers for the update
            # This ensures we don't lose any servers that might be missing from either list
            combined_servers = current_stdio_servers.copy()
            for server in self._last_updated_mcp_stdio_servers:
                if server not in combined_servers:
                    combined_servers.append(server)

            stdio_tools = [
                server.model_dump(mode='json') for server in combined_servers
            ]
            stdio_tools.sort(key=lambda x: x.get('name', ''))  # Sort by server name

            self.log(
                'debug',
                f'Updating MCP server with {len(new_servers)} new stdio servers (total: {len(combined_servers)})',
            )
            try:
                response = self._send_action_server_request(
                    'POST',
                    f'{self.action_execution_server_url}/update_mcp_server',
                    json=stdio_tools,
                    timeout=60,
                )
                result = response.json()
                if response.status_code != 200:
                    self.log('warning', f'Failed to update MCP server: {response.text}')
                else:
                    if isinstance(result, dict) and result.get('router_error_log'):
                        self.log(
                            'warning',
                            f'Some MCP servers failed to be added: {result["router_error_log"]}',
                        )

                    # Update our cached list with combined servers after successful update
                    self._last_updated_mcp_stdio_servers = combined_servers.copy()
                    self.log(
                        'debug',
                        f'Successfully updated MCP stdio servers, now tracking {len(combined_servers)} servers',
                    )
                self.log(
                    'info',
                    f'Updated MCP config: {updated_mcp_config.sse_servers}',
                )
            except httpx.HTTPError as e:
                # Optional endpoint; older action servers may not provide MCP updates.
                if self._is_404(e):
                    self.log('debug', 'update_mcp_server: endpoint not found on runtime (older server); skipping update')
                else:
                    raise
        else:
            self.log('debug', 'No new stdio servers to update')

        if len(self._last_updated_mcp_stdio_servers) > 0:
            # We should always include the runtime as an MCP server whenever there's > 0 stdio servers
            updated_mcp_config.sse_servers.append(
                MCPSSEServerConfig(
                    url=self.action_execution_server_url.rstrip('/') + '/sse',
                    api_key=self.session_api_key,
                )
            )

        return updated_mcp_config

    async def call_tool_mcp(self, action: MCPAction) -> Observation:
        import sys

        from openhands.events.observation import ErrorObservation

        # Check if we're on Windows - MCP is disabled on Windows
        if sys.platform == 'win32':
            self.log('info', 'MCP functionality is disabled on Windows')
            return ErrorObservation('MCP functionality is not available on Windows')

        # Import here to avoid circular imports
        from openhands.mcp.utils import call_tool_mcp as call_tool_mcp_handler
        from openhands.mcp.utils import create_mcp_clients

        # Get the updated MCP config
        updated_mcp_config = self.get_mcp_config()
        self.log(
            'debug',
            f'Creating MCP clients with servers: {updated_mcp_config.sse_servers}',
        )

        # Create clients for this specific operation
        mcp_clients = await create_mcp_clients(
            updated_mcp_config.sse_servers, updated_mcp_config.shttp_servers, self.sid
        )

        # Call the tool and return the result
        # No need for try/finally since disconnect() is now just resetting state
        result = await call_tool_mcp_handler(mcp_clients, action)
        return result

    def update_idle_life(self, idle_life: int) -> None:
        """Update the idle_life setting in the runtime."""
        try:
            self._send_action_server_request(
                'POST',
                f'{self.action_execution_server_url}/idle_life',
                json={'idle_life': idle_life},
                timeout=5,
            )
        except Exception as e:
            # Optional endpoint for newer runtimes.
            if self._is_404(e):
                self.log('debug', 'update_idle_life: endpoint not found on runtime (older server)')
                return
            raise

    def close(self) -> None:
        # Make sure we don't close the session multiple times
        # Can happen in evaluation
        if self._runtime_closed:
            return
        self._runtime_closed = True
        self.session.close()
