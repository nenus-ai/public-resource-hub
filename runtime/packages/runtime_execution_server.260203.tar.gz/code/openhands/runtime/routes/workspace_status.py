import time
from collections.abc import Awaitable, Callable
from typing import Any

from fastapi import APIRouter, HTTPException


def create_workspace_status_router(
    *,
    get_workspace_state_payload: Callable[[], Awaitable[dict[str, Any]]],
    list_active_commands: Callable[[], Awaitable[list[Any]]],
    get_session_pool_summary: Callable[[], Awaitable[dict[str, Any]]],
    get_registry_entry: Callable[[str], Awaitable[Any]],
) -> APIRouter:
    """Create a router for workspace status + running command monitoring."""

    router = APIRouter()

    @router.get('/workspace_state')
    async def workspace_state():
        return await get_workspace_state_payload()

    @router.get('/running_commands')
    async def running_commands():
        active = await list_active_commands()
        summary = await get_session_pool_summary()
        max_size = summary.get('max_size', 5)
        return {
            'running_commands': active,
            'max_slots': max_size,
        }

    @router.get('/running_commands/{task_id}')
    async def get_running_command(task_id: str):
        """Lightweight status endpoint: reads registry only (no tmux)."""
        entry = await get_registry_entry(task_id)
        if entry is None:
            raise HTTPException(status_code=404, detail='Task not found')

        d = entry.model_dump()
        try:
            d['duration_seconds'] = max(0.0, time.time() - entry.start_time)
        except Exception:
            pass
        return d

    return router
