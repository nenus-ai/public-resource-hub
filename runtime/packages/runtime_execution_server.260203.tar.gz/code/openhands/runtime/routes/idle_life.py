from __future__ import annotations

from typing import Callable

from fastapi import APIRouter, HTTPException, Request

from openhands.runtime.action_execution.executor.executor import ActionExecutor


def create_idle_life_router(*, get_client: Callable[[], ActionExecutor | None]) -> APIRouter:
    router = APIRouter()

    @router.post('/idle_life')
    async def update_idle_life(request: Request):
        """Update the idle_life setting at runtime.

        This endpoint allows the runtime to update its idle timeout dynamically.
        """
        client = get_client()
        assert client is not None
        try:
            body = await request.json()
            idle_life = body.get('idle_life')
            if idle_life is None:
                raise HTTPException(
                    status_code=400, detail='Missing required field: idle_life'
                )
            client.update_idle_life(int(idle_life))
            return {'status': 'ok', 'idle_life': client.idle_life}
        except ValueError:
            raise HTTPException(status_code=400, detail='idle_life must be an integer')

    return router
