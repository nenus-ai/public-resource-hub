import os
import shutil
import tempfile
from collections.abc import Callable
from typing import Any, Optional
from zipfile import ZipFile

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from starlette.background import BackgroundTask

from openhands.core.logger import openhands_logger as logger
from openhands.runtime.action_execution.executor.executor import ActionExecutor


def create_file_manager_router(
    get_client: Callable[[], Optional[ActionExecutor]],
) -> APIRouter:
    """Create a router for file manager operations under the workspace.

    This exposes the `/file_manager/*` endpoints used by the UI. All paths are
    constrained to stay within `client.initial_cwd`.
    """

    router = APIRouter()

    def _resolve_under_workspace(p: str | None) -> str:
        """Resolve a user-provided path to an absolute path under the workspace.

        Supports absolute paths and paths relative to initial_cwd.
        Enforces traversal safety by requiring the resolved realpath to be within initial_cwd.
        """
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')
        base = os.path.realpath(client.initial_cwd)
        if p is None or p == '' or p == '.':
            resolved = base
        else:
            candidate = p if os.path.isabs(p) else os.path.join(base, p)
            resolved = os.path.realpath(candidate)

        if not (resolved == base or resolved.startswith(base + os.sep)):
            raise HTTPException(
                status_code=400, detail='Path must be within the workspace'
            )
        return resolved

    def _safe_unlink(p: str) -> None:
        try:
            os.unlink(p)
        except FileNotFoundError:
            pass
        except Exception:
            logger.exception('Failed to delete temp download file: %s', p)

    @router.post('/file_manager/list')
    async def fm_list(request: Request):
        """List files/folders with metadata under the workspace."""
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')
        client.start_idle_timer()

        body = await request.json()
        path = body.get('path', None)

        logger.debug('Action server fm_list: path=%s', path or '/')
        full_path = _resolve_under_workspace(path)
        if not os.path.exists(full_path) or not os.path.isdir(full_path):
            logger.debug(
                'Action server fm_list: path does not exist or is not a directory: %s',
                full_path,
            )
            return JSONResponse(content={'entries': [], 'path': path or ''})

        entries: list[dict[str, Any]] = []
        try:
            with os.scandir(full_path) as it:
                for entry in it:
                    try:
                        is_dir = entry.is_dir(follow_symlinks=False)
                        # Avoid calling stat() for directories to reduce I/O overhead,
                        # especially on slow or networked filesystems. Only files need
                        # full metadata (size, mtime) for the UI.
                        st = None if is_dir else entry.stat(follow_symlinks=False)
                        entries.append(
                            {
                                'name': entry.name,
                                'path': os.path.relpath(entry.path, client.initial_cwd),
                                'is_dir': is_dir,
                                'size': 0
                                if is_dir
                                else int(st.st_size if st is not None else 0),
                                'modified': int(st.st_mtime) if st is not None else 0,
                            }
                        )
                    except FileNotFoundError:
                        continue
        except Exception as e:
            logger.error(
                'Action server fm_list failed: path=%s, error=%s', path, str(e)
            )
            raise HTTPException(status_code=500, detail=str(e))

        logger.debug('Action server fm_list: returning %d entries', len(entries))
        return JSONResponse(content={'entries': entries, 'path': path or ''})

    @router.post('/file_manager/mkdir')
    async def fm_mkdir(request: Request):
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')
        client.start_idle_timer()

        body = await request.json()
        path = body.get('path')
        if not isinstance(path, str) or path.strip() == '':
            raise HTTPException(status_code=400, detail='Missing required field: path')

        logger.debug('Action server fm_mkdir: path=%s', path)
        full_path = _resolve_under_workspace(path)
        try:
            os.makedirs(full_path, exist_ok=False)
            logger.info('Action server fm_mkdir: created directory %s', path)
        except FileExistsError:
            logger.warning('Action server fm_mkdir: directory already exists: %s', path)
            raise HTTPException(status_code=409, detail='Folder already exists')
        except Exception as e:
            logger.error(
                'Action server fm_mkdir failed: path=%s, error=%s', path, str(e)
            )
            raise HTTPException(status_code=500, detail=str(e))
        return {'status': 'ok'}

    @router.post('/file_manager/delete')
    async def fm_delete(request: Request):
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')
        client.start_idle_timer()

        body = await request.json()
        path = body.get('path')
        recursive = bool(body.get('recursive', False))
        if not isinstance(path, str) or path.strip() == '':
            raise HTTPException(status_code=400, detail='Missing required field: path')

        logger.debug('Action server fm_delete: path=%s, recursive=%s', path, recursive)
        full_path = _resolve_under_workspace(path)
        base = os.path.realpath(client.initial_cwd)
        if os.path.realpath(full_path) == base:
            logger.warning(
                'Action server fm_delete: attempted to delete workspace root'
            )
            raise HTTPException(
                status_code=400, detail='Refusing to delete workspace root'
            )

        if not os.path.exists(full_path):
            logger.warning('Action server fm_delete: path not found: %s', path)
            raise HTTPException(status_code=404, detail='Not found')

        try:
            if os.path.isdir(full_path):
                if recursive:
                    shutil.rmtree(full_path)
                else:
                    os.rmdir(full_path)
            else:
                os.remove(full_path)
            logger.info(
                'Action server fm_delete: deleted %s (recursive=%s)', path, recursive
            )
        except OSError as e:
            logger.error(
                'Action server fm_delete failed: path=%s, error=%s', path, str(e)
            )
            raise HTTPException(status_code=400, detail=str(e))
        except Exception as e:
            logger.error(
                'Action server fm_delete failed: path=%s, error=%s', path, str(e)
            )
            raise HTTPException(status_code=500, detail=str(e))
        return {'status': 'ok'}

    @router.post('/file_manager/move')
    async def fm_move(request: Request):
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')
        client.start_idle_timer()

        body = await request.json()
        src = body.get('src')
        dest = body.get('dest')
        if not isinstance(src, str) or src.strip() == '':
            raise HTTPException(status_code=400, detail='Missing required field: src')
        if not isinstance(dest, str) or dest.strip() == '':
            raise HTTPException(status_code=400, detail='Missing required field: dest')

        logger.debug('Action server fm_move: src=%s, dest=%s', src, dest)
        full_src = _resolve_under_workspace(src)
        full_dest = _resolve_under_workspace(dest)

        base = os.path.realpath(client.initial_cwd)
        if os.path.realpath(full_src) == base or os.path.realpath(full_dest) == base:
            logger.warning('Action server fm_move: attempted to move workspace root')
            raise HTTPException(
                status_code=400, detail='Refusing to move workspace root'
            )

        if not os.path.exists(full_src):
            logger.warning('Action server fm_move: source not found: %s', src)
            raise HTTPException(status_code=404, detail='Source not found')

        dest_parent = os.path.dirname(full_dest)
        if dest_parent and not os.path.exists(dest_parent):
            os.makedirs(dest_parent, exist_ok=True)

        try:
            shutil.move(full_src, full_dest)
            logger.info('Action server fm_move: moved %s -> %s', src, dest)
        except Exception as e:
            logger.error(
                'Action server fm_move failed: src=%s, dest=%s, error=%s',
                src,
                dest,
                str(e),
            )
            raise HTTPException(status_code=500, detail=str(e))
        return {'status': 'ok'}

    @router.get('/file_manager/download')
    async def fm_download(path: str):
        """Download a file (raw) or a folder (zipped)."""
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')
        client.start_idle_timer()

        logger.debug('Action server fm_download: path=%s', path)
        full_path = _resolve_under_workspace(path)
        if not os.path.exists(full_path):
            logger.warning('Action server fm_download: path not found: %s', path)
            raise HTTPException(status_code=404, detail='File not found')

        if os.path.isfile(full_path):
            filename = os.path.basename(full_path)
            file_size = os.path.getsize(full_path)
            logger.info(
                'Action server fm_download: downloading file %s, size=%d',
                filename,
                file_size,
            )
            return FileResponse(path=full_path, filename=filename)

        if os.path.isdir(full_path):
            try:
                base_dir_real = os.path.realpath(full_path)
                with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as temp_zip:
                    with ZipFile(temp_zip, 'w') as zipf:
                        file_count = 0
                        skipped_links = 0
                        for root, _, files in os.walk(full_path):
                            for file in files:
                                file_path = os.path.join(root, file)

                                # Never include symlinks in zips: ZipFile.write would
                                # follow the link and include the target's contents.
                                try:
                                    if os.path.islink(file_path):
                                        skipped_links += 1
                                        continue
                                except OSError:
                                    # If we can't stat it reliably, skip.
                                    continue

                                # Belt-and-suspenders: ensure the real path stays under
                                # the directory being downloaded (defends against
                                # hardlinks/mount tricks and race-y changes).
                                real_file = os.path.realpath(file_path)
                                if not (
                                    real_file == base_dir_real
                                    or real_file.startswith(base_dir_real + os.sep)
                                ):
                                    skipped_links += 1
                                    continue

                                zipf.write(
                                    file_path,
                                    arcname=os.path.relpath(file_path, full_path),
                                )
                                file_count += 1
                    zip_size = os.path.getsize(temp_zip.name)
                    logger.info(
                        'Action server fm_download: created zip for directory %s, files=%d, skipped=%d, size=%d',
                        os.path.basename(full_path),
                        file_count,
                        skipped_links,
                        zip_size,
                    )
                return FileResponse(
                    path=temp_zip.name,
                    media_type='application/zip',
                    filename=f'{os.path.basename(full_path)}.zip',
                    background=BackgroundTask(_safe_unlink, temp_zip.name),
                )
            except Exception as e:
                logger.error(
                    'Action server fm_download failed: path=%s, error=%s', path, str(e)
                )
                raise HTTPException(status_code=500, detail=str(e))

        raise HTTPException(status_code=400, detail='Unsupported path type')

    return router
