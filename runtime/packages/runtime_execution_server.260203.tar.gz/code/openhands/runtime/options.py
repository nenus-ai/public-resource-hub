from enum import Enum
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class AccessMode(str, Enum):
    """Enumeration for access modes"""

    READ = 'r'
    READ_WRITE = 'rw'
    WRITE = 'w'  # Added write-only if needed


class RuntimeOptions(BaseModel):
    """Options model for runtime configuration"""

    model_config = ConfigDict(
        use_enum_values=True,
        json_schema_extra={
            'examples': [
                {
                    'runtime_container_image': 'python:3.9-slim',
                    'access_mode': 'rw',
                    'memory_limit': '1g',
                    'cpu_limit': 1.0,
                    'environment_vars': {'DEBUG': 'true', 'LOG_LEVEL': 'info'},
                    'timeout_seconds': 300,
                }
            ]
        },
    )

    runtime_container_image: str = Field(
        ...,
        description='Docker/container image to use for runtime',
        examples=['python:3.9-slim', 'node:16-alpine'],
    )

    access_mode: AccessMode = Field(
        default=AccessMode.READ,
        description='Access mode for resources (r: read-only, rw: read-write)',
    )

    # Additional optional fields you might want
    memory_limit: Optional[str] = Field(
        default=None,
        description="Memory limit for the container (e.g., '512m', '2g')",
        examples=['512m', '1g', '2g'],
    )

    cpu_limit: Optional[float] = Field(
        default=None,
        description='CPU limit for the container (e.g., 0.5, 1.0, 2.0)',
        ge=0.1,
        le=32.0,  # Increased to match our maximum CPU limit
    )

    environment_vars: dict[str, str] = Field(
        default_factory=dict,
        description='Environment variables to pass to the container',
    )

    timeout_seconds: int = Field(
        default=300, description='Timeout for operations in seconds', ge=1, le=3600
    )

    gpu_count: Optional[int] = Field(
        default=None,
        description='Number of GPUs to allocate to the container',
        ge=0,
        le=8,
    )

    # Field validators (Pydantic v2 style)
    @field_validator('runtime_container_image')
    @classmethod
    def validate_image_name(cls, v: str) -> str:
        """Validate container image format"""
        if not v or v.isspace():
            raise ValueError('Container image cannot be empty')
        # Basic validation - you can make this more sophisticated
        if ':' not in v and '/' not in v:
            raise ValueError('Container image should include registry/name:tag format')
        return v

    @field_validator('memory_limit')
    @classmethod
    def validate_memory_limit(cls, v: Optional[str]) -> Optional[str]:
        """Validate memory limit format"""
        if v is None:
            return v

        import re

        pattern = r'^\d+[kmgKMG]?$'
        if not re.match(pattern, v):
            raise ValueError(
                "Memory limit must be in format like '512m', '2g', '1024k'"
            )
        return v

    # Model serialization helpers (Pydantic v2 style)
    def model_dump_json_custom(self) -> str:
        """Custom JSON serialization if needed"""
        return self.model_dump_json(indent=2)


# Alternative simplified version if you only need the basics
class SimpleOptions(BaseModel):
    """Simplified options model with just the essentials"""

    runtime_container_image: str
    access_mode: Literal['r', 'rw'] = 'r'


# Example usage with Pydantic v2
def process_data(data: Any, options: RuntimeOptions) -> Any:
    """Example function using the options model"""
    print(f'Processing with image: {options.runtime_container_image}')
    print(f'Access mode: {options.access_mode}')

    if options.access_mode == AccessMode.READ:
        print('Read-only mode - no modifications allowed')
    elif options.access_mode == AccessMode.READ_WRITE:
        print('Read-write mode - modifications allowed')

    # Pass options down to other functions
    result = sub_process(data, options)
    return result


def sub_process(data: Any, options: RuntimeOptions) -> Any:
    """Sub-function that receives the same options"""
    # Access options properties
    if options.memory_limit:
        print(f'Memory limit set to: {options.memory_limit}')

    return data


# Example instantiation and usage
if __name__ == '__main__':
    # Create options instance
    options = RuntimeOptions(
        runtime_container_image='python:3.9-alpine',
        access_mode='rw',
        memory_limit='512m',
        cpu_limit=1.5,
        environment_vars={'APP_ENV': 'production'},
    )

    # Convert to dict (Pydantic v2 method)
    print(options.model_dump())

    # JSON serialization (Pydantic v2 method)
    print(options.model_dump_json(indent=2))

    # Use in function
    process_data({'test': 'data'}, options)

    # Create from dict
    options_dict = {'runtime_container_image': 'node:16-slim', 'access_mode': 'r'}
    options_from_dict = RuntimeOptions(**options_dict)
    print(options_from_dict)

    # Model validation (Pydantic v2)
    from pydantic import ValidationError

    try:
        # This will fail validation
        bad_options = RuntimeOptions(
            runtime_container_image='invalid_image', access_mode='invalid'
        )
    except ValidationError as e:
        print(f'Validation error: {e}')

    # Create model with validated data (Pydantic v2)
    validated_options = RuntimeOptions.model_validate(
        {
            'runtime_container_image': 'python:3.11',
            'access_mode': 'rw',
            'memory_limit': '2g',
        }
    )
    print(validated_options)
