import os
from typing import MutableMapping

from openhands.core.logger import openhands_logger as logger

VolumeSpec = dict[str, str]
Volumes = MutableMapping[str, VolumeSpec]


def get_runtime_source_path_env() -> str | None:
    """Prefer uppercase env var for convention; keep lowercase for backwards compat."""
    return os.environ.get("RUNTIME_SOURCE_PATH") or os.environ.get("runtime_source_path")


def apply_runtime_source_mount(
    volumes: Volumes,
    runtime_source_path: str,
    *,
    require_abs: bool = False,
    resolve_abspath: bool = True,
    validate_dir_if_exists: bool = True,
    allow_nonexistent: bool = False,
    bind_path: str = "/kepilot/code",
    mode: str = "rw",
) -> None:
    """
    Applies a bind mount of runtime_source_path -> bind_path (rw) into volumes.

    - Removes any existing mount targeting bind_path to avoid duplicate mount point errors.
    - Optionally requires an absolute path (useful for remote runtime).
    - Validates directory-ness when path exists locally.
    - For remote runtime, can allow_nonexistent=True (path must exist on remote host).
    """
    if require_abs and not os.path.isabs(runtime_source_path):
        logger.warning(
            f"RUNTIME_SOURCE_PATH must be an absolute path; got relative path: {runtime_source_path!r}. "
            f"Skipping runtime source mount."
        )
        return

    host_path = os.path.abspath(runtime_source_path) if resolve_abspath else runtime_source_path

    # Validate the path first before removing conflicting mounts
    if os.path.exists(host_path):
        if validate_dir_if_exists and not os.path.isdir(host_path):
            logger.warning(
                f"RUNTIME_SOURCE_PATH is set but is not a directory: {host_path}. Skipping runtime source mount."
            )
            return
    elif not allow_nonexistent:
        logger.warning(
            f"RUNTIME_SOURCE_PATH is set but does not exist: {host_path}. Skipping runtime source mount."
        )
        return

    # Remove any existing mounts to the same container path to avoid Docker rejecting start.
    conflicting = [
        hp
        for hp, spec in volumes.items()
        if isinstance(spec, dict) and spec.get("bind") == bind_path
    ]
    for hp in conflicting:
        logger.warning(
            f"Removing existing {bind_path} mount from volumes (host={hp}) to apply RUNTIME_SOURCE_PATH override."
        )
        volumes.pop(hp, None)

    # Add the mount
    volumes[host_path] = {"bind": bind_path, "mode": mode}

    if os.path.exists(host_path):
        logger.info(f"Mounting runtime source (RUNTIME_SOURCE_PATH): {host_path} -> {bind_path} ({mode})")
    else:
        # Remote runtime case: allow mount even if not present on this machine.
        logger.warning(
            f"RUNTIME_SOURCE_PATH is set to {host_path} but path does not exist on this host; "
            f"remote runtime will attempt to mount it on the runtime host."
        )
