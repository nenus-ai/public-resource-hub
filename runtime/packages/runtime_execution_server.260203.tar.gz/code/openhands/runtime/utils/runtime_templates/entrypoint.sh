#! /bin/bash

# Simple entrypoint script that delegates to start.sh for all upgrade logic
# This script's sole purpose is to:
# 1. Download start.sh from remote (or use local if OAIS_USE_LOCAL_STARTSH=true)
# 2. Execute start.sh

STARTSH_PATH="/opt/runtime/bootstrap/start.sh"
REMOTE_STARTSH_URL="https://raw.githubusercontent.com/nenus-ai/public-resource-hub/refs/heads/master/runtime/bootstrap/start.sh"

# Check if we should use local start.sh (default is false, always download)
USE_LOCAL_STARTSH="${OAIS_USE_LOCAL_STARTSH:-false}"

echo "Entrypoint: Checking for start.sh..."

# By default, always download start.sh from remote since it's not stable yet
# Set OAIS_USE_LOCAL_STARTSH=true to use local cached version (only if it exists)
if [ "$USE_LOCAL_STARTSH" = "true" ] && [ -f "$STARTSH_PATH" ]; then
    echo "Entrypoint: Using local start.sh at $STARTSH_PATH (OAIS_USE_LOCAL_STARTSH=true)"
    echo "Entrypoint: Executing start.sh..."
    exec bash "$STARTSH_PATH"
else
    echo "Entrypoint: Downloading start.sh from remote..."
    
    # Create directory if it doesn't exist
    mkdir -p /opt/runtime/bootstrap
    
    # Download start.sh from remote
    if curl -fsSL --max-time 10 -o "$STARTSH_PATH" "$REMOTE_STARTSH_URL?$(date +%s)" 2>&1; then
        chmod +x "$STARTSH_PATH"
        echo "Entrypoint: Successfully downloaded start.sh from remote"
        echo "Entrypoint: Executing start.sh..."
        exec bash "$STARTSH_PATH"
    else
        echo "Entrypoint: ERROR - Failed to download start.sh from remote"
        
        # Fall back to local cached version if it exists (could be stale but better than nothing)
        if [ -f "$STARTSH_PATH" ]; then
            echo "Entrypoint: Falling back to local cached start.sh"
            exec bash "$STARTSH_PATH"
        else
            echo "Entrypoint: Cannot proceed without start.sh"
            exit 1
        fi
    fi
fi
