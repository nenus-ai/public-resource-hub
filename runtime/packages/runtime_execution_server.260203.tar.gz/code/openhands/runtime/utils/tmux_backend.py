from __future__ import annotations

import subprocess
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@dataclass(frozen=True)
class TmuxState:
    server: Any
    session: Any
    window: Any
    pane: Any
    pane_id: str | None
    session_name: str | None


@runtime_checkable
class TmuxBackend(Protocol):
    def start_session(
        self,
        *,
        session_name: str,
        start_directory: str,
        window_name: str,
        window_shell: str,
        history_limit: int,
        x: int,
        y: int,
    ) -> TmuxState: ...

    def kill_session(self, session: Any) -> None: ...

    def capture_pane(
        self,
        *,
        window: Any | None,
        pane: Any,
        pane_id: str | None,
    ) -> str: ...

    def send_keys(self, pane: Any, keys: str, *, enter: bool = True) -> None: ...

    def clear_history(self, pane: Any) -> None: ...

    def display_message(self, pane: Any, *, format_str: str) -> str | None: ...

    def is_healthy(self, *, pane_id: str | None, session_name: str | None) -> bool: ...


class LibTmuxBackend:
    """Thin wrapper around libtmux + tmux CLI health checks.

    The goal is to isolate all tmux/libtmux/subprocess details from higher-level
    session logic (e.g. BashSession).
    """

    def __init__(self):
        self._import_error: Exception | None = None
        try:
            import libtmux  # type: ignore

            self._libtmux = libtmux
        except Exception as e:  # pragma: no cover
            self._libtmux = None
            self._import_error = e
        else:
            self._import_error = None

    def start_session(
        self,
        *,
        session_name: str,
        start_directory: str,
        window_name: str,
        window_shell: str,
        history_limit: int,
        x: int,
        y: int,
    ) -> TmuxState:
        if self._libtmux is None:  # pragma: no cover
            raise RuntimeError(
                "libtmux is required to start tmux sessions"
            ) from self._import_error

        server = self._libtmux.Server()
        session = server.new_session(
            session_name=session_name,
            start_directory=start_directory,
            kill_session=True,
            x=x,
            y=y,
        )

        # Set history limit to a large number to avoid losing history.
        session.set_option('history-limit', str(history_limit), _global=True)
        session.history_limit = history_limit

        # Create a new window (the initial window's history limit often differs).
        initial_window = session.active_window
        window = session.new_window(
            window_name=window_name,
            window_shell=window_shell,
            start_directory=start_directory,
        )
        pane = window.active_pane

        try:
            pane_id = getattr(pane, 'pane_id', None)
        except Exception:
            pane_id = None

        try:
            initial_window.kill_window()
        except Exception:
            # Best-effort; the window may already be gone.
            pass

        return TmuxState(
            server=server,
            session=session,
            window=window,
            pane=pane,
            pane_id=pane_id,
            session_name=session_name,
        )

    def kill_session(self, session: Any) -> None:
        session.kill_session()

    def capture_pane(
        self,
        *,
        window: Any | None,
        pane: Any,
        pane_id: str | None,
    ) -> str:
        pane_obj = pane
        if pane_id and window is not None:
            try:
                pane_obj = window.get_by_id(pane_id)
            except Exception:
                pane_obj = pane

        # Match prior behavior: join lines and rstrip each line.
        return '\n'.join(
            line.rstrip()
            for line in pane_obj.cmd('capture-pane', '-J', '-pS', '-').stdout
        )

    def send_keys(self, pane: Any, keys: str, *, enter: bool = True) -> None:
        pane.send_keys(keys, enter=enter)

    def clear_history(self, pane: Any) -> None:
        pane.cmd('clear-history')

    def display_message(self, pane: Any, *, format_str: str) -> str | None:
        out = pane.cmd('display-message', '-p', format_str).stdout
        msg = (out[0] if out else '').strip()
        return msg or None

    def is_healthy(self, *, pane_id: str | None, session_name: str | None) -> bool:
        try:
            if pane_id:
                res = subprocess.run(
                    [
                        'tmux',
                        'display-message',
                        '-p',
                        '-t',
                        str(pane_id),
                        '#S',
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=0.5,
                )
                return res.returncode == 0

            if session_name:
                res = subprocess.run(
                    ['tmux', 'has-session', '-t', str(session_name)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=0.5,
                )
                return res.returncode == 0

            return False
        except subprocess.TimeoutExpired:
            return False
        except Exception:
            return False
