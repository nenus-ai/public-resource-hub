"""Action Execution Server (runtime-side).

This package contains the refactored implementation that used to live in
`openhands.runtime.action_execution_server`.

`openhands.runtime.action_execution_server` remains as the stable entrypoint.
"""
