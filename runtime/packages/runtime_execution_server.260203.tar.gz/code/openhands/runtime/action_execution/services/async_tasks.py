from __future__ import annotations

import asyncio
from collections.abc import Callable
import threading
import time
import traceback
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, TYPE_CHECKING

from fastapi import HTTPException

from openhands.core.logger import openhands_logger as logger
from openhands.events.action import Action, CmdRunAction
from openhands.events.observation import CmdOutputObservation, Observation
from openhands.events.serialization import event_to_dict
from openhands.runtime.model.running_commands import RunningCommandStatus

if TYPE_CHECKING:
    from openhands.runtime.action_execution.monitoring.registry import RunningCommandRegistry
    from openhands.runtime.action_execution.executor.executor import ActionExecutor


class AsyncTaskStatus(str, Enum):
    PENDING = 'pending'
    RUNNING = 'running'
    STOPPING = 'stopping'
    COMPLETED = 'completed'
    FAILED = 'failed'
    CANCELLED = 'cancelled'


@dataclass
class LogChunk:
    """Represents a chunk of incremental log output."""

    seq: int
    content: str
    timestamp: float


@dataclass
class AsyncActionTaskState:
    """Represents the state of a single asynchronous execution."""

    task_id: str
    session_id: str | None = None
    slot_id: str | None = None
    status: AsyncTaskStatus = AsyncTaskStatus.PENDING
    result: Observation | None = None
    error: str | None = None
    created_at: float = field(default_factory=time.time)
    started_at: float | None = None
    completed_at: float | None = None
    cancel_requested: bool = False
    cancel_requested_at: float | None = None

    log_chunks: list[LogChunk] = field(default_factory=list)
    _log_lock: threading.Lock = field(default_factory=threading.Lock)
    _next_seq: int = 0
    _max_log_chunks: int = 1000

    def add_log_chunk(self, content: str) -> None:
        with self._log_lock:
            chunk = LogChunk(seq=self._next_seq, content=content, timestamp=time.time())
            self.log_chunks.append(chunk)
            self._next_seq += 1
            if len(self.log_chunks) > self._max_log_chunks:
                self.log_chunks = self.log_chunks[-self._max_log_chunks :]

    def get_logs_after(self, after_seq: int) -> list[LogChunk]:
        with self._log_lock:
            return [c for c in self.log_chunks if c.seq > after_seq]


class AsyncTaskStore:
    """Simple in-memory store for async action tasks."""

    def __init__(self) -> None:
        self._tasks: dict[str, AsyncActionTaskState] = {}

    def create_task(self, session_id: str | None) -> AsyncActionTaskState:
        task_id = str(uuid.uuid4())
        state = AsyncActionTaskState(task_id=task_id, session_id=session_id)
        self._tasks[task_id] = state
        return state

    def get_task(self, task_id: str) -> AsyncActionTaskState | None:
        return self._tasks.get(task_id)

    def update_task(self, state: AsyncActionTaskState) -> None:
        self._tasks[state.task_id] = state

    def delete_task(self, task_id: str) -> None:
        self._tasks.pop(task_id, None)

    def list_task_ids(self) -> list[str]:
        """Return a list of all task IDs currently in the store."""
        return list(self._tasks.keys())

    def list_tasks(self) -> list[tuple[str, AsyncActionTaskState]]:
        """Return a snapshot of all tasks currently in the store as (task_id, state) tuples."""
        return list(self._tasks.items())


_TASK_STORE = AsyncTaskStore()
_ASYNC_RUNNERS: dict[str, asyncio.Task] = {}


class AsyncActionService:
    """Coordinates async execution lifecycle for actions."""

    def __init__(
        self,
        task_store: AsyncTaskStore,
        runners: dict[str, asyncio.Task],
        running_registry: 'RunningCommandRegistry',
        *,
        ttl_seconds: int,
    ) -> None:
        self._task_store = task_store
        self._runners = runners
        self._running_registry = running_registry
        self._ttl_seconds = ttl_seconds

    def get(self, task_id: str) -> AsyncActionTaskState | None:
        return self._task_store.get_task(task_id)

    async def cancel(self, task_id: str, *, client: 'ActionExecutor | None') -> dict[str, Any]:
        state = self._task_store.get_task(task_id)
        if state is None:
            raise HTTPException(status_code=404, detail='Unknown task ID')

        if state.status in (
            AsyncTaskStatus.COMPLETED,
            AsyncTaskStatus.FAILED,
            AsyncTaskStatus.CANCELLED,
        ):
            return {'task_id': task_id, 'status': state.status.value}

        state.cancel_requested = True
        state.cancel_requested_at = time.time()
        state.status = AsyncTaskStatus.CANCELLED
        state.error = 'Cancelled'
        self._task_store.update_task(state)

        if client is not None:
            try:
                await client.stop_task(task_id)
            except Exception:
                logger.error('Failed to stop task %s via tmux interrupt', task_id, exc_info=True)

        runner = self._runners.get(task_id)
        if runner is not None and not runner.done():
            runner.cancel()

        try:
            await self._running_registry.update_status(task_id, RunningCommandStatus.CANCELLED)
        except Exception:
            logger.error('Failed to update running registry status to CANCELLED for task %s', task_id, exc_info=True)

        return {'task_id': task_id, 'status': AsyncTaskStatus.CANCELLED.value}

    def status_payload(self, state: AsyncActionTaskState) -> dict[str, Any]:
        payload: dict[str, Any] = {
            'task_id': state.task_id,
            'status': state.status.value,
            'created_at': state.created_at,
            'started_at': state.started_at,
            'completed_at': state.completed_at,
        }
        if state.result is not None:
            payload['result'] = event_to_dict(state.result)
        if state.error is not None:
            payload['error'] = state.error
        return payload

    def logs_payload(self, state: AsyncActionTaskState, after_seq: int) -> dict[str, Any]:
        chunks = state.get_logs_after(after_seq)
        return {
            'chunks': [
                {'seq': c.seq, 'content': c.content, 'timestamp': c.timestamp}
                for c in chunks
            ],
            'task_status': state.status.value,
        }

    async def start(
        self,
        *,
        client: 'ActionExecutor',
        action: Action,
        session_id: str | None,
    ) -> AsyncActionTaskState:
        exec_action: Action = action
        state = self._task_store.create_task(session_id=session_id)

        if isinstance(action, CmdRunAction):
            setattr(exec_action, '_runtime_task_id', state.task_id)

        async def _cleanup_now(task_id: str) -> None:
            try:
                current = self._task_store.get_task(task_id)
                if current is None:
                    self._runners.pop(task_id, None)
                    return

                if current.status in (
                    AsyncTaskStatus.COMPLETED,
                    AsyncTaskStatus.FAILED,
                    AsyncTaskStatus.CANCELLED,
                ):
                    logger.info(
                        'Deleting async task %s after TTL expiry (terminal=%s); subsequent status checks may return 404',
                        task_id,
                        current.status,
                    )
                    self._task_store.delete_task(task_id)
                    self._runners.pop(task_id, None)
                    return

                logger.debug(
                    'Async task %s still non-terminal (%s); skipping TTL cleanup',
                    task_id,
                    current.status,
                )
            except Exception:
                logger.exception('Async task cleanup loop crashed (task_id=%s)', task_id)

        def _schedule_cleanup(task_id: str) -> None:
            # ttl_seconds <= 0 disables cleanup (useful for tests or callers that manage lifecycle elsewhere)
            if self._ttl_seconds <= 0:
                return

            loop = asyncio.get_running_loop()

            def _kickoff() -> None:
                asyncio.create_task(_cleanup_now(task_id))

            loop.call_later(self._ttl_seconds, _kickoff)

        async def _run() -> None:
            state.status = AsyncTaskStatus.RUNNING
            state.started_at = time.time()

            def _mark_terminal(status: AsyncTaskStatus, *, error: str | None = None) -> None:
                state.status = status
                if error is not None:
                    state.error = error
                if state.completed_at is None:
                    state.completed_at = time.time()

            try:
                client.last_execution_time = time.time()

                # For CmdRunAction, scope log capture ONLY to initial run_action call.
                if isinstance(exec_action, CmdRunAction):
                    client._current_log_callback = state.add_log_chunk
                try:
                    observation = await client.run_action(exec_action)
                finally:
                    if isinstance(exec_action, CmdRunAction):
                        client._current_log_callback = None

                state.result = observation

                if isinstance(exec_action, CmdRunAction):
                    entry = await self._running_registry.get(state.task_id)
                    if entry is not None:
                        state.slot_id = entry.slot_id

                # If command returned partial: it is STILL running; stay RUNNING
                # and await final observation from executor watcher.
                if isinstance(exec_action, CmdRunAction) and isinstance(observation, CmdOutputObservation):
                    if observation.is_partial:
                        state.status = AsyncTaskStatus.RUNNING
                        self._task_store.update_task(state)

                        final_obs = await client.wait_for_detached_result(state.task_id)
                        state.result = final_obs

                        exit_code = final_obs.metadata.exit_code
                        # If cancellation happened, prefer CANCELLED (covers Ctrl+C/kill patterns)
                        if state.cancel_requested or exit_code in (130, 137):
                            _mark_terminal(AsyncTaskStatus.CANCELLED, error='Cancelled')
                        elif exit_code == 0:
                            _mark_terminal(AsyncTaskStatus.COMPLETED)
                        else:
                            _mark_terminal(AsyncTaskStatus.FAILED, error='Command failed')

                        self._task_store.update_task(state)
                        return

                    # Non-partial command completed in this call.
                    if observation.metadata.exit_code == 0:
                        _mark_terminal(AsyncTaskStatus.COMPLETED)
                    else:
                        _mark_terminal(
                            AsyncTaskStatus.FAILED,
                            error=getattr(observation, 'message', None) or 'Command failed',
                        )

                elif isinstance(action, CmdRunAction):
                    obs_success = True
                    try:
                        if hasattr(observation, 'success'):
                            obs_success = bool(getattr(observation, 'success'))
                    except Exception:
                        obs_success = True

                    _mark_terminal(AsyncTaskStatus.COMPLETED if obs_success else AsyncTaskStatus.FAILED)
                    if not obs_success:
                        try:
                            state.error = getattr(observation, 'message', None) or 'Command failed'
                        except Exception:
                            state.error = 'Command failed'

                else:
                    obs_success = True
                    try:
                        if hasattr(observation, 'success'):
                            obs_success = bool(getattr(observation, 'success'))
                        elif hasattr(observation, 'error'):
                            obs_success = not bool(getattr(observation, 'error'))
                    except Exception:
                        obs_success = True

                    _mark_terminal(AsyncTaskStatus.COMPLETED if obs_success else AsyncTaskStatus.FAILED)
                    if not obs_success:
                        try:
                            state.error = getattr(observation, 'message', None) or 'Action failed'
                        except Exception:
                            state.error = 'Action failed'

            except asyncio.CancelledError:
                _mark_terminal(AsyncTaskStatus.CANCELLED, error='Cancelled')
                raise
            except Exception:
                logger.error('Error while executing async action %s', state.task_id, exc_info=True)
                _mark_terminal(AsyncTaskStatus.FAILED, error=traceback.format_exc())
            finally:
                self._task_store.update_task(state)

                if state.status in (
                    AsyncTaskStatus.COMPLETED,
                    AsyncTaskStatus.FAILED,
                    AsyncTaskStatus.CANCELLED,
                ):
                    _schedule_cleanup(state.task_id)

        runner_task = asyncio.create_task(_run())
        self._runners[state.task_id] = runner_task
        return state


def get_task_store() -> AsyncTaskStore:
    return _TASK_STORE


def get_async_runners() -> dict[str, asyncio.Task]:
    return _ASYNC_RUNNERS
