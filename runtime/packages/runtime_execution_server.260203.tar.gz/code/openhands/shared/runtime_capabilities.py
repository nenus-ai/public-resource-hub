"""Shared capability negotiation for action execution runtimes.

The action execution server (running inside the sandbox) exposes `GET /capabilities`.
Clients (OpenHands backend) should probe that endpoint and gate feature usage.

If the endpoint is missing, we treat the runtime as legacy and assume only `CORE_CAPABILITIES`.
"""

from __future__ import annotations

from typing import Final

# Bump this when the shape/meaning of the /capabilities response changes.
CAPABILITIES_PROTOCOL_VERSION: Final[int] = 1


# "Core" means the minimal baseline we assume for legacy runtimes when /capabilities
# is not present. Keep this list conservative.
CORE_CAPABILITIES: Final[frozenset[str]] = frozenset(
    {
        # Supports POST /execute_action (sync or async-compatible).
        'actions.execute_action.v1',
        'vscode.v1',
    }
)


# Known capability keys (a small registry to avoid typos).
CAP_FILE_MANAGER_V1: Final[str] = 'file_manager.v1'
CAP_FILE_TRANSFER_V1: Final[str] = 'file_transfer.v1'
CAP_LIST_FILES_V1: Final[str] = 'files.list_files.v1'
CAP_WORKSPACE_STATUS_V1: Final[str] = 'workspace.status.v1'
CAP_WORKSPACE_MODE_V1: Final[str] = 'workspace.mode.v1'
CAP_IDLE_LIFE_V1: Final[str] = 'workspace.idle_life.v1'
CAP_VSCODE_V1: Final[str] = 'vscode.v1'
CAP_MCP_UPDATE_V1: Final[str] = 'mcp.update.v1'


KNOWN_CAPABILITIES: Final[frozenset[str]] = frozenset(
    set(CORE_CAPABILITIES)
    | {
        CAP_LIST_FILES_V1,
        CAP_FILE_MANAGER_V1,
        CAP_FILE_TRANSFER_V1,
        CAP_WORKSPACE_STATUS_V1,
        CAP_WORKSPACE_MODE_V1,
        CAP_IDLE_LIFE_V1,
        CAP_VSCODE_V1,
        CAP_MCP_UPDATE_V1,
    }
)
