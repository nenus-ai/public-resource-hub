import asyncio
import os
import shutil
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from openhands.core.logger import openhands_logger as logger
from openhands.events.action import Action
from openhands.events.observation import Observation
from openhands.runtime.plugins.requirement import Plugin, PluginRequirement
from openhands.runtime.utils.system import check_port_available
from openhands.utils.shutdown_listener import should_continue


@dataclass
class VSCodeRequirement(PluginRequirement):
    name: str = 'vscode'


class VSCodePlugin(Plugin):
    name: str = 'vscode'
    vscode_port: Optional[int] = None
    vscode_connection_token: Optional[str] = None
    gateway_process: asyncio.subprocess.Process

    async def initialize(self, username: str, readonly: bool = False) -> None:
        # Check if we're on Windows - VSCode plugin is not supported on Windows
        if os.name == 'nt' or sys.platform == 'win32':
            self.vscode_port = None
            self.vscode_connection_token = None
            logger.warning(
                'VSCode plugin is not supported on Windows. Plugin will be disabled.'
            )
            return

        if username not in ['root', 'kepilot']:
            self.vscode_port = None
            self.vscode_connection_token = None
            logger.warning(
                'VSCodePlugin is only supported for root or kepilot user. '
                'It is not yet supported for other users (i.e., when running LocalRuntime).'
            )
            return

        # Set up VSCode settings.json
        self._setup_vscode_settings()

        # Create restricted shell script
        self._setup_restricted_shell()

        try:
            self.vscode_port = int(os.environ['VSCODE_PORT'])
        except (KeyError, ValueError):
            logger.warning(
                'VSCODE_PORT environment variable not set or invalid. VSCode plugin will be disabled.'
            )
            return

        self.vscode_connection_token = str(uuid.uuid4())
        if not check_port_available(self.vscode_port):
            logger.warning(
                f'Port {self.vscode_port} is not available. VSCode plugin will be disabled.'
            )
            return
        cmd = (
            f"su - {username} -s /bin/bash << 'EOF'\n"
            f'sudo chown -R {username}:{username} /kepilot/.openvscode-server\n'
            'cd /workspace\n'
            f'exec /kepilot/.openvscode-server/bin/openvscode-server --host 0.0.0.0 --connection-token {self.vscode_connection_token} --port {self.vscode_port} --disable-workspace-trust --default-folder /workspace\n'
            'EOF'
        )

        # Using asyncio.create_subprocess_shell instead of subprocess.Popen
        # to avoid ASYNC101 linting error
        self.gateway_process = await asyncio.create_subprocess_shell(
            cmd,
            stderr=asyncio.subprocess.STDOUT,
            stdout=asyncio.subprocess.PIPE,
        )
        # read stdout until the kernel gateway is ready
        output = ''
        start_time = time.perf_counter()
        while should_continue() and self.gateway_process.stdout is not None:
            line_bytes = await self.gateway_process.stdout.readline()
            line = line_bytes.decode('utf-8')
            print(line)
            output += line
            if 'at' in line:
                break
            await asyncio.sleep(1)
            elapsed = time.perf_counter() - start_time
            logger.debug(f'Waiting for VSCode server to start... ({elapsed:.1f}s)')

        elapsed = time.perf_counter() - start_time
        logger.debug(
            f'VSCode server started at port {self.vscode_port} in {elapsed:.1f}s. Output: {output}'
        )

    def _setup_vscode_settings(self) -> None:
        """
        Set up VSCode settings by creating the .vscode directory in the workspace
        and copying the settings.json file there.
        """
        import json

        # Get the path to the settings.json file in the plugin directory
        current_dir = Path(__file__).parent
        settings_path = current_dir / 'settings.json'

        # Load the base settings
        with open(settings_path, 'r') as f:
            settings = json.load(f)

        # Create the .vscode directory in the workspace if it doesn't exist
        vscode_dir = Path('/workspace/.vscode')
        vscode_dir.mkdir(parents=True, exist_ok=True)

        # Write the settings to the .vscode directory
        target_path = vscode_dir / 'settings.json'
        with open(target_path, 'w') as f:
            json.dump(settings, f, indent=2)

        # Make sure the settings file is readable and writable by all users
        os.chmod(target_path, 0o666)

        logger.debug(f'VSCode settings written to {target_path}')

    def _setup_restricted_shell(self) -> None:
        """
        Create a restricted shell script that prevents users from accessing directories outside /workspace
        """
        restricted_shell_content = '''#!/bin/bash

# Restricted shell for workspace-only access
export WORKSPACE_ROOT="/workspace"

# Set up Poetry Python environment
# Find Poetry virtual environment in /kepilot/poetry/
for venv_path in "/kepilot/poetry"/kepilot-ai-*-py*/bin; do
    if [ -d "$(dirname "$venv_path")" ] && [ -f "$venv_path/python" ]; then
        export PATH="$(dirname "$venv_path")/bin:$PATH"
        # echo "Using Poetry Python: $(dirname "$venv_path")/bin/python"
        break
    fi
done

# Fallback: check other common locations
if ! command -v python | grep -q "/kepilot/"; then
    for venv_path in "/kepilot/.venv" "/kepilot/poetry"/* "/root/.cache/pypoetry/virtualenvs"/*; do
        if [ -d "$venv_path/bin" ] && [ -f "$venv_path/bin/python" ]; then
            export PATH="$venv_path/bin:$PATH"
            # echo "Using fallback Python: $venv_path/bin/python"
            break
        fi
    done
fi

# Override cd command to restrict directory access
cd() {
    if [[ $# -eq 0 ]]; then
        # cd with no arguments goes to workspace
        builtin cd "$WORKSPACE_ROOT"
        return $?
    fi

    local target_dir="$1"

    # Convert relative path to absolute
    if [[ "$target_dir" != /* ]]; then
        target_dir="$(pwd)/$target_dir"
    fi

    # Normalize the path (remove .. and .)
    target_dir=$(readlink -m "$target_dir")

    # Check if target directory is within workspace
    if [[ "$target_dir" == "$WORKSPACE_ROOT"* ]] || [[ "$target_dir" == "$WORKSPACE_ROOT" ]]; then
        builtin cd "$target_dir"
    else
        echo "Access denied: Cannot access directories outside /workspace"
        return 1
    fi
}

# Set initial directory to workspace
builtin cd "$WORKSPACE_ROOT"

# Start interactive bash with restricted cd function
exec /bin/bash --rcfile <(echo 'source ~/.bashrc 2>/dev/null;
# Set up Poetry Python environment
for venv_path in "/kepilot/poetry"/kepilot-ai-*-py*/bin; do
    if [ -d "$(dirname "$venv_path")" ] && [ -f "$venv_path/python" ]; then
        export PATH="$(dirname "$venv_path")/bin:$PATH"
        # echo "Using Poetry Python: $(dirname "$venv_path")/bin/python"
        break
    fi
done
if ! command -v python | grep -q "/kepilot/"; then
    for venv_path in "/kepilot/.venv" "/kepilot/poetry"/* "/root/.cache/pypoetry/virtualenvs"/*; do
        if [ -d "$venv_path/bin" ] && [ -f "$venv_path/bin/python" ]; then
            export PATH="$venv_path/bin:$PATH"
            # echo "Using fallback Python: $venv_path/bin/python"
            break
        fi
    done
fi
cd() { local target_dir="$1"; if [[ $# -eq 0 ]]; then builtin cd /workspace; return $?; fi; if [[ "$target_dir" != /* ]]; then target_dir="$(pwd)/$target_dir"; fi; target_dir=$(readlink -m "$target_dir"); if [[ "$target_dir" == "/workspace"* ]] || [[ "$target_dir" == "/workspace" ]]; then builtin cd "$target_dir"; else echo "Access denied: Cannot access directories outside /workspace"; return 1; fi; }; cd /workspace')
'''

        # Write the restricted shell script
        restricted_shell_path = Path('/kepilot/restricted-shell.sh')
        with open(restricted_shell_path, 'w') as f:
            f.write(restricted_shell_content)

        # Make the script executable
        os.chmod(restricted_shell_path, 0o755)

        logger.debug(f'Restricted shell script created at {restricted_shell_path}')

    async def run(self, action: Action) -> Observation:
        """Run the plugin for a given action."""
        raise NotImplementedError('VSCodePlugin does not support run method')
