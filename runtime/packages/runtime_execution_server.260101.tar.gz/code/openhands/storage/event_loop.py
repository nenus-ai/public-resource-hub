import asyncio

# the global event loop is created in the main thread
global_event_loop = None


def set_global_event_loop():
    """Set the global event loop for the current thread."""
    global global_event_loop
    global_event_loop = asyncio.get_event_loop()
    return global_event_loop


def equal_to_global_event_loop():
    """Check if the current event loop is the same as the global event loop."""
    global global_event_loop
    current_loop = asyncio.get_event_loop()
    return current_loop == global_event_loop
