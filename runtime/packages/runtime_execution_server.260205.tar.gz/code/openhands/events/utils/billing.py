"""Billing-related utilities for events.

This module provides utilities to determine if an event should be billed or not.
The logic here mirrors the Kafka consumer billing logic to ensure frontend and backend consistency.
"""

from typing import Any, Dict

from openhands.core.logger import openhands_logger as logger
from openhands.events.event import Event


def should_bill_event(event: Event) -> bool:
    """Determine if an event should be billed based on its properties.

    Philosophy: Only system/agent-level errors are billing-exempt.
    Individual command failures are part of normal agent work and should be billed.

    Returns True if the event should be billed, False otherwise.

    Args:
        event: The event to check

    Returns:
        bool: True if billable, False if billing-exempt (show "Not charged" badge)
    """
    try:
        # Only exempt these critical errors where Agent stops working:

        # 1. ErrorObservation - System-level errors
        if hasattr(event, "observation"):
            obs_type = getattr(event, "observation", None)
            if isinstance(obs_type, str) and obs_type.lower() == "error":
                return False  # System error → not billable

        # 2. Agent enters ERROR state
        if hasattr(event, "agent_state"):
            agent_state = getattr(event, "agent_state", None)
            if isinstance(agent_state, str) and agent_state.lower() == "error":
                return False  # Agent ERROR state → not billable

        # All other cases are billable:
        # - Command failures (Agent continues working)
        # - Partial errors (Agent tries alternative approaches)
        # - Commands running
        # - Successful operations
        return True

    except Exception:
        logger.exception("Billing evaluation failed for event; defaulting to billable")
        return True


def mark_event_billing_status(event: Event) -> None:
    """Mark an event with its billing status.

    Sets the _billing_exempt attribute on the event based on should_bill_event().
    This should be called before sending events to the frontend.

    Args:
        event: The event to mark
    """
    try:
        is_billable = should_bill_event(event)
        event._billing_exempt = not is_billable  # type: ignore[attr-defined]
    except Exception:
        logger.exception("Failed to mark billing status; defaulting to billable")
        event._billing_exempt = False  # type: ignore[attr-defined]
