import os
from datetime import datetime


def is_localhost(domain: str):
    return domain == 'localhost' or '.localhost' in domain


ECR_REGISTRY_URL = os.environ.get(
    'ECR_REGISTRY_URL', '545083594342.dkr.ecr.us-east-1.amazonaws.com/nenus-ai'
)

# Allowed characters:
# Lowercase and uppercase letters (a-z, A-Z)
# Digits (0-9)
# Underscores (_)
# Periods (.)
# Hyphens (-)

# Restrictions:
# Maximum length: 128 characters
# Must not start with a period (.) or hyphen (-)
# Can contain multiple separators like dots and hyphens


# 545083594342.dkr.ecr.us-east-1.amazonaws.com/nenus-ai/
# prefix-xxx-suffix: xxx is means the lifetime in n+1 days
# e.g.
# *-001-*: 2 days
# *-007-*: 8 days
# *-030-*: 31 days
# *-090-*: 91 days
# 81a475b5f2a2414990f0bf98861ee6cd_f9ff8b1e-001-1a2b3c4d
def get_shared_workspaces_image(
    user_id: str, snapshot_id: str, expires_at_naive: datetime | None
) -> str:
    prefix = f'{user_id}_{snapshot_id}'
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    suffix = hash(timestamp) & 0xFFFFFFFF

    middle = '000'  # default to 1 days
    if expires_at_naive:
        delta_days = (expires_at_naive.date() - datetime.now().date()).days
        if delta_days >= 90:
            middle = '090'
        elif delta_days >= 30:
            middle = '030'
        elif delta_days >= 7:
            middle = '007'
        else:
            middle = '001'
    image_tag = f'{prefix}-{middle}-{suffix:08x}'
    # Use a fixed repository name for snapshots
    repository = 'kepilot_snapshot'
    return f'{ECR_REGISTRY_URL}/{repository}:{image_tag}'


def is_remote_runtime() -> bool:
    runtime = os.environ.get('RUNTIME', 'docker')
    return runtime == 'remote'


# full_image_name:   545083594342.dkr.ecr.us-east-1.amazonaws.com/nenus-ai/kepilot_snapshot:9977ffc7-007-eb3ccd40
# registry: 545083594342.dkr.ecr.us-east-1.amazonaws.com/nenus-ai
# repository: kepilot_snapshot
# tag: 9977ffc7-007-eb3ccd40
def parse_full_image_name(full_image_name: str) -> tuple[str, str, str]:
    try:
        registry_and_repo, tag = full_image_name.rsplit(':', 1)
        registry_parts = registry_and_repo.split('/')
        registry = '/'.join(registry_parts[:-1])
        repository = registry_parts[-1]
        return registry, repository, tag
    except Exception:
        return '', '', ''  # return empty strings if error occurs
