import os

from openhands.server.config.server_config import ServerConfig
from openhands.server.helper import is_localhost
from openhands.server.types import AppMode


class OaisConfig(ServerConfig):
    config_cls = None
    app_mode = AppMode.SAAS
    posthog_client_key = os.environ.get('POSTHOG_CLIENT_KEY', '')
    github_client_id = os.environ.get('GITHUB_APP_CLIENT_ID', '')
    github_client_secret = os.environ.get('GITHUB_APP_CLIENT_SECRET')
    github_app_oauth_client_id = os.environ.get('GITHUB_APP_OAUTH_CLIENT_ID', '')
    github_app_oauth_client_secret = os.environ.get('GITHUB_APP_OAUTH_CLIENT_SECRET')
    github_app_slug = os.environ.get('GITHUB_APP_SLUG', 'kepilotai')
    jwt_secret_key = os.getenv('JWT_SECRET_KEY', 'KepilotIsAwesome#$%!#')
    jwt_token_expire_seconds = int(os.getenv('JWT_ACCESS_TOKEN_EXPIRE_SECONDS', 60*60*24*2))
    jwt_secret_key_next_auth = os.getenv('JWT_SECRET_KEY_NEXT_AUTH', 'KepilotIsAwesomeNextAuth#$%!#')
    jwt_algorithm_next_auth = 'HS256'
    jwt_algorithm = 'HS256'
    debug_port = int(os.getenv('OAIS_DEBUG_PORT', 3000))
    domain = os.getenv('OAIS_DOMAIN', 'localhost')
    app_url = f'https://app.{domain}' if not is_localhost(domain) else f'http://{domain}:{debug_port}'

    enable_billing = os.environ.get('ENABLE_BILLING', 'false') == 'true'
    hide_llm_settings = os.environ.get('HIDE_LLM_SETTINGS', 'false') == 'true'
    settings_store_class: str = (
       'openhands.storage.settings.postgres_settings_store.PostgresSettingsStore'

    )
    secret_store_class: str = (
        'openhands.storage.secrets.postgres_secrets_store.PostgresSecretsStore'
    )
    conversation_store_class: str = (
        'openhands.storage.conversation.postgres_conversation_store.PostgresConversationStore'
    )
    conversation_manager_class: str = os.environ.get(
        'CONVERSATION_MANAGER_CLASS',
        'openhands.server.conversation_manager.standalone_conversation_manager.StandaloneConversationManager',
    )
    monitoring_listener_class: str = 'openhands.server.monitoring.MonitoringListener'
    user_auth_class: str = (
        'openhands.server.user_auth.tenant_auth.TenantUserAuth'
    )

    # Stripe configuration (optional to support testing without Stripe)
    stripe_secret_key: str | None = os.environ.get('STRIPE_SECRET_KEY')
    stripe_webhook_secret_snapshot: str | None = os.environ.get('STRIPE_WEBHOOK_SECRET_SNAPSHOT')
    stripe_webhook_secret_thin: str | None = os.environ.get('STRIPE_WEBHOOK_SECRET_THIN')
    frontend_url: str | None = os.environ.get('FRONTEND_URL')

    def verify_config(self):
        if self.config_cls:
            raise ValueError('Unexpected config path provided')

    def get_stripe_api_key(self) -> str:
        """Get Stripe API key with validation."""
        if not self.stripe_secret_key:
            raise ValueError('STRIPE_SECRET_KEY environment variable is not set.')
        return self.stripe_secret_key

    def get_stripe_webhook_secret(self, webhook_type: str) -> str:
        """Get Stripe webhook secret with validation.
        
        Args:
            webhook_type: Either 'snapshot' or 'thin'
        
        Returns:
            The webhook secret for the specified type
            
        Raises:
            ValueError: If webhook secret is not configured
        """
        if webhook_type == 'snapshot':
            if not self.stripe_webhook_secret_snapshot:
                raise ValueError('STRIPE_WEBHOOK_SECRET_SNAPSHOT environment variable is not set.')
            return self.stripe_webhook_secret_snapshot
        elif webhook_type == 'thin':
            if not self.stripe_webhook_secret_thin:
                raise ValueError('STRIPE_WEBHOOK_SECRET_THIN environment variable is not set.')
            return self.stripe_webhook_secret_thin
        else:
            raise ValueError(f'Unknown webhook type: {webhook_type}')

    def get_frontend_url(self) -> str:
        """Get frontend URL with validation."""
        if not self.frontend_url:
            raise ValueError('FRONTEND_URL environment variable is not set.')
        # Validate FRONTEND_URL has a scheme
        if not (self.frontend_url.startswith('http://') or self.frontend_url.startswith('https://')):
            raise ValueError("FRONTEND_URL environment variable must include 'http://' or 'https://' scheme (e.g., 'https://localhost:3000').")
        return self.frontend_url

    def get_config(self):
        config = {
            'APP_MODE': self.app_mode,
            'GITHUB_CLIENT_ID': self.github_client_id,
            'POSTHOG_CLIENT_KEY': self.posthog_client_key,
            'APP_SLUG': self.github_app_slug,
            'FEATURE_FLAGS': {
                'ENABLE_BILLING': self.enable_billing,
                'HIDE_LLM_SETTINGS': self.hide_llm_settings,
            },
        }

        return config


oais_config = OaisConfig()

