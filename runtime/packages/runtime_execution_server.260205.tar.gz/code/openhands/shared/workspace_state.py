from enum import Enum


class WorkspaceStateName(str, Enum):
    """
    Single source of truth for workspace runtime state names.
    Used by both runtime API + storage models to avoid drift.
    """

    STARTING = 'STARTING'
    READY = 'READY'
    BUSY_SLOTS_AVAILABLE = 'BUSY_SLOTS_AVAILABLE'
    BUSY_SLOTS_EXHAUSTED = 'BUSY_SLOTS_EXHAUSTED'
    DRAINING = 'DRAINING'
    UPGRADING = 'UPGRADING'
    MAINTENANCE = 'MAINTENANCE'
    STOPPED = 'STOPPED'
    UNKNOWN = 'UNKNOWN'
    UNSUPPORTED = 'UNSUPPORTED'
