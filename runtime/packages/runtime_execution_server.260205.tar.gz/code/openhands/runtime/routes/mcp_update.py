from __future__ import annotations

import json
import os
import sys
from typing import Any, Callable

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse
from mcpm import MCPRouter

from openhands.core.logger import openhands_logger as logger
from openhands.runtime.action_execution.executor.executor import ActionExecutor
from openhands.runtime.utils.log_capture import capture_logs


def create_mcp_update_router(
    *,
    get_client: Callable[[], ActionExecutor | None],
    get_mcp_router: Callable[[], MCPRouter | None],
    profile_path: str,
) -> APIRouter:
    router = APIRouter()

    @router.post('/update_mcp_server')
    async def update_mcp_server(request: Request):
        client = get_client()
        assert client is not None
        client.start_idle_timer()

        # Check if we're on Windows
        is_windows = sys.platform == 'win32'

        if is_windows:
            # On Windows, just return a success response without doing anything
            logger.info(
                'MCP server update request received on Windows - skipping as MCP is disabled'
            )
            return JSONResponse(
                status_code=200,
                content={
                    'detail': 'MCP server update skipped (MCP is disabled on Windows)',
                    'router_error_log': '',
                },
            )

        mcp_router = get_mcp_router()
        assert mcp_router is not None
        assert os.path.exists(profile_path)

        def read_profile() -> dict[str, Any]:
            with open(profile_path, 'r') as f:
                return json.load(f)

        current_profile = read_profile()
        assert 'default' in current_profile
        assert isinstance(current_profile['default'], list)

        mcp_tools_to_sync = await request.json()
        if not isinstance(mcp_tools_to_sync, list):
            raise HTTPException(
                status_code=400, detail='Request must be a list of MCP tools to sync'
            )

        logger.info(
            f'Updating MCP server to: {json.dumps(mcp_tools_to_sync, indent=2)}.\nPrevious profile: {json.dumps(current_profile, indent=2)}'
        )
        current_profile['default'] = mcp_tools_to_sync

        def write_profile(profile: dict[str, Any]) -> None:
            with open(profile_path, 'w') as f:
                json.dump(profile, f)

        write_profile(current_profile)

        # Manually reload the profile and update the servers
        mcp_router.profile_manager.reload()
        servers_wait_for_update = mcp_router.get_unique_servers()
        async with capture_logs('mcpm.router.router') as log_capture:
            await mcp_router.update_servers(servers_wait_for_update)
        router_error_log = log_capture.getvalue()

        logger.info(
            f'MCP router updated successfully with unique servers: {servers_wait_for_update}'
        )
        if router_error_log:
            logger.warning(f'Some MCP servers failed to be added: {router_error_log}')

        return JSONResponse(
            status_code=200,
            content={
                'detail': 'MCP server updated successfully',
                'router_error_log': router_error_log,
            },
        )

    return router
