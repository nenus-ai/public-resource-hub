from __future__ import annotations

import os
from typing import Callable

from fastapi import APIRouter, HTTPException, Request

from openhands.core.logger import openhands_logger as logger
from openhands.runtime.action_execution.executor.executor import ActionExecutor

IDLE_LIFE_PERSISTENCE_PATH = '/opt/runtime/idle_life.txt'


def persist_idle_life(idle_life: int) -> None:
    """Write idle_life to a file so the value survives container restarts."""
    try:
        os.makedirs(os.path.dirname(IDLE_LIFE_PERSISTENCE_PATH), exist_ok=True)
        with open(IDLE_LIFE_PERSISTENCE_PATH, 'w') as f:
            f.write(str(idle_life))
    except OSError as e:
        logger.warning(
            f'Failed to persist idle_life to {IDLE_LIFE_PERSISTENCE_PATH}: {e}'
        )


def create_idle_life_router(
    *, get_client: Callable[[], ActionExecutor | None]
) -> APIRouter:
    router = APIRouter()

    @router.post('/idle_life')
    async def update_idle_life(request: Request):
        """Update the idle_life setting at runtime.

        This endpoint allows the runtime to update its idle timeout dynamically.
        """
        client = get_client()
        assert client is not None
        try:
            body = await request.json()
            idle_life = body.get('idle_life')
            if idle_life is None:
                raise HTTPException(
                    status_code=400, detail='Missing required field: idle_life'
                )
            idle_life_int = int(idle_life)
            if idle_life_int < 0:
                raise HTTPException(
                    status_code=400,
                    detail='idle_life must be a positive integer to enable timeout, or 0 to disable',
                )
        except ValueError:
            raise HTTPException(status_code=400, detail='idle_life must be an integer')
        client.update_idle_life(idle_life_int)
        persist_idle_life(client.idle_life)
        return {'status': 'ok', 'idle_life': client.idle_life}

    return router
