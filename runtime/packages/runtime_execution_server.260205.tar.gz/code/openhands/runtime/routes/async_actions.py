import time
from collections.abc import Awaitable, Callable
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from openhands.core.logger import openhands_logger as logger
from openhands.events.action import Action, CmdRunAction
from openhands.events.serialization import event_from_dict, event_to_dict
from openhands.runtime.action_execution.executor.executor import ActionExecutor
from openhands.runtime.action_execution.services.async_tasks import (
    AsyncActionService,
    AsyncTaskStatus,
    AsyncTaskStore,
)


class ActionRequest(BaseModel):
    action: dict
    async_execution: bool | None = False


def create_async_actions_router(
    *,
    get_client: Callable[[], Optional[ActionExecutor]],
    async_action_service: AsyncActionService,
    task_store: AsyncTaskStore,
    get_workspace_state_payload: Callable[[], Awaitable[dict[str, Any]]],
) -> APIRouter:
    """Create router for async-capable action execution endpoints.

    Endpoints:
    - POST /execute_action
    - GET  /actions/{task_id}
    - GET  /actions/{task_id}/logs
    - POST /actions/{task_id}/cancel
    - POST /stop_all
    """

    router = APIRouter()

    @router.post('/actions/{task_id}/cancel')
    async def cancel_action(task_id: str):
        client = get_client()
        # Safe action: allow even when input is blocked
        return await async_action_service.cancel(task_id, client=client)

    @router.post('/execute_action')
    async def execute_action(action_request: ActionRequest, request: Request):
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')

        client.start_idle_timer()
        try:
            action = event_from_dict(action_request.action)
            if not isinstance(action, Action):
                raise HTTPException(status_code=400, detail='Invalid action type')

            async_requested = bool(action_request.async_execution)
            header_async = request.headers.get('X-Async-Execution', '').lower() == 'true'
            async_requested = async_requested or header_async

            # Input gate for new shell commands
            if isinstance(action, CmdRunAction):
                ws = await get_workspace_state_payload()
                if not ws.get('accepting_user_actions', True):
                    raise HTTPException(
                        status_code=409,
                        detail={
                            'message': 'Workspace is not accepting new commands',
                            'workspace_state': ws,
                        },
                    )

            # Synchronous execution for backward compatibility
            if not async_requested:
                client.last_execution_time = time.time()
                observation = await client.run_action(action)
                return event_to_dict(observation)

            # Async execution: schedule background execution and return a task_id.
            session_id = request.headers.get('X-Session-ID')
            state = await async_action_service.start(
                client=client,
                action=action,
                session_id=session_id,
            )
            return {'task_id': state.task_id, 'status': state.status.value}

        except HTTPException:
            raise
        except Exception:
            logger.error('Error while running /execute_action', exc_info=True)
            raise HTTPException(status_code=500, detail='Internal server error')

    @router.get('/actions/{task_id}')
    async def get_action_status(task_id: str):
        try:
            state = task_store.get_task(task_id)
            if state is None:
                logger.warning('get_action_status: unknown task_id %s', task_id)
                raise HTTPException(status_code=404, detail='Unknown task ID')

            payload: dict[str, Any] = {
                'task_id': state.task_id,
                'status': state.status.value,
                'created_at': state.created_at,
                'started_at': state.started_at,
                'completed_at': state.completed_at,
            }
            if state.result is not None:
                try:
                    payload['result'] = event_to_dict(state.result)
                except Exception:
                    logger.error(
                        'Failed to serialize result for task %s',
                        task_id,
                        exc_info=True,
                    )
                    payload['status'] = AsyncTaskStatus.FAILED.value
                    payload['error'] = 'Failed to serialize result'

            if state.error is not None:
                payload['error'] = state.error
            return payload
        except HTTPException:
            raise
        except Exception:
            logger.error('Error while running /actions/%s', task_id, exc_info=True)
            raise HTTPException(status_code=500, detail='Internal server error')

    @router.get('/actions/{task_id}/logs')
    async def get_action_logs(task_id: str, after_seq: int = -1):
        """Get incremental log chunks for a running action."""
        try:
            state = task_store.get_task(task_id)
            if state is None:
                logger.warning('get_action_logs: unknown task_id %s', task_id)
                raise HTTPException(status_code=404, detail='Unknown task ID')

            chunks = state.get_logs_after(after_seq)
            return {
                'chunks': [
                    {'seq': c.seq, 'content': c.content, 'timestamp': c.timestamp}
                    for c in chunks
                ],
                'task_status': state.status.value,
            }
        except HTTPException:
            raise
        except Exception:
            logger.error('Error while running /actions/%s/logs', task_id, exc_info=True)
            raise HTTPException(status_code=500, detail='Internal server error')

    @router.post('/stop_all')
    async def stop_all_tasks():
        """Best-effort cancellation for all currently running async actions."""
        client = get_client()
        if client is None:
            raise HTTPException(status_code=503, detail='Runtime not ready')
        client.start_idle_timer()

        stopped: list[str] = []
        for task_id, state in task_store.list_tasks():
            if state.status in (AsyncTaskStatus.PENDING, AsyncTaskStatus.RUNNING):
                try:
                    await async_action_service.cancel(task_id, client=client)
                    stopped.append(task_id)
                except HTTPException:
                    continue
                except Exception:
                    logger.exception('stop_all: failed cancelling task %s', task_id)

        return {'status': 'ok', 'stopped_tasks': stopped}

    return router
