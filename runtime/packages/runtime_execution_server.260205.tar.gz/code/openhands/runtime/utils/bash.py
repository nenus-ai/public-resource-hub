import os
import re
import subprocess
import tempfile
import signal
from collections import deque
import time
import uuid
from enum import Enum
from typing import Callable

from openhands.core.logger import openhands_logger as logger
from openhands.events.action import CmdRunAction
from openhands.events.observation import ErrorObservation
from openhands.events.observation.commands import (
    CMD_OUTPUT_PS1_END,
    CmdOutputMetadata,
    CmdOutputObservation,
)
from openhands.runtime.utils.bash_constants import TIMEOUT_MESSAGE_TEMPLATE
from openhands.runtime.utils.bash_parsing import escape_bash_special_chars, split_bash_commands
from openhands.runtime.utils.bash_guardrails import (
    dangerous_pkill_python_error_message,
    should_block_dangerous_pkill_python,
)
from openhands.runtime.utils.shell_session import (
    is_background_command as _is_background_command,
)
from openhands.runtime.utils.tmux_backend import LibTmuxBackend, TmuxBackend
from openhands.runtime.utils.process_listing import _list_python_processes
from openhands.utils.shutdown_listener import should_continue

# Foreground PID discovery: ignore interactive shells/helpers by default.
# This keeps us focused on the actual foreground work process rather than wrappers.
# Can be overridden for edge cases via env var (comma-separated).
_DEFAULT_FOREGROUND_HELPER_COMMANDS = frozenset({"tmux", "bash", "sh", "su", "ps"})
_env_helpers = os.environ.get("OPENHANDS_FOREGROUND_HELPER_COMMANDS", "").strip()
_FOREGROUND_HELPER_COMMANDS = (
    frozenset({c.strip().lower() for c in _env_helpers.split(",") if c.strip()})
    if _env_helpers
    else _DEFAULT_FOREGROUND_HELPER_COMMANDS
)

# Cap per-line tail size to avoid unbounded memory growth when commands print huge lines.
# (The tail buffer is per-session and multiplied by concurrent slots.)
DEFAULT_TAIL_MAX_CHARS = 2000

class BashCommandStatus(Enum):
    CONTINUE = 'continue'
    COMPLETED = 'completed'
    NO_CHANGE_TIMEOUT = 'no_change_timeout'
    HARD_TIMEOUT = 'hard_timeout'


def _remove_command_prefix(command_output: str, command: str) -> str:
    return command_output.lstrip().removeprefix(command.lstrip()).lstrip()


class BashSession:
    POLL_INTERVAL = 0.5
    HISTORY_LIMIT = 10_000
    PS1 = CmdOutputMetadata.to_ps1_prompt()

    def __init__(
        self,
        work_dir: str,
        username: str | None = None,
        no_change_timeout_seconds: int = 30,
        max_memory_mb: int | None = None,
        slot_id: str | None = None,
        tail_max_lines: int = 80,
        tail_max_chars: int = 4000,
        tmux_backend: TmuxBackend | None = None,
    ):
        self.NO_CHANGE_TIMEOUT_SECONDS = no_change_timeout_seconds
        self.work_dir = work_dir
        self.username = username
        self._initialized = False
        self.max_memory_mb = max_memory_mb
        self._tmux: TmuxBackend = tmux_backend or LibTmuxBackend()

        # Session-pool / monitoring fields
        self.slot_id = slot_id
        self._tail_max_lines = tail_max_lines
        self._tail_max_chars = tail_max_chars
        self._tail_lines: deque[str] = deque(maxlen=tail_max_lines)
        self.last_output_time: float | None = None
        self.current_command: str | None = None
        self.current_pid: int | None = None
        self._pane_tty: str | None = None
        self._pane_id: str | None = None

        # Lifecycle fields (set here so close/__del__ are safe even if initialize() is never called)
        self._closed: bool = False
        self.prev_status: BashCommandStatus | None = None
        self.prev_output: str = ''
        self._cwd = os.path.abspath(self.work_dir)

    def _truncate_tail_line(self, line: str) -> str:
        if len(line) <= self._tail_max_chars:
            return line
        return line[: self._tail_max_chars] + " ...(truncated)"

    def _update_tail_from_content(self, content: str) -> None:
        try:
            self._tail_lines.clear()
            self._tail_lines.extend(
                [
                    self._truncate_tail_line(ln)
                    for ln in content.splitlines()[-self._tail_max_lines :]
                ]
            )
        except Exception:
            logger.exception(
                "Failed to update _tail_lines from pane content in _update_tail_from_content."
            )

    def _compute_log_delta(self, cur: str, last: str) -> str:
        if not last:
            return cur
        if len(cur) > len(last) and cur.startswith(last):
            return cur[len(last) :]
        return cur

    def _prompt_at_bottom(self, pane_output: str) -> bool:
        try:
            return (pane_output or "").rstrip().endswith(CMD_OUTPUT_PS1_END.rstrip())
        except Exception:
            return False

    def initialize(self) -> None:
        _shell_command = '/bin/bash'
        if self.username in ['root', 'openhands']:
            # This starts a non-login (new) shell for the given user
            _shell_command = f'su {self.username} -'

        # FIXME: we will introduce memory limit using sysbox-runc in coming PR
        # # otherwise, we are running as the CURRENT USER (e.g., when running LocalRuntime)
        # if self.max_memory_mb is not None:
        #     window_command = (
        #         f'prlimit --as={self.max_memory_mb * 1024 * 1024} {_shell_command}'
        #     )
        # else:
        window_command = _shell_command

        logger.debug(f'Initializing bash session with command: {window_command}')
        session_name = f'openhands-{self.username}-{uuid.uuid4()}'

        state = self._tmux.start_session(
            session_name=session_name,
            start_directory=self.work_dir,
            window_name='bash',
            window_shell=window_command,
            history_limit=self.HISTORY_LIMIT,
            x=1000,
            y=1000,
        )

        # Keep these attributes for backwards compatibility / debugging.
        self.server = state.server
        self.session = state.session
        self.window = state.window
        self.pane = state.pane
        self._pane_id = state.pane_id

        logger.debug(f'pane: {self.pane}; history_limit: {self.HISTORY_LIMIT}')

        # Configure bash to use simple PS1 and disable PS2
        self._tmux.send_keys(
            self.pane,
            f'export PROMPT_COMMAND=\'export PS1="{self.PS1}"\'; export PS2=""',
        )
        time.sleep(0.1)  # Wait for command to take effect
        self._clear_screen()

        # Store the last command for interactive input handling
        self.prev_status = None
        self.prev_output = ''
        self._closed = False
        logger.debug(f'Bash session initialized with work dir: {self.work_dir}')

        # Maintain the current working directory
        self._cwd = os.path.abspath(self.work_dir)
        self._initialized = True

    def __del__(self) -> None:
        """Ensure the session is closed when the object is destroyed."""
        try:
            self.close()
        except Exception:
            # Never raise from a destructor; best-effort cleanup only.
            pass

    def _get_pane_content(self) -> str:
        """Capture the current pane content and update the buffer."""
        try:
            content = self._tmux.capture_pane(
                window=getattr(self, 'window', None),
                pane=self.pane,
                pane_id=getattr(self, '_pane_id', None),
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError("tmux capture-pane timed out (tmux likely unhealthy)")
        except Exception:
            raise

        self._update_tail_from_content(content)
        return content

    def _wait_for_initial_prompt(self, timeout_s: float = 2.0, poll_s: float = 0.05):
        """
        On a fresh tmux pane, capture-pane can be empty for a short time until the shell prints
        the first prompt. If we snapshot PS1 count = 0 and immediately send a command, the first
        prompt will look like a "new prompt" and we falsely mark the command as completed.
        """
        deadline = time.time() + timeout_s
        last = ""

        while time.time() < deadline:
            pane = self._get_pane_content()
            last = pane
            matches = CmdOutputMetadata.matches_ps1_metadata(pane)
            if len(matches) > 0:
                return pane, matches, len(matches)
            time.sleep(poll_s)

        # Timeout: log a warning and return whatever we saw last (likely empty) so caller can proceed.
        logger.warning(
            "Timed out waiting for initial shell prompt after %.2f seconds; "
            "proceeding with last captured pane content (%d characters).",
            timeout_s,
            len(last),
        )
        matches = CmdOutputMetadata.matches_ps1_metadata(last)
        return last, matches, len(matches)

    def _get_initial_prompt_state(
        self, initial_pane_output: str, *, command: str, is_input: bool
    ) -> tuple[str, list[re.Match], int, bool]:
        initial_ps1_matches = CmdOutputMetadata.matches_ps1_metadata(initial_pane_output)
        initial_ps1_count = len(initial_ps1_matches)
        if (not is_input) and command != '' and initial_ps1_count == 0:
            logger.debug('No initial PS1 detected yet; waiting for first prompt...')
            initial_pane_output, initial_ps1_matches, initial_ps1_count = (
                self._wait_for_initial_prompt(timeout_s=2.0)
            )
        logger.debug(f'Initial PS1 count: {initial_ps1_count}')
        initial_prompt_at_bottom = self._prompt_at_bottom(initial_pane_output)
        return (
            initial_pane_output,
            initial_ps1_matches,
            initial_ps1_count,
            initial_prompt_at_bottom,
        )

    def _poll_until_command_finishes(
        self,
        *,
        action: CmdRunAction,
        command: str,
        command_for_obs: str,
        initial_pane_output: str,
        initial_ps1_count: int,
        start_time: float,
        last_change_time: float,
        last_pane_output: str,
        log_callback: Callable[[str], None] | None,
        is_followup_input: bool,
    ) -> CmdOutputObservation | ErrorObservation:
        # Track whether pane content has changed since we started waiting.
        # This avoids falsely treating an already-visible idle prompt as completion.
        pane_changed_since_start = False

        while should_continue():
            # If tmux server/session is killed (e.g. `tmux kill-server` / `tmux kill-session`),
            # libtmux capture-pane can hang or throw. Bail out early.
            if not self.is_healthy():
                return self._tmux_died_obs()

            _start_time = time.time()
            logger.debug(f'GETTING PANE CONTENT at {_start_time}')
            try:
                cur_pane_output = self._get_pane_content()
            except Exception:
                if not self.is_healthy():
                    return self._tmux_died_obs()
                raise

            if not pane_changed_since_start and cur_pane_output != initial_pane_output:
                pane_changed_since_start = True

            logger.debug(
                f'PANE CONTENT GOT after {time.time() - _start_time:.2f} seconds'
            )
            pane_lines = cur_pane_output.split('\n')
            logger.debug(f'BEGIN OF PANE CONTENT: {pane_lines[:10]}')
            logger.debug(f'END OF PANE CONTENT: {pane_lines[-10:]}')
            ps1_matches = CmdOutputMetadata.matches_ps1_metadata(cur_pane_output)
            current_ps1_count = len(ps1_matches)

            if cur_pane_output != last_pane_output:
                if log_callback:
                    delta = self._compute_log_delta(cur_pane_output, last_pane_output)
                    if delta:
                        try:
                            log_callback(delta)
                        except Exception as e:
                            logger.warning(f'log_callback failed: {e}')

                last_pane_output = cur_pane_output
                last_change_time = time.time()
                self.last_output_time = last_change_time
                logger.debug(f'CONTENT UPDATED DETECTED at {last_change_time}')

            # Completion detection.
            new_prompt_seen = current_ps1_count > initial_ps1_count
            prompt_at_bottom = self._prompt_at_bottom(cur_pane_output)
            if new_prompt_seen or (
                prompt_at_bottom and (command == '' or pane_changed_since_start)
            ):
                return self._handle_completed_command(
                    command_for_obs,
                    pane_content=cur_pane_output,
                    ps1_matches=ps1_matches,
                    is_followup_input=is_followup_input,
                )

            # No-change timeout (only for non-blocking actions)
            time_since_last_change = time.time() - last_change_time
            logger.debug(
                f'CHECKING NO CHANGE TIMEOUT ({self.NO_CHANGE_TIMEOUT_SECONDS}s): '
                f'elapsed {time_since_last_change}. Action blocking: {action.blocking}'
            )
            if (
                not action.blocking
                and time_since_last_change >= self.NO_CHANGE_TIMEOUT_SECONDS
            ):
                return self._handle_nochange_timeout_command(
                    command_for_obs,
                    pane_content=cur_pane_output,
                    ps1_matches=ps1_matches,
                )

            # Hard timeout
            elapsed_time = time.time() - start_time
            logger.debug(
                f'CHECKING HARD TIMEOUT ({action.timeout}s): elapsed {elapsed_time:.2f}'
            )
            if action.timeout and elapsed_time >= action.timeout:
                logger.debug('Hard timeout triggered.')
                return self._handle_hard_timeout_command(
                    command_for_obs,
                    pane_content=cur_pane_output,
                    ps1_matches=ps1_matches,
                    timeout=action.timeout,
                )

            logger.debug(f'SLEEPING for {self.POLL_INTERVAL} seconds for next poll')
            time.sleep(self.POLL_INTERVAL)

        raise RuntimeError('Bash session was likely interrupted...')

    def close(self) -> None:
        """Clean up the session."""
        if getattr(self, '_closed', False):
            return

        # If we don't have a tmux session object, there's nothing to clean up.
        # Note: `initialize()` may fail after creating `self.session` but before
        # setting `_initialized = True`, so we must not rely on `_initialized`
        # here to decide whether to kill the session.
        if not hasattr(self, 'session') or self.session is None:
            self._closed = True
            return

        try:
            self._tmux.kill_session(self.session)
        finally:
            self._closed = True

    @property
    def cwd(self) -> str:
        return self._cwd

    def _is_special_key(self, command: str) -> bool:
        """Check if the command is a special key."""
        # Special keys are of the form C-<key>
        _command = command.strip()
        return _command.startswith('C-') and len(_command) == 3

    def _clear_screen(self) -> None:
        """Clear the tmux pane screen and history."""
        self._tmux.send_keys(self.pane, 'C-l', enter=False)
        time.sleep(0.1)
        self._tmux.clear_history(self.pane)

    def _get_command_output(
        self,
        command: str,
        raw_command_output: str,
        metadata: CmdOutputMetadata,
        continue_prefix: str = '',
    ) -> str:
        """Get the command output with the previous command output removed.

        Args:
            command: The command that was executed.
            raw_command_output: The raw output from the command.
            metadata: The metadata object to store prefix/suffix in.
            continue_prefix: The prefix to add to the command output if it's a continuation of the previous command.
        """
        # remove the previous command output from the new output if any
        if self.prev_output:
            command_output = raw_command_output.removeprefix(self.prev_output)
            metadata.prefix = continue_prefix
        else:
            command_output = raw_command_output
        self.prev_output = raw_command_output  # update current command output anyway
        command_output = _remove_command_prefix(command_output, command)
        return command_output.rstrip()

    def _handle_completed_command(
        self,
        command: str,
        pane_content: str,
        ps1_matches: list[re.Match],
        *,
        is_followup_input: bool = False,
    ) -> CmdOutputObservation:
        is_special_key = self._is_special_key(command)
        assert len(ps1_matches) >= 1, (
            f'Expected at least one PS1 metadata block, but got {len(ps1_matches)}.\n'
            f'---FULL OUTPUT---\n{pane_content!r}\n---END OF OUTPUT---'
        )
        metadata = CmdOutputMetadata.from_ps1_match(ps1_matches[-1])

        # Special case where the previous command output is truncated due to history limit
        # We should get the content BEFORE the last PS1 prompt
        get_content_before_last_match = bool(len(ps1_matches) == 1)

        # Update the current working directory if it has changed
        if metadata.working_dir != self._cwd and metadata.working_dir:
            self._cwd = metadata.working_dir

        logger.debug(f'COMMAND OUTPUT: {pane_content}')
        # Extract the command output between the two PS1 prompts
        raw_command_output = self._combine_outputs_between_matches(
            pane_content,
            ps1_matches,
            get_content_before_last_match=get_content_before_last_match,
        )

        if get_content_before_last_match:
            # Count the number of lines in the truncated output
            num_lines = len(raw_command_output.splitlines())
            metadata.prefix = f'[Previous command outputs are truncated. Showing the last {num_lines} lines of the output below.]\n'

        metadata.suffix = (
            f'\n[The command completed with exit code {metadata.exit_code}.]'
            if not is_special_key
            else f'\n[The command completed with exit code {metadata.exit_code}. CTRL+{command[-1].upper()} was sent.]'
        )
        command_output = self._get_command_output(
            command,
            raw_command_output,
            metadata,
            continue_prefix=(
                ''
                if is_followup_input
                else '[Below is the output of the previous command.]\n'
            ),
        )
        self.prev_status = BashCommandStatus.COMPLETED
        self.prev_output = ''  # Reset previous command output
        self.current_command = None
        self.current_pid = None
        self._ready_for_next_command()
        return CmdOutputObservation(
            content=command_output,
            command=command,
            metadata=metadata,
            is_partial=False,
        )

    def _handle_nochange_timeout_command(
        self,
        command: str,
        pane_content: str,
        ps1_matches: list[re.Match],
    ) -> CmdOutputObservation:
        self.prev_status = BashCommandStatus.NO_CHANGE_TIMEOUT
        if len(ps1_matches) != 1:
            logger.warning(
                'Expected exactly one PS1 metadata block BEFORE the execution of a command, '
                f'but got {len(ps1_matches)} PS1 metadata blocks:\n---\n{pane_content!r}\n---'
            )
        raw_command_output = self._combine_outputs_between_matches(
            pane_content, ps1_matches
        )
        metadata = CmdOutputMetadata()  # No metadata available
        metadata.suffix = (
            f'\n[The command has no new output after {self.NO_CHANGE_TIMEOUT_SECONDS} seconds. '
            f'{TIMEOUT_MESSAGE_TEMPLATE}]'
        )
        metadata.pid = self.current_pid if self.current_pid is not None else -1
        command_output = self._get_command_output(
            command,
            raw_command_output,
            metadata,
            continue_prefix='[Below is the output of the previous command.]\n',
        )
        return CmdOutputObservation(
            content=command_output,
            command=command,
            metadata=metadata,
            is_partial=False,
        )

    def _handle_hard_timeout_command(
        self,
        command: str,
        pane_content: str,
        ps1_matches: list[re.Match],
        timeout: float,
    ) -> CmdOutputObservation:
        self.prev_status = BashCommandStatus.HARD_TIMEOUT
        if len(ps1_matches) != 1:
            logger.warning(
                'Expected exactly one PS1 metadata block BEFORE the execution of a command, '
                f'but got {len(ps1_matches)} PS1 metadata blocks:\n---\n{pane_content!r}\n---'
            )
        raw_command_output = self._combine_outputs_between_matches(
            pane_content, ps1_matches
        )
        metadata = CmdOutputMetadata()  # No metadata available
        metadata.pid = -1
        metadata.suffix = (
            f'\n[The command timed out after {timeout} seconds. '
            f'{TIMEOUT_MESSAGE_TEMPLATE}]'
        )
        command_output = self._get_command_output(
            command,
            raw_command_output,
            metadata,
            continue_prefix='[Below is the output of the previous command.]\n',
        )
        return CmdOutputObservation(
            command=command,
            content=command_output,
            metadata=metadata,
            is_partial=False,
        )

    def _ready_for_next_command(self) -> None:
        """Reset the content buffer for a new command."""
        # Clear the current content
        self._clear_screen()

    def _combine_outputs_between_matches(
        self,
        pane_content: str,
        ps1_matches: list[re.Match],
        get_content_before_last_match: bool = False,
    ) -> str:
        """Combine all outputs between PS1 matches.

        Args:
            pane_content: The full pane content containing PS1 prompts and command outputs
            ps1_matches: List of regex matches for PS1 prompts
            get_content_before_last_match: when there's only one PS1 match, whether to get
                the content before the last PS1 prompt (True) or after the last PS1 prompt (False)
        Returns:
            Combined string of all outputs between matches
        """
        if len(ps1_matches) == 1:
            if get_content_before_last_match:
                # The command output is the content before the last PS1 prompt
                return pane_content[: ps1_matches[0].start()]
            else:
                # The command output is the content after the last PS1 prompt
                return pane_content[ps1_matches[0].end() + 1 :]
        elif len(ps1_matches) == 0:
            return pane_content
        combined_output = ''
        for i in range(len(ps1_matches) - 1):
            # Extract content between current and next PS1 prompt
            output_segment = pane_content[
                ps1_matches[i].end() + 1 : ps1_matches[i + 1].start()
            ]
            combined_output += output_segment + '\n'
        # Add the content after the last PS1 prompt
        combined_output += pane_content[ps1_matches[-1].end() + 1 :]
        logger.debug(f'COMBINED OUTPUT: {combined_output}')
        return combined_output

    def _tmux_died_obs(self) -> ErrorObservation:
        self.prev_status = BashCommandStatus.COMPLETED
        self.current_command = None
        self.current_pid = None
        return ErrorObservation(
            content=(
                "tmux session became unhealthy (likely killed). "
                "Slot will be restarted automatically for the next command."
            ),
            error_id="AGENT_ERROR$TMUX_SESSION_DIED",
        )

    # =========================
    # Monitoring / slot helpers
    # =========================

    def get_status_snapshot(self, *, refresh: bool = True) -> dict[str, object]:
        """Return a best-effort status snapshot for monitoring/watchers.

        This is intentionally lightweight and side-effect free (except for optional
        pane capture to refresh the internal tail buffer).

        Returns keys:
          - pid: foreground PID if detected, else None
          - prompt_at_bottom: whether the pane currently ends with the PS1 marker
          - tail: recent output tail (best-effort)
          - last_output_time: epoch seconds when tail last changed (best-effort)
        """

        pane_content = ''
        prompt_at_bottom = False
        if refresh:
            try:
                pane_content = self._get_pane_content()
            except Exception:
                pane_content = ''
        if pane_content:
            prompt_at_bottom = self._prompt_at_bottom(pane_content)

        pid: int | None = None
        try:
            pid = self.discover_foreground_pid()
        except Exception:
            pid = getattr(self, 'current_pid', None)

        tail = ''
        try:
            tail = self.get_tail()
        except Exception:
            tail = ''

        lot = getattr(self, 'last_output_time', None)

        return {
            'pid': pid,
            'prompt_at_bottom': prompt_at_bottom,
            'tail': tail,
            'last_output_time': lot,
        }

    def get_tail(self) -> str:
        return '\n'.join(list(self._tail_lines))

    def _refresh_pane_tty(self) -> str | None:
        if not self._initialized or self._closed:
            return None
        try:
            tty = self._tmux.display_message(self.pane, format_str='#{pane_tty}') or ''
            if tty:
                self._pane_tty = tty
            return self._pane_tty
        except Exception:
            return self._pane_tty

    def is_healthy(self) -> bool:
        if not self._initialized or self._closed:
            return False

        session_name: str | None = None
        try:
            session_name = self.session.get('session_name')
        except Exception:
            session_name = None

        return self._tmux.is_healthy(
            pane_id=getattr(self, '_pane_id', None),
            session_name=session_name,
        )

    def restart(self) -> None:
        logger.info(f"BashSession.restart: restarting session (slot_id={getattr(self, 'slot_id', 'unknown')})")
        try:
            self.close()
        except Exception:
            # Best-effort: pane may already be gone.
            logger.debug(f"BashSession.restart: error during close (slot_id={getattr(self, 'slot_id', 'unknown')})", exc_info=True)
        self._closed = False
        self._initialized = False
        self.initialize()
        logger.info(f"BashSession.restart: session restarted successfully (slot_id={getattr(self, 'slot_id', 'unknown')})")

    # =========================
    # Stop / cancel primitives
    # =========================

    def interrupt(self) -> None:
        if not self._initialized or self._closed:
            logger.debug(f"BashSession.interrupt: skipping (not initialized or closed, slot_id={getattr(self, 'slot_id', 'unknown')})")
            return
        logger.debug(f"BashSession.interrupt: sending Ctrl+C (slot_id={getattr(self, 'slot_id', 'unknown')})")
        try:
            self._tmux.send_keys(self.pane, 'C-c', enter=False)
        except Exception:
            # Best-effort: pane may already be gone.
            logger.debug(f"BashSession.interrupt: failed to send Ctrl+C (slot_id={getattr(self, 'slot_id', 'unknown')})", exc_info=True)

    def quit(self) -> None:
        """Send Ctrl+\\ (SIGQUIT) to the foreground process best-effort."""
        if not self._initialized or self._closed:
            logger.debug(f"BashSession.quit: skipping (not initialized or closed, slot_id={getattr(self, 'slot_id', 'unknown')})")
            return
        logger.debug(f"BashSession.quit: sending Ctrl+\\ SIGQUIT (slot_id={getattr(self, 'slot_id', 'unknown')})")
        try:
            self._tmux.send_keys(self.pane, 'C-\\', enter=False)
        except Exception:
            # Best-effort: pane may already be gone.
            logger.debug(f"BashSession.quit: failed to send Ctrl+\\ (slot_id={getattr(self, 'slot_id', 'unknown')})", exc_info=True)

    def _send_command_or_input_to_pane(self, *, command: str, is_input: bool) -> None:
        if command == '':
            return

        is_special_key = self._is_special_key(command)
        if is_input:
            logger.debug(f'SENDING INPUT TO RUNNING PROCESS: {command!r}')
            self._tmux.send_keys(self.pane, command, enter=not is_special_key)
            return

        to_send = escape_bash_special_chars(command)
        logger.debug(f'SENDING COMMAND: {to_send!r}')
        self._tmux.send_keys(self.pane, to_send, enter=not is_special_key)

    @staticmethod
    def is_background_command(command: str) -> bool:
        """Backwards-compatible wrapper for shared background detection."""

        return _is_background_command(command)

    def discover_foreground_pid(self) -> int | None:
        logger.debug(f"BashSession.discover_foreground_pid: discovering PID (slot_id={getattr(self, 'slot_id', 'unknown')})")
        tty = self._refresh_pane_tty()
        if not tty:
            logger.debug(f"BashSession.discover_foreground_pid: no TTY found (slot_id={getattr(self, 'slot_id', 'unknown')})")
            return None
        try:
            out = subprocess.check_output(
                ['ps', '-t', tty, '-o', 'pid=,stat=,comm=,args='],
                text=True,
                stderr=subprocess.STDOUT,
                timeout=3,
            )
            candidates = []
            for line in out.splitlines():
                line = line.strip()
                if not line:
                    continue
                parts = line.split(None, 3)
                if len(parts) < 3:
                    continue
                pid = int(parts[0])
                stat = parts[1]
                comm = parts[2]
                args = parts[3] if len(parts) > 3 else comm
                # Ignore helper/management processes so we only track the actual
                # foreground command running in the pane.
                comm_lower = comm.lower()
                if comm_lower in _FOREGROUND_HELPER_COMMANDS:
                    continue
                candidates.append((pid, stat, comm, args))
            # Prefer foreground (+)
            for pid, stat, *_ in candidates:
                if '+' in stat:
                    self.current_pid = pid
                    logger.debug(f"BashSession.discover_foreground_pid: found foreground PID {pid} (slot_id={getattr(self, 'slot_id', 'unknown')})")
                    return pid
            if candidates:
                pid = candidates[-1][0]
                self.current_pid = pid
                logger.debug(f"BashSession.discover_foreground_pid: found candidate PID {pid} (slot_id={getattr(self, 'slot_id', 'unknown')})")
                return pid
        except Exception:
            logger.debug(f"BashSession.discover_foreground_pid: exception during discovery, returning current_pid={self.current_pid} (slot_id={getattr(self, 'slot_id', 'unknown')})", exc_info=True)
            return self.current_pid
        logger.debug(f"BashSession.discover_foreground_pid: no PID found (slot_id={getattr(self, 'slot_id', 'unknown')})")
        return None

    def terminate(self) -> None:
        pid = self.discover_foreground_pid()
        if pid is None:
            logger.debug(f"BashSession.terminate: no PID found, falling back to interrupt (slot_id={getattr(self, 'slot_id', 'unknown')})")
            self.interrupt()
            return
        logger.debug(f"BashSession.terminate: sending SIGTERM to PID {pid} (slot_id={getattr(self, 'slot_id', 'unknown')})")
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            logger.warning(f"BashSession.terminate: SIGTERM failed for PID {pid}, falling back to interrupt (slot_id={getattr(self, 'slot_id', 'unknown')})", exc_info=True)
            try:
                self.interrupt()
            except Exception:
                logger.exception(f"BashSession.terminate: failed to send interrupt after SIGTERM failure (slot_id={getattr(self, 'slot_id', 'unknown')})")

    def kill(self) -> None:
        pid = self.discover_foreground_pid()
        if pid is None:
            logger.debug(f"BashSession.kill: no PID found (slot_id={getattr(self, 'slot_id', 'unknown')})")
            return
        logger.debug(f"BashSession.kill: sending SIGKILL to PID {pid} (slot_id={getattr(self, 'slot_id', 'unknown')})")
        try:
            os.kill(pid, signal.SIGKILL)
        except Exception:
            # Best-effort: pane may already be gone.
            logger.debug(f"BashSession.kill: SIGKILL failed for PID {pid} (slot_id={getattr(self, 'slot_id', 'unknown')})", exc_info=True)

    def execute(
        self,
        action: CmdRunAction,
        log_callback: Callable[[str], None] | None = None
    ) -> CmdOutputObservation | ErrorObservation:
        """Execute a command in the bash session.

        Args:
            action: The command action to execute
            log_callback: Optional callback to receive incremental output deltas
        """
        if not self._initialized:
            raise RuntimeError('Bash session is not initialized')

        # Strip the command of any leading/trailing whitespace
        logger.debug(f'RECEIVED ACTION: {action}')
        command = action.command.strip()
        is_input: bool = action.is_input

         # detect dead tmux early and return sentinel obs
        if not self.is_healthy():
            return self._tmux_died_obs()

        # When polling a still-running command (action.command == ''), keep a stable
        # command string for observations/monitoring so it doesn't appear as empty.
        command_for_obs = command if command != '' else (self.current_command or '')

        # If the previous command is not completed, we need to check if the command is empty
        if self.prev_status not in {
            BashCommandStatus.CONTINUE,
            BashCommandStatus.NO_CHANGE_TIMEOUT,
            BashCommandStatus.HARD_TIMEOUT,
        }:
            if command == '':
                return CmdOutputObservation(
                    content='ERROR: No previous running command to retrieve logs from.',
                    command='',
                    metadata=CmdOutputMetadata(),
                )
            if is_input:
                return CmdOutputObservation(
                    content='ERROR: No previous running command to interact with.',
                    command='',
                    metadata=CmdOutputMetadata(),
                )

        # Check if the command is a single command or multiple commands
        splited_commands = split_bash_commands(command)

        # Block overly broad cleanup that can kill the agent/runtime itself
        if should_block_dangerous_pkill_python(commands=splited_commands, is_input=is_input):
            msg = dangerous_pkill_python_error_message(
                list_python_processes=_list_python_processes
            )
            return CmdOutputObservation(
                content=msg,
                command=command,
                metadata=CmdOutputMetadata(),
            )

        if len(splited_commands) > 1:
            # Use tempfile for secure temporary file creation with proper permissions
            # delete=False because we need to execute it with bash before removing it
            with tempfile.NamedTemporaryFile(
                mode='w',
                suffix='.sh',
                dir=self.work_dir,
                delete=False,
                prefix='keplore_cmd_',
            ) as f:
                f.write(command + '\n')
                temp_script_path = f.name
            # Execute and clean up the temp script
            # The rm command ensures cleanup even if bash execution fails
            command = f'bash {temp_script_path}; rm {temp_script_path}'

        # Start every NEW non-input command from a clean pane.
        # This prevents cancelled/old command history from reappearing
        # in the "background terminal" tail monitoring.
        if not is_input and command != '':
            try:
                self._clear_screen()
            except Exception:
                # best-effort; if clear fails we still proceed
                pass

            try:
                self._tail_lines.clear()
            except Exception:
                logger.debug('Failed to clear _tail_lines buffer before starting new command', exc_info=True)

            self.prev_output = ''
            self.last_output_time = None

        # Get initial state before sending command
        try:
            initial_pane_output = self._get_pane_content()
        except Exception:
            if not self.is_healthy():
                return self._tmux_died_obs()
            raise

        (
            initial_pane_output,
            initial_ps1_matches,
            initial_ps1_count,
            initial_prompt_at_bottom,
        ) = self._get_initial_prompt_state(
            initial_pane_output,
            command=command,
            is_input=is_input,
        )

        start_time = time.time()
        last_change_time = start_time
        last_pane_output = (
            initial_pane_output  # Use initial output as the starting point
        )

        # If we're polling a previously-started command (command == ''), it may have
        # already completed since the last call. If the prompt is already at the bottom,
        # treat it as completed immediately.
        if (
            command == ''
            and self.prev_status
            in {
                BashCommandStatus.CONTINUE,
                BashCommandStatus.NO_CHANGE_TIMEOUT,
                BashCommandStatus.HARD_TIMEOUT,
            }
            and initial_prompt_at_bottom
            and initial_ps1_matches
        ):
            return self._handle_completed_command(
                command_for_obs,
                pane_content=initial_pane_output,
                ps1_matches=initial_ps1_matches,
            )

        # When prev command is still running, and we are trying to send a new command
        if (
            self.prev_status
            in {
                BashCommandStatus.HARD_TIMEOUT,
                BashCommandStatus.NO_CHANGE_TIMEOUT,
            }
            and not self._prompt_at_bottom(last_pane_output)  # prev command is not completed
            and not is_input
            and command != ''  # not input and not empty command
        ):
            _ps1_matches = CmdOutputMetadata.matches_ps1_metadata(last_pane_output)
            # Use initial_ps1_matches if _ps1_matches is empty, otherwise use _ps1_matches
            # This handles the case where the prompt might be scrolled off screen but existed before
            current_matches_for_output = (
                _ps1_matches if _ps1_matches else initial_ps1_matches
            )
            raw_command_output = self._combine_outputs_between_matches(
                last_pane_output, current_matches_for_output
            )
            prev_cmd = getattr(self, 'current_command', None)
            if prev_cmd:
                raw_command_output = _remove_command_prefix(raw_command_output, prev_cmd)
            metadata = CmdOutputMetadata()  # No metadata available
            metadata.prefix = '[Below is the output of the previous command.]\n'
            metadata.suffix = (
                f'\n[Your command "{command}" is NOT executed. '
                f'The previous command is still running - You CANNOT send new commands until the previous command is completed. '
                'By setting `is_input` to `true`, you can interact with the current process: '
                "You may wait longer to see additional output of the previous command by sending empty command '', "
                'send other commands to interact with the current process, '
                'or send keys ("C-c", "C-z", "C-d") to interrupt/kill the previous command before sending your new command.]'
            )
            logger.debug(f'PREVIOUS COMMAND OUTPUT: {raw_command_output}')
            command_output = self._get_command_output(
                command,
                raw_command_output,
                metadata,
                continue_prefix='',
            )
            return CmdOutputObservation(
                command=command,
                content=command_output,
                metadata=metadata,
            )
        # Record current command for monitoring
        if not is_input and command != '':
            self.current_command = command
            self.current_pid = None

        # Send actual command/inputs to the pane
        try:
            self._send_command_or_input_to_pane(command=command, is_input=is_input)
        except Exception:
            if not self.is_healthy():
                return self._tmux_died_obs()
            raise

        # Track whether pane content has changed since we started waiting.
        # This avoids falsely treating an already-visible idle prompt as completion.
        is_followup_input = bool(is_input and command != '')
        return self._poll_until_command_finishes(
            action=action,
            command=command,
            command_for_obs=command_for_obs,
            initial_pane_output=initial_pane_output,
            initial_ps1_count=initial_ps1_count,
            start_time=start_time,
            last_change_time=last_change_time,
            last_pane_output=last_pane_output,
            log_callback=log_callback,
            is_followup_input=is_followup_input,
        )
