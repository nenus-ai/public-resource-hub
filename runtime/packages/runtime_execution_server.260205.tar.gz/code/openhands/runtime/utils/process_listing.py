import subprocess

from openhands.core.logger import openhands_logger as logger


def _list_python_processes(max_lines: int = 30) -> str:
    """
    Best-effort process list to help user pick a PID/pattern safely.
    Runs on the same machine/container as the runtime.
    """
    try:
        out = subprocess.check_output(
            ["ps", "-eo", "pid,ppid,etime,args"],
            text=True,
            stderr=subprocess.STDOUT,
            timeout=5,
        )
        lines = out.splitlines()
        header = lines[:1]
        body = [ln for ln in lines[1:] if "python" in ln.lower()][:max_lines]
        if not body:
            body = ["(no python processes found)"]
        return "\n".join(header + body)
    except Exception as e:
        logger.debug(f"Failed to list python processes: {e}")
        return "(failed to list processes)"
