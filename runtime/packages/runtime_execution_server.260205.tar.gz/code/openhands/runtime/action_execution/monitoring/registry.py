from __future__ import annotations

import asyncio
import time
from typing import Any

from openhands.runtime.model.running_commands import (
    RunningCommandEntry,
    RunningCommandStatus,
)


class RunningCommandRegistry:
    """In-memory source of truth for what's currently running in the runtime."""

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._entries: dict[str, RunningCommandEntry] = {}  # task_id -> entry

    async def upsert(self, entry: RunningCommandEntry) -> None:
        async with self._lock:
            self._entries[entry.task_id] = entry

    async def update_status(
        self,
        task_id: str,
        status: RunningCommandStatus,
        *,
        tail: str | None = None,
        pid: int | None = None,
    ) -> None:
        async with self._lock:
            e = self._entries.get(task_id)
            if not e:
                return

            terminal = {
                RunningCommandStatus.COMPLETED,
                RunningCommandStatus.FAILED,
                RunningCommandStatus.CANCELLED,
            }
            ranks: dict[RunningCommandStatus, int] = {
                RunningCommandStatus.PENDING: 0,
                RunningCommandStatus.RUNNING: 1,
                RunningCommandStatus.STOPPING: 2,
                RunningCommandStatus.COMPLETED: 3,
                RunningCommandStatus.FAILED: 3,
                RunningCommandStatus.CANCELLED: 3,
            }

            if e.status in terminal:
                pass
            else:
                if ranks.get(status, 0) >= ranks.get(e.status, 0):
                    e.status = status

            if pid is not None:
                e.pid = pid

            if tail is not None:
                prev_tail = e.tail
                e.tail = tail
                if prev_tail != tail:
                    e.last_output_time = time.time()

            self._entries[task_id] = e

    async def update_tail(
        self,
        task_id: str,
        *,
        tail: str | None = None,
        pid: int | None = None,
    ) -> None:
        """Update tail/pid without mutating status."""
        async with self._lock:
            e = self._entries.get(task_id)
            if not e:
                return

            if pid is not None:
                e.pid = pid
            if tail is not None:
                prev_tail = e.tail
                e.tail = tail
                if prev_tail != tail:
                    e.last_output_time = time.time()

            self._entries[task_id] = e

    async def delete(self, task_id: str) -> None:
        async with self._lock:
            self._entries.pop(task_id, None)

    async def list_active(self) -> list[dict[str, Any]]:
        now = time.time()
        async with self._lock:
            result: list[dict[str, Any]] = []
            for e in self._entries.values():
                if e.status in (
                    RunningCommandStatus.PENDING,
                    RunningCommandStatus.RUNNING,
                    RunningCommandStatus.STOPPING,
                ):
                    d = e.model_dump()
                    d['duration_seconds'] = max(0.0, now - e.start_time)
                    result.append(d)

            result.sort(key=lambda x: (x.get('slot_id', ''), x.get('start_time', 0)))
            return result

    async def get(self, task_id: str) -> RunningCommandEntry | None:
        async with self._lock:
            return self._entries.get(task_id)


_RUNNING_REGISTRY = RunningCommandRegistry()


def get_running_registry() -> RunningCommandRegistry:
    return _RUNNING_REGISTRY
