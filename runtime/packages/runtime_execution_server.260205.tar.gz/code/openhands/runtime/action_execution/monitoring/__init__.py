"""Monitoring helpers (workspace state, running commands) for the runtime."""
