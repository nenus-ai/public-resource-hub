from __future__ import annotations

import asyncio
import base64
import mimetypes
import os
import sys
import tempfile
import time
import uuid
from pathlib import Path
from typing import Callable

from openhands_aci.editor.editor import OHEditor

from openhands.core.exceptions import BrowserUnavailableException
from openhands.core.logger import openhands_logger as logger
from openhands.events.action import (
    BrowseInteractiveAction,
    BrowseURLAction,
    CmdRunAction,
    FileEditAction,
    FileReadAction,
    FileWriteAction,
    IPythonRunCellAction,
)
from openhands.events.event import FileEditSource, FileReadSource
from openhands.events.observation import (
    CmdOutputMetadata,
    CmdOutputObservation,
    ErrorObservation,
    FileEditObservation,
    FileReadObservation,
    FileWriteObservation,
    IPythonRunCellObservation,
    Observation,
)
from openhands.runtime.browser import browse
from openhands.runtime.browser.browser_env import BrowserEnv
from openhands.runtime.model.running_commands import (
    RunningCommandEntry,
    RunningCommandStatus,
)
from openhands.runtime.plugins import JupyterPlugin, Plugin, VSCodePlugin
from openhands.runtime.utils.bash import BashSession
from openhands.runtime.utils.files import insert_lines, read_lines
from openhands.runtime.utils.memory_monitor import MemoryMonitor
from openhands.runtime.utils.runtime_init import init_user_and_working_directory
from openhands.runtime.utils.shell_session import ShellSession, is_background_command
from openhands.utils.async_utils import call_sync_from_async, wait_all
from openhands.utils.shutdown_listener import should_continue
from openhands_aci.utils.diff import get_diff

from openhands.runtime.action_execution.executor.file_editor import execute_file_editor
from openhands.runtime.action_execution.executor.session_pool import SessionPool
from openhands.runtime.action_execution.monitoring.registry import get_running_registry

if sys.platform == 'win32':
    from openhands.runtime.utils.windows_bash import WindowsPowershellSession


STOP_CTRL_C_DELAY_SECONDS = float(os.environ.get('STOP_CTRL_C_DELAY_SECONDS', '0.7'))
STOP_SIGQUIT_DELAY_SECONDS = float(os.environ.get('STOP_SIGQUIT_DELAY_SECONDS', '0.7'))
STOP_SIGTERM_DELAY_SECONDS = float(os.environ.get('STOP_SIGTERM_DELAY_SECONDS', '1.2'))
STOP_SIGKILL_DELAY_SECONDS = float(os.environ.get('STOP_SIGKILL_DELAY_SECONDS', '0.5'))

# VSCode plugin initialization can involve cold-start work (server spin-up, extension download).
# Use a longer timeout to avoid flaky startup failures in slower/loaded environments.
VSCODE_INIT_TIMEOUT_S = float(os.environ.get('VSCODE_INIT_TIMEOUT_S', '100.0'))

class ActionExecutor:
    """Executes actions inside the sandbox and returns observations."""

    def __init__(
        self,
        plugins_to_load: list[Plugin],
        work_dir: str,
        username: str,
        user_id: int,
        browsergym_eval_env: str | None,
        idle_life: int | None = None,
    ) -> None:
        self.plugins_to_load = plugins_to_load
        self._initial_cwd = work_dir
        self.username = username
        self.user_id = user_id
        _updated_user_id = init_user_and_working_directory(
            username=username, user_id=self.user_id, initial_cwd=work_dir
        )
        if _updated_user_id is not None:
            self.user_id = _updated_user_id

        self.bash_session: ShellSession | None = None
        self.session_pool = SessionPool(
            lambda slot_id: self._create_bash_session(cwd=self._initial_cwd),
            max_size=int(os.environ.get('SESSION_POOL_MAX_SIZE', '5')),
        )
        self.lock = asyncio.Lock()
        self.plugins: dict[str, Plugin] = {}
        self.file_editor = OHEditor(workspace_root=self._initial_cwd)
        self.browser: BrowserEnv | None = None
        self.browser_init_task: asyncio.Task | None = None
        self.vscode_init_task: asyncio.Task | None = None
        self.browsergym_eval_env = browsergym_eval_env

        self.start_time = time.time()
        self.last_execution_time = self.start_time
        self._initialized = False

        self._current_log_callback: Callable[[str], None] | None = None

        # Background watchers for detached/non-blocking commands that outlive the
        # originating action request (e.g., no-change timeout / hard timeout).
        self._command_watchers_lock = asyncio.Lock()
        self._command_watchers: dict[str, asyncio.Task] = {}

        # Futures for detached/non-blocking commands so the async task layer can
        # await the final observation even after run() returns a partial.
        # The watcher resolves these futures when the command actually completes.
        self._detached_result_lock = asyncio.Lock()
        self._detached_results: dict[str, asyncio.Future[Observation]] = {}

        self._idle_life = idle_life or 90000
        self._idle_timer: asyncio.TimerHandle | None = None
        self._close_lock = asyncio.Lock()
        self._closing: bool = False

        self.max_memory_gb: int | None = None
        if _override_max_memory_gb := os.environ.get('RUNTIME_MAX_MEMORY_GB', None):
            self.max_memory_gb = int(_override_max_memory_gb)
            logger.info(
                f'Setting max memory to {self.max_memory_gb}GB (according to the RUNTIME_MAX_MEMORY_GB environment variable)'
            )
        else:
            logger.info('No max memory limit set, using all available system memory')

        self.memory_monitor = MemoryMonitor(
            enable=os.environ.get('RUNTIME_MEMORY_MONITOR', 'False').lower() in ['true', '1', 'yes']
        )
        self.memory_monitor.start_monitoring()

    @property
    def initial_cwd(self):
        return self._initial_cwd

    @property
    def idle_life(self) -> int:
        return self._idle_life

    @idle_life.setter
    def idle_life(self, value: int) -> None:
        self._idle_life = value

    def update_idle_life(self, life: int) -> None:
        self._idle_life = life
        logger.info(f'Idle life updated to {life} seconds')
        self.cancel_idle_timer()
        if life > 0:
            self.start_idle_timer()

    def start_idle_timer(self) -> None:
        if self._idle_life <= 0:
            return
        self.cancel_idle_timer()
        loop = asyncio.get_event_loop()
        self._idle_timer = loop.call_later(self._idle_life, self._on_idle_timer_expired)

    def cancel_idle_timer(self) -> None:
        if self._idle_timer is not None:
            self._idle_timer.cancel()
            self._idle_timer = None

    def _on_idle_timer_expired(self) -> None:
        logger.info(f'Closing runtime due to inactivity, idle_life {self._idle_life}s')
        loop = asyncio.get_event_loop()
        loop.create_task(self._close_and_exit())

    async def _close_and_exit(self) -> None:
        if self._closing:
            return
        self._closing = True
        try:
            await self.close()
        except Exception:
            logger.exception('Error while closing runtime during shutdown; forcing exit')
        sys.exit(0)

    async def _init_vscode_async(self):
        logger.debug('Initializing VSCode asynchronously')
        try:
            plugin = VSCodePlugin()
            await plugin.initialize(self.username)
            self.plugins['vscode'] = plugin
            logger.debug('VSCode initialized asynchronously')
        except Exception as e:
            logger.error(f'Failed to initialize VSCode: {e}')

    async def _ensure_vscode_ready(self):
        if 'vscode' in self.plugins:
            return
        if self.vscode_init_task is not None and not self.vscode_init_task.done():
            try:
                await asyncio.wait_for(self.vscode_init_task, timeout=VSCODE_INIT_TIMEOUT_S)
            except asyncio.TimeoutError:
                logger.error('VSCode initialization timed out')

    async def _init_browser_async(self):
        if sys.platform == 'win32':
            logger.warning('Browser environment not supported on windows')
            return
        try:
            self.browser = BrowserEnv(self.browsergym_eval_env)
        except Exception as e:
            logger.error(f'Failed to initialize browser: {e}')
            self.browser = None

    async def _ensure_browser_ready(self):
        if self.browser is None:
            raise BrowserUnavailableException('Browser initialization failed')

    def _create_bash_session(self, cwd: str | None = None) -> ShellSession:
        if sys.platform == 'win32':
            return WindowsPowershellSession(  # type: ignore[name-defined]
                work_dir=cwd or self._initial_cwd,
                username=self.username,
                no_change_timeout_seconds=int(os.environ.get('NO_CHANGE_TIMEOUT_SECONDS', 10)),
                max_memory_mb=self.max_memory_gb * 1024 if self.max_memory_gb else None,
            )

        bash_session = BashSession(
            work_dir=cwd or self._initial_cwd,
            username=self.username,
            no_change_timeout_seconds=int(os.environ.get('NO_CHANGE_TIMEOUT_SECONDS', 10)),
            max_memory_mb=self.max_memory_gb * 1024 if self.max_memory_gb else None,
        )
        bash_session.initialize()
        return bash_session

    async def stop_task(self, task_id: str) -> bool:
        """Best-effort stop for a running foreground command by task_id.

        Escalation sequence:
        1) Ctrl+C
        2) Ctrl+\\ (SIGQUIT)
        3) SIGTERM
        4) SIGKILL

        Also validates tmux/session health and restarts the slot if broken.
        """
        logger.info(
            "ActionExecutionClient.stop_task: attempting to stop task (task_id=%s)",
            task_id,
        )
        registry = get_running_registry()
        entry = await registry.get(task_id)
        if entry is None:
            logger.warning(
                "ActionExecutionClient.stop_task: task not found in registry (task_id=%s)",
                task_id,
            )
            return False

        if entry.status in (
            RunningCommandStatus.COMPLETED,
            RunningCommandStatus.FAILED,
            RunningCommandStatus.CANCELLED,
        ):
            logger.info(
                "ActionExecutionClient.stop_task: task already in terminal state (task_id=%s, status=%s)",
                task_id,
                entry.status.value,
            )
            return False

        slot = await self.session_pool.get_slot(entry.slot_id)
        if slot is None:
            logger.warning(
                "ActionExecutionClient.stop_task: slot not found (task_id=%s, slot_id=%s)",
                task_id,
                entry.slot_id,
            )
            return False

        logger.info(
            "ActionExecutionClient.stop_task: marking slot as STOPPING (task_id=%s, slot_id=%s)",
            task_id,
            slot.slot_id,
        )
        await self.session_pool.mark_stopping(slot.slot_id)
        await registry.update_status(task_id, RunningCommandStatus.STOPPING)

        sess = slot.bash_session
        ok = False

        def _pid_alive() -> bool:
            try:
                pid = getattr(sess, "discover_foreground_pid", lambda: None)()
                return pid is not None
            except Exception:
                return False

        try:
            # 1) Ctrl+C
            logger.debug(
                "ActionExecutionClient.stop_task: sending Ctrl+C (task_id=%s, slot_id=%s)",
                task_id,
                slot.slot_id,
            )
            try:
                if hasattr(sess, "interrupt"):
                    sess.interrupt()
                else:
                    pane = getattr(sess, "pane", None)
                    if pane is not None:
                        pane.send_keys("C-c", enter=False)
            except Exception:
                logger.warning(
                    "ActionExecutionClient.stop_task: Ctrl+C failed (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                    exc_info=True,
                )

            await asyncio.sleep(STOP_CTRL_C_DELAY_SECONDS)
            if not _pid_alive():
                logger.info(
                    "ActionExecutionClient.stop_task: process stopped after Ctrl+C (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                )
                ok = True
                return True

            # 2) Ctrl+\\ (SIGQUIT)
            logger.debug(
                "ActionExecutionClient.stop_task: sending Ctrl+\\ SIGQUIT (task_id=%s, slot_id=%s)",
                task_id,
                slot.slot_id,
            )
            try:
                if hasattr(sess, "quit"):
                    sess.quit()
            except Exception:
                logger.warning(
                    "ActionExecutionClient.stop_task: SIGQUIT failed (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                    exc_info=True,
                )

            await asyncio.sleep(STOP_SIGQUIT_DELAY_SECONDS)
            if not _pid_alive():
                logger.info(
                    "ActionExecutionClient.stop_task: process stopped after SIGQUIT (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                )
                ok = True
                return True

            # 3) SIGTERM
            logger.debug(
                "ActionExecutionClient.stop_task: sending SIGTERM (task_id=%s, slot_id=%s)",
                task_id,
                slot.slot_id,
            )
            try:
                if hasattr(sess, "terminate"):
                    sess.terminate()
            except Exception:
                logger.warning(
                    "ActionExecutionClient.stop_task: SIGTERM failed (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                    exc_info=True,
                )

            await asyncio.sleep(STOP_SIGTERM_DELAY_SECONDS)
            if not _pid_alive():
                logger.info(
                    "ActionExecutionClient.stop_task: process stopped after SIGTERM (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                )
                ok = True
                return True

            # 4) SIGKILL
            logger.debug(
                "ActionExecutionClient.stop_task: sending SIGKILL (task_id=%s, slot_id=%s)",
                task_id,
                slot.slot_id,
            )
            try:
                if hasattr(sess, "kill"):
                    sess.kill()
            except Exception:
                logger.warning(
                    "ActionExecutionClient.stop_task: SIGKILL failed (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                    exc_info=True,
                )

            await asyncio.sleep(STOP_SIGKILL_DELAY_SECONDS)
            ok = not _pid_alive()
            if ok:
                logger.info(
                    "ActionExecutionClient.stop_task: process stopped after SIGKILL (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                )
            else:
                logger.warning(
                    "ActionExecutionClient.stop_task: process still alive after all escalation attempts (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                )
            return ok

        finally:
            if ok:
                logger.debug(
                    "ActionExecutionClient.stop_task: clearing pane after successful stop (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                )
                try:
                    if hasattr(sess, "_ready_for_next_command"):
                        sess._ready_for_next_command()  # type: ignore[attr-defined]
                    elif hasattr(sess, "_clear_screen"):
                        sess._clear_screen()  # type: ignore[attr-defined]
                    else:
                        pane = getattr(sess, "pane", None)
                        if pane is not None:
                            pane.send_keys("C-l", enter=False)
                except Exception:
                    logger.warning(
                        "ActionExecutionClient.stop_task: failed to clear pane after successful stop (task_id=%s, slot_id=%s)",
                        task_id,
                        slot.slot_id,
                        exc_info=True,
                    )

            logger.debug(
                "ActionExecutionClient.stop_task: checking session health (task_id=%s, slot_id=%s)",
                task_id,
                slot.slot_id,
            )
            try:
                healthy = getattr(sess, "is_healthy", lambda: True)()
                if not healthy and hasattr(sess, "restart"):
                    logger.warning(
                        "ActionExecutionClient.stop_task: session unhealthy, restarting (task_id=%s, slot_id=%s)",
                        task_id,
                        slot.slot_id,
                    )
                    sess.restart()
                    logger.info(
                        "ActionExecutionClient.stop_task: session restarted successfully (task_id=%s, slot_id=%s)",
                        task_id,
                        slot.slot_id,
                    )
                elif not healthy:
                    logger.warning(
                        "ActionExecutionClient.stop_task: session unhealthy but no restart method available (task_id=%s, slot_id=%s)",
                        task_id,
                        slot.slot_id,
                    )
            except Exception:
                logger.warning(
                    "ActionExecutionClient.stop_task: error while checking or restarting bash session (task_id=%s, slot_id=%s)",
                    task_id,
                    slot.slot_id,
                    exc_info=True,
                )

            if ok:
                logger.info(
                    "ActionExecutionClient.stop_task: updating registry status to CANCELLED (task_id=%s)",
                    task_id,
                )
                try:
                    await registry.update_status(task_id, RunningCommandStatus.CANCELLED)
                except Exception:
                    logger.warning(
                        "ActionExecutionClient.stop_task: failed to update registry status (task_id=%s)",
                        task_id,
                        exc_info=True,
                    )

                # If this command was detached (run() returned partial and a watcher owns finalization),
                # we must cancel the watcher and release the slot here. Otherwise the UI stays BUSY.
                async with self._command_watchers_lock:
                    watcher = self._command_watchers.pop(task_id, None)
                was_detached = watcher is not None
                if watcher is not None and not watcher.done():
                    watcher.cancel()
                    try:
                        await watcher
                    except asyncio.CancelledError:
                        pass

                if was_detached:
                    # Unblock any async waiter on the detached command.
                    await self._resolve_detached_future(
                        task_id, ErrorObservation('Cancelled', error_id='CANCELLED')
                    )
                    try:
                        await self.session_pool.release(slot.slot_id)
                    except Exception:
                        logger.warning(
                            "ActionExecutionClient.stop_task: failed to release slot after stop (task_id=%s, slot_id=%s)",
                            task_id,
                            slot.slot_id,
                            exc_info=True,
                        )

    async def ainit(self):
        logger.debug('Initializing bash session pool (slot S0)')
        try:
            await self.session_pool.ensure_min_slots(1)
            s0 = await self.session_pool.get_slot('S0')
            if s0 is None:
                raise RuntimeError('Failed to create primary bash slot S0')
            self.bash_session = s0.bash_session
        except Exception as e:
            logger.error('Failed to initialize bash session pool: %s', e, exc_info=True)
            self.bash_session = self._create_bash_session()

        self.vscode_init_task = asyncio.create_task(self._init_vscode_async())

        await wait_all(
            (self._init_plugin(plugin) for plugin in self.plugins_to_load),
            timeout=int(os.environ.get('INIT_PLUGIN_TIMEOUT', '120')),
        )

        if 'agent_skills' in self.plugins and 'jupyter' in self.plugins:
            obs = await self.run_ipython(
                IPythonRunCellAction(code='from openhands.runtime.plugins.agent_skills.agentskills import *\n')
            )
            logger.debug(f'AgentSkills initialized: {obs}')

        await self._init_bash_commands()
        self._initialized = True

    @property
    def initialized(self) -> bool:
        return self._initialized

    async def _init_plugin(self, plugin: Plugin):
        assert self.bash_session is not None
        await plugin.initialize(self.username)
        self.plugins[plugin.name] = plugin

        if isinstance(plugin, JupyterPlugin):
            cwd = self.bash_session.cwd.replace('\\', '/')
            await self.run_ipython(IPythonRunCellAction(code=f'import os; os.chdir(r"{cwd}")'))

    async def _init_bash_commands(self):
        INIT_COMMANDS: list[str] = []
        is_local_runtime = os.environ.get('LOCAL_RUNTIME_MODE') == '1'
        is_windows = sys.platform == 'win32'

        # Determine git config commands based on platform and runtime mode
        if is_local_runtime:
            if is_windows:
                # Windows, local - split into separate commands
                INIT_COMMANDS.append(
                    'git config --file ./.git_config user.name "keplore-ai"'
                )
                INIT_COMMANDS.append(
                    'git config --file ./.git_config user.email "keplore@keploreai.com"'
                )
                INIT_COMMANDS.append(
                    '$env:GIT_CONFIG = (Join-Path (Get-Location) ".git_config")'
                )
            else:
                # Linux/macOS, local
                base_git_config = (
                    'git config --file ./.git_config user.name "keplore-ai" && '
                    'git config --file ./.git_config user.email "keplore@keploreai.com" && '
                    'export GIT_CONFIG=$(pwd)/.git_config'
                )
                INIT_COMMANDS.append(base_git_config)
        else:
            # Non-local (implies Linux/macOS)
            base_git_config = (
                'git config --global user.name "keplore-ai" && '
                'git config --global user.email "keplore@keploreai.com"'
            )
            INIT_COMMANDS.append(base_git_config)

        # Determine no-pager command
        if is_windows:
            no_pager_cmd = 'function git { git.exe --no-pager $args }'
        else:
            no_pager_cmd = 'alias git="git --no-pager"'

        INIT_COMMANDS.append(no_pager_cmd)

        logger.info(f'Initializing by running {len(INIT_COMMANDS)} bash commands...')
        for command in INIT_COMMANDS:
            action = CmdRunAction(command=command)
            action.set_hard_timeout(300)
            logger.debug(f'Executing init command: {command}')
            # Init commands should NOT go through the session pool.
            # They are part of runtime bootstrap and must be maximally reliable.
            assert self.bash_session is not None
            obs = await call_sync_from_async(
                self.bash_session.execute, action, self._current_log_callback
            )

            # If init fails, crash with actionable log instead of AssertionError
            # Init commands are required for a healthy runtime; failing fast is intentional.
            if isinstance(obs, ErrorObservation):
                logger.error(f'Init command failed: {command}. Error: {obs.content}')
                raise RuntimeError(f'Init command failed: {command}: {obs.content}')
            if not isinstance(obs, CmdOutputObservation):
                logger.error(
                    f'Unexpected init observation type: {type(obs)} for command: {command}'
                )
                raise RuntimeError(
                    f'Unexpected init observation type: {type(obs)} for command: {command}'
                )

            logger.debug(
                f'Init command outputs (exit code: {obs.exit_code}): {obs.content}'
            )
            if obs.exit_code != 0:
                raise RuntimeError(
                    f'Init command returned non-zero exit code {obs.exit_code}: {command}'
                )

        logger.debug('Bash init commands completed')

    async def run_action(self, action) -> Observation:
        if isinstance(action, CmdRunAction):
            # CmdRunAction can be long-running and uses SessionPool for concurrency control.
            # Avoid holding the executor-wide lock to prevent head-of-line blocking.
            return await self.run(action)

        async with self.lock:
            action_type = action.action
            return await getattr(self, action_type)(action)

    async def _start_command_watcher(self, *, task_id: str, slot_id: str) -> None:
        """Start (or no-op if already running) a background watcher for a task."""
        async with self._command_watchers_lock:
            existing = self._command_watchers.get(task_id)
            if existing is not None and not existing.done():
                return
            t = asyncio.create_task(
                self._watch_command_until_complete(task_id=task_id, slot_id=slot_id)
            )
            self._command_watchers[task_id] = t

    async def _get_or_create_detached_future(self, task_id: str) -> asyncio.Future[Observation]:
        """Return a Future that resolves when a detached command finishes.

        run() creates the future when it returns a partial observation; the background
        watcher resolves it when the command reaches a terminal state.
        """
        async with self._detached_result_lock:
            fut = self._detached_results.get(task_id)
            if fut is None or fut.cancelled():
                fut = asyncio.get_running_loop().create_future()
                self._detached_results[task_id] = fut
            return fut

    async def _resolve_detached_future(self, task_id: str, obs: Observation) -> None:
        """Resolve a detached command Future, if one exists (or create one for late waiters)."""
        async with self._detached_result_lock:
            fut = self._detached_results.get(task_id)
            if fut is None or fut.cancelled():
                fut = asyncio.get_running_loop().create_future()
                self._detached_results[task_id] = fut
            if not fut.done():
                fut.set_result(obs)

    async def wait_for_detached_result(self, task_id: str, *, timeout: float | None = None) -> CmdOutputObservation:
        """Wait for the final observation of a detached/non-blocking command.

        This is used by the async task layer to keep task status RUNNING until
        the command truly completes, even when the initial run() returns a partial.
        """
        async with self._detached_result_lock:
            fut = self._detached_results.get(task_id)

        if fut is None:
            # Fallback: synthesize a result if the registry is already terminal.
            registry = get_running_registry()
            entry = await registry.get(task_id)
            if entry is not None and entry.status in (
                RunningCommandStatus.COMPLETED,
                RunningCommandStatus.FAILED,
                RunningCommandStatus.CANCELLED,
            ):
                exit_code = 0 if entry.status == RunningCommandStatus.COMPLETED else (1 if entry.status == RunningCommandStatus.FAILED else -1)
                return CmdOutputObservation(
                    content=entry.tail or '',
                    command=entry.command or '',
                    metadata=CmdOutputMetadata(
                        exit_code=exit_code,
                        pid=entry.pid if entry.pid is not None else -1,
                    ),
                    is_partial=False,
                    runtime_task_id=task_id,
                )

            fut = await self._get_or_create_detached_future(task_id)

        obs_any: Observation
        if timeout is not None:
            obs_any = await asyncio.wait_for(fut, timeout=timeout)
        else:
            obs_any = await fut

        # Best-effort cleanup to avoid unbounded growth.
        async with self._detached_result_lock:
            self._detached_results.pop(task_id, None)

        if isinstance(obs_any, CmdOutputObservation):
            obs_any.runtime_task_id = task_id
            return obs_any

        if isinstance(obs_any, ErrorObservation):
            return CmdOutputObservation(
                content=(obs_any.content or '')[-2000:],
                command='',
                metadata=CmdOutputMetadata(exit_code=1, pid=-1),
                is_partial=False,
                runtime_task_id=task_id,
            )

        # Unexpected observation type; still return a CmdOutputObservation to satisfy the contract.
        return CmdOutputObservation(
            content=str(obs_any)[-2000:],
            command='',
            metadata=CmdOutputMetadata(exit_code=1, pid=-1),
            is_partial=False,
            runtime_task_id=task_id,
        )

    async def _watch_command_until_complete(self, *, task_id: str, slot_id: str) -> None:
        registry = get_running_registry()
        poll_action = CmdRunAction(command='')
        terminal = {
            RunningCommandStatus.COMPLETED,
            RunningCommandStatus.FAILED,
            RunningCommandStatus.CANCELLED,
        }
        last_refresh = 0.0
        try:
            while should_continue():
                entry = await registry.get(task_id)
                if entry is None:
                    await self._resolve_detached_future(
                        task_id,
                        ErrorObservation(f'Detached task {task_id} disappeared from registry.'),
                    )
                    # Best-effort: avoid leaking the slot if the registry entry vanished.
                    try:
                        await self.session_pool.release(slot_id)
                    except Exception:
                        logger.debug(
                            'Watcher: failed to release slot %s for missing task %s',
                            slot_id,
                            task_id,
                            exc_info=True,
                        )
                    return
                if entry.status in terminal:
                    exit_code = (
                        0
                        if entry.status == RunningCommandStatus.COMPLETED
                        else (1 if entry.status == RunningCommandStatus.FAILED else -1)
                    )
                    await self._resolve_detached_future(
                        task_id,
                        CmdOutputObservation(
                            content=entry.tail or '',
                            command=entry.command or '',
                            metadata={
                                'exit_code': exit_code,
                                'pid': entry.pid if entry.pid is not None else -1,
                            },
                            is_partial=False,
                            runtime_task_id=task_id,
                        ),
                    )
                    await self.session_pool.release(slot_id)
                    return
                slot = await self.session_pool.get_slot(slot_id)
                if slot is None:
                    await self._resolve_detached_future(
                        task_id,
                        ErrorObservation(
                            f'Detached task {task_id} lost its slot {slot_id}; cannot compute final status.'
                        ),
                    )
                    try:
                        await self.session_pool.release(slot_id)
                    except Exception:
                        logger.debug(
                            'Watcher: failed to release slot %s for lost-slot task %s',
                            slot_id,
                            task_id,
                            exc_info=True,
                        )
                    return
                sess = slot.bash_session

                # health check
                try:
                    healthy = getattr(sess, 'is_healthy', lambda: True)()
                except Exception:
                    healthy = True
                if not healthy:
                    msg = 'tmux session became unhealthy (likely killed).'
                    await registry.update_status(task_id, RunningCommandStatus.COMPLETED, tail=msg[-2000:])
                    await self.session_pool.mark_broken(slot_id, reason='AGENT_ERROR$TMUX_SESSION_DIED')
                    await self._resolve_detached_future(
                        task_id,
                        ErrorObservation(msg, error_id='AGENT_ERROR$TMUX_SESSION_DIED'),
                    )
                    await self.session_pool.release(slot_id)
                    return

                now = time.time()
                refresh = (now - last_refresh) > 3.0
                snapshot = {}
                if hasattr(sess, 'get_status_snapshot'):
                    try:
                        snapshot = getattr(sess, 'get_status_snapshot')(refresh=refresh)
                    except Exception:
                        snapshot = {}
                pid = snapshot.get('pid', None) if snapshot else None
                prompt_at_bottom = bool(snapshot.get('prompt_at_bottom', False)) if snapshot else False
                tail = snapshot.get('tail', None) if snapshot else None

                if refresh:
                    last_refresh = now
                await registry.update_tail(task_id, tail=tail)
                try:
                    ent = await registry.get(task_id)
                    if ent is not None:
                        ent.pid = pid
                        await registry.upsert(ent)
                except Exception:
                    logger.debug("Watcher: failed to upsert pid for task_id %s", task_id, exc_info=True)

                if pid is None and prompt_at_bottom:
                    final_obs = await call_sync_from_async(sess.execute, poll_action)

                    if isinstance(final_obs, ErrorObservation):
                        error_id = getattr(final_obs, "error_id", "")
                        status = (
                            RunningCommandStatus.COMPLETED
                            if error_id == "AGENT_ERROR$TMUX_SESSION_DIED"
                            else RunningCommandStatus.FAILED
                        )
                        tail2 = (getattr(final_obs, "content", "") or "")[-2000:] or None
                        await registry.update_status(task_id, status, tail=tail2)
                        await self._resolve_detached_future(task_id, final_obs)
                        if error_id == "AGENT_ERROR$TMUX_SESSION_DIED":
                            await self.session_pool.mark_broken(slot_id, reason=error_id)
                        await self.session_pool.release(slot_id)
                        return

                    if isinstance(final_obs, CmdOutputObservation) and (not final_obs.is_partial):
                        final_obs.runtime_task_id = task_id
                        status = (
                            RunningCommandStatus.COMPLETED
                            if final_obs.metadata.exit_code == 0
                            else RunningCommandStatus.FAILED
                        )
                        tail2 = final_obs.content[-2000:] if final_obs.content else None
                        pid2 = getattr(final_obs.metadata, "pid", None)
                        await registry.update_status(task_id, status, tail=tail2, pid=pid2)
                        await self._resolve_detached_future(task_id, final_obs)
                        await self.session_pool.release(slot_id)
                        return

                    # If we still got a partial observation, do NOT release yet.
                    # Keep polling in the watcher.
                await asyncio.sleep(1.0)
        finally:
            async with self._command_watchers_lock:
                self._command_watchers.pop(task_id, None)

    async def run(self, action: CmdRunAction) -> CmdOutputObservation | ErrorObservation:
        registry = get_running_registry()
        task_id: str = getattr(action, '_runtime_task_id', None) or str(uuid.uuid4())

        # ensure action retains task id for consistency
        setattr(action, "_runtime_task_id", task_id)

        if action.is_static:
            try:
                bash_session = self._create_bash_session(action.cwd)
                try:
                    return await call_sync_from_async(bash_session.execute, action, self._current_log_callback)
                except TypeError:
                    return await call_sync_from_async(bash_session.execute, action)
            except Exception as e:
                return ErrorObservation(str(e))

        slot = await self.session_pool.acquire()
        if slot is None:
            return ErrorObservation('No available execution slots (session pool exhausted).')

        slot.current_task_id = task_id
        slot.current_command = action.command
        slot.started_at = time.time()

        await registry.upsert(
            RunningCommandEntry(
                slot_id=slot.slot_id,
                task_id=task_id,
                command=action.command,
                status=RunningCommandStatus.RUNNING,
                start_time=slot.started_at,
                duration_seconds=0.0,
                last_output_time=None,
                pid=None,
                tail=None,
            )
        )

        async def _monitor_output():
            while should_continue():
                try:
                    e = await registry.get(task_id)
                    if e is None or e.status not in (
                        RunningCommandStatus.RUNNING,
                        RunningCommandStatus.STOPPING,
                    ):
                        return

                    tail = getattr(slot.bash_session, 'get_tail', lambda: None)()
                    await registry.update_tail(task_id, tail=tail)

                    lot = getattr(slot.bash_session, 'last_output_time', None)
                    if lot is not None:
                        ent = await registry.get(task_id)
                        if ent is not None:
                            ent.last_output_time = lot
                            await registry.upsert(ent)

                except asyncio.CancelledError:
                    return
                except Exception:
                    logger.exception('Error while monitoring output for task_id %s', task_id)
                await asyncio.sleep(1.0)

        monitor_task = asyncio.create_task(_monitor_output())
        detached = False
        try:
            # Execute once. If we hit "no-change timeout" (partial output),
            # return immediately and let a backend watcher finalize + release.
            try:
                obs = await call_sync_from_async(
                    slot.bash_session.execute,
                    action,
                    log_callback=self._current_log_callback,
                )
            except TypeError:
                obs = await call_sync_from_async(slot.bash_session.execute, action)

            if isinstance(obs, CmdOutputObservation) and obs.is_partial:
                # expose task id to UI
                obs.runtime_task_id = task_id
                tail = obs.content[-2000:] if obs.content else None
                pid = getattr(obs.metadata, 'pid', None)
                await registry.update_status(
                    task_id,
                    RunningCommandStatus.RUNNING,
                    tail=tail,
                    pid=pid,
                )

                # Ensure Future exists before watcher starts to avoid race.
                await self._get_or_create_detached_future(task_id)

                detached = True
                await self._start_command_watcher(task_id=task_id, slot_id=slot.slot_id)
                return obs

            if isinstance(obs, CmdOutputObservation):
                obs.runtime_task_id = task_id
                status = (
                    RunningCommandStatus.COMPLETED
                    if obs.metadata.exit_code == 0
                    else RunningCommandStatus.FAILED
                )
                tail = obs.content[-2000:] if obs.content else None
                pid = getattr(obs.metadata, 'pid', None)
                await registry.update_status(task_id, status, tail=tail, pid=pid)

            if isinstance(obs, ErrorObservation):
                error_id = getattr(obs, 'error_id', '')
                status = (
                    RunningCommandStatus.COMPLETED
                    if error_id == 'AGENT_ERROR$TMUX_SESSION_DIED'
                    else RunningCommandStatus.FAILED
                )
                tail = (getattr(obs, 'content', '') or '')[-2000:] or None
                await registry.update_status(task_id, status, tail=tail)

                # ensure the next acquire() restarts the slot
                if error_id == 'AGENT_ERROR$TMUX_SESSION_DIED':
                    await self.session_pool.mark_broken(slot.slot_id, reason=error_id)

            return obs

        except asyncio.CancelledError:
            await registry.update_status(task_id, RunningCommandStatus.CANCELLED)
            raise
        except Exception as e:
            await registry.update_status(task_id, RunningCommandStatus.FAILED)
            # if tmux is dead, mark slot broken so it gets restarted
            try:
                healthy = getattr(slot.bash_session, 'is_healthy', lambda: True)()
                if not healthy:
                    await self.session_pool.mark_broken(
                        slot.slot_id, reason='unhealthy after exception'
                    )
            except Exception:
                logger.debug(
                    'Failed to mark session slot %s as broken after exception',
                    getattr(slot, 'slot_id', 'unknown'),
                    exc_info=True,
                )
            return ErrorObservation(str(e))
        finally:
            monitor_task.cancel()
            try:
                await monitor_task
            except asyncio.CancelledError:
                # Swallow the cancellation error since we explicitly cancelled monitor_task above.
                pass
            if not detached:
                await self.session_pool.release(slot.slot_id)

    async def run_ipython(self, action: IPythonRunCellAction) -> Observation:
        assert self.bash_session is not None
        if 'jupyter' not in self.plugins:
            return await self._run_python_fallback(action)

        _jupyter_plugin: JupyterPlugin = self.plugins['jupyter']  # type: ignore
        jupyter_cwd = getattr(self, '_jupyter_cwd', None)
        if self.bash_session.cwd != jupyter_cwd:
            cwd = self.bash_session.cwd.replace('\\', '/')
            reset_jupyter_cwd_code = f'import os; os.chdir("{cwd}")'
            _aux_action = IPythonRunCellAction(code=reset_jupyter_cwd_code)
            _reset_obs: IPythonRunCellObservation = await _jupyter_plugin.run(_aux_action)
            self._jupyter_cwd = self.bash_session.cwd

        obs: IPythonRunCellObservation = await _jupyter_plugin.run(action)
        obs.content = obs.content.rstrip()

        if action.include_extra:
            obs.content += f'\n[Jupyter current working directory: {self.bash_session.cwd}]'
            obs.content += f'\n[Jupyter Python interpreter: {_jupyter_plugin.python_interpreter_path}]'
        return obs

    async def _run_python_fallback(self, action: IPythonRunCellAction) -> IPythonRunCellObservation:
        assert self.bash_session is not None

        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write('import sys, os\n')
            f.write(action.code)
            script_path = f.name

        try:
            cmd = f'python "{script_path}"'
            cmd_action = CmdRunAction(command=cmd)
            if hasattr(action, 'timeout') and action.timeout:
                cmd_action.set_hard_timeout(action.timeout)
            result = self.bash_session.execute(cmd_action)

            if isinstance(result, ErrorObservation):
                return IPythonRunCellObservation(content=f'Error: {result.content}', code=action.code)
            return IPythonRunCellObservation(content=result.content.strip(), code=action.code)
        finally:
            if os.path.exists(script_path):
                os.unlink(script_path)

    def _resolve_path(self, path: str, working_dir: str) -> str:
        filepath = Path(path)
        if not filepath.is_absolute():
            return str(Path(working_dir) / filepath)
        return str(filepath)

    async def read(self, action: FileReadAction) -> Observation:
        assert self.bash_session is not None

        if action.impl_source == FileReadSource.OH_ACI:
            result_str, _ = execute_file_editor(
                self.file_editor,
                command='view',
                path=action.path,
                view_range=action.view_range,
            )

            return FileReadObservation(
                content=result_str,
                path=action.path,
                impl_source=FileReadSource.OH_ACI,
            )

        working_dir = self.bash_session.cwd
        filepath = self._resolve_path(action.path, working_dir)

        try:
            lower = filepath.lower()
            if lower.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
                with open(filepath, 'rb') as file:
                    image_data = file.read()
                    encoded_image = base64.b64encode(image_data).decode('utf-8')
                    mime_type, _ = mimetypes.guess_type(filepath)
                    if mime_type is None:
                        mime_type = 'image/png'
                    encoded_image = f'data:{mime_type};base64,{encoded_image}'
                return FileReadObservation(path=filepath, content=encoded_image)

            if lower.endswith('.pdf'):
                with open(filepath, 'rb') as file:
                    pdf_data = file.read()
                    encoded_pdf = base64.b64encode(pdf_data).decode('utf-8')
                    encoded_pdf = f'data:application/pdf;base64,{encoded_pdf}'
                return FileReadObservation(path=filepath, content=encoded_pdf)

            if lower.endswith(('.mp4', '.webm', '.ogg')):
                with open(filepath, 'rb') as file:
                    video_data = file.read()
                    encoded_video = base64.b64encode(video_data).decode('utf-8')
                    mime_type, _ = mimetypes.guess_type(filepath)
                    if mime_type is None:
                        mime_type = 'video/mp4'
                    encoded_video = f'data:{mime_type};base64,{encoded_video}'
                return FileReadObservation(path=filepath, content=encoded_video)

            with open(filepath, 'r', encoding='utf-8') as file:
                lines = read_lines(file.readlines(), action.start, action.end)

        except FileNotFoundError:
            return ErrorObservation(
                f'File not found: {filepath}. Your current working directory is {working_dir}.'
            )
        except UnicodeDecodeError:
            return ErrorObservation(f'File could not be decoded as utf-8: {filepath}.')
        except IsADirectoryError:
            return ErrorObservation(f'Path is a directory: {filepath}. You can only read files')

        return FileReadObservation(path=filepath, content=''.join(lines))

    async def write(self, action: FileWriteAction) -> Observation:
        assert self.bash_session is not None
        working_dir = self.bash_session.cwd
        filepath = self._resolve_path(action.path, working_dir)

        insert = action.content.split('\n')
        if not os.path.exists(os.path.dirname(filepath)):
            os.makedirs(os.path.dirname(filepath))

        file_exists = os.path.exists(filepath)
        file_stat = os.stat(filepath) if file_exists else None

        mode = 'w' if not file_exists else 'r+'
        try:
            with open(filepath, mode, encoding='utf-8') as file:
                if mode != 'w':
                    all_lines = file.readlines()
                    new_file = insert_lines(insert, all_lines, action.start, action.end)
                else:
                    new_file = [i + '\n' for i in insert]

                file.seek(0)
                file.writelines(new_file)
                file.truncate()

        except FileNotFoundError:
            return ErrorObservation(f'File not found: {filepath}')
        except IsADirectoryError:
            return ErrorObservation(f'Path is a directory: {filepath}. You can only write to files')
        except UnicodeDecodeError:
            return ErrorObservation(f'File could not be decoded as utf-8: {filepath}')

        try:
            if file_exists:
                assert file_stat is not None
                os.chmod(filepath, file_stat.st_mode)
                os.chown(filepath, file_stat.st_uid, file_stat.st_gid)
            else:
                os.chmod(filepath, 0o664)
                os.chown(filepath, self.user_id, self.user_id)
        except PermissionError as e:
            return ErrorObservation(
                f'File {filepath} written, but failed to change ownership and permissions: {e}'
            )

        return FileWriteObservation(content='', path=filepath)

    async def edit(self, action: FileEditAction) -> Observation:
        assert action.impl_source == FileEditSource.OH_ACI
        result_str, (old_content, new_content) = execute_file_editor(
            self.file_editor,
            command=action.command,
            path=action.path,
            file_text=action.file_text,
            old_str=action.old_str,
            new_str=action.new_str,
            insert_line=action.insert_line,
            enable_linting=False,
        )

        return FileEditObservation(
            content=result_str,
            path=action.path,
            old_content=action.old_str,
            new_content=action.new_str,
            impl_source=FileEditSource.OH_ACI,
            diff=get_diff(
                old_contents=old_content or '',
                new_contents=new_content or '',
                filepath=action.path,
            ),
        )

    async def browse(self, action: BrowseURLAction) -> Observation:
        if self.browser is None:
            return ErrorObservation('Browser functionality is not supported on Windows.')
        await self._ensure_browser_ready()
        return await browse(action, self.browser, self.initial_cwd)

    async def browse_interactive(self, action: BrowseInteractiveAction) -> Observation:
        if self.browser is None:
            return ErrorObservation('Browser functionality is not supported on Windows.')
        await self._ensure_browser_ready()
        return await browse(action, self.browser, self.initial_cwd)

    async def close(self):
        async with self._close_lock:
            self.cancel_idle_timer()
            self.memory_monitor.stop_monitoring()

            # Stop any detached command watchers to avoid leaks.
            async with self._command_watchers_lock:
                watchers = list(self._command_watchers.values())
                self._command_watchers.clear()
            for t in watchers:
                t.cancel()
            for t in watchers:
                try:
                    await t
                except asyncio.CancelledError:
                    pass
            if self.bash_session is not None:
                self.bash_session.close()
            if self.browser is not None:
                self.browser.close()
