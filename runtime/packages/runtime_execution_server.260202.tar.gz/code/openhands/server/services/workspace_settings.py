"""Workspace-related utility functions."""

from openhands.core.logger import openhands_logger as logger
from openhands.utils.async_utils import GENERAL_TIMEOUT, call_async_from_sync

MAX_CLOSE_DELAY = 5184000  # 60 days in seconds
MIN_CLOSE_DELAY = 300  # 5 minutes in seconds

async def _get_workspace_close_delay_async(conversation_id: str) -> int | None:
    """Get close_delay from workspace settings for a conversation.

    Args:
        conversation_id: The conversation/session ID

    Returns:
        The close_delay in seconds from workspace settings, or None if not found
    """
    from openhands.storage.db import create_async_session_local
    from openhands.storage.orm.workspace import WorkspaceORM, WorkspaceUserConversationORM
    from sqlalchemy import select

    try:
        async with create_async_session_local() as db_session:
            stmt = (
                select(WorkspaceORM.settings)
                .join(
                    WorkspaceUserConversationORM,
                    WorkspaceORM.id == WorkspaceUserConversationORM.workspace_id
                )
                .where(WorkspaceUserConversationORM.conversation_id == conversation_id)
            )
            result = await db_session.execute(stmt)
            settings = result.scalar_one_or_none()
            if settings and isinstance(settings, dict) and 'close_delay' in settings:
                close_delay = settings['close_delay']
                if MIN_CLOSE_DELAY <= close_delay <= MAX_CLOSE_DELAY:
                    return close_delay
    except Exception as e:
        logger.warning(f'Failed to get workspace close_delay for conversation {conversation_id}: {e}')
    return None


def get_workspace_close_delay(conversation_id: str) -> int | None:
    """Get per workspace close_delay for a conversation.

    Args:
        conversation_id: The conversation/session ID

    Returns:
        The close_delay in seconds or None if not found
    """
    if conversation_id:
        workspace_close_delay = call_async_from_sync(_get_workspace_close_delay_async, GENERAL_TIMEOUT, conversation_id)
        if workspace_close_delay is not None:
            return workspace_close_delay

    return None
