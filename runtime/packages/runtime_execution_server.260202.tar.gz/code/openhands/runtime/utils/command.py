import os

from openhands.core.config import OpenHandsConfig
from openhands.runtime.plugins import PluginRequirement

DEFAULT_PYTHON_PREFIX = [
    '/kepilot/micromamba/bin/micromamba',
    'run',
    '-n',
    'kepilot',
    'poetry',
    'run',
]
DEFAULT_MAIN_MODULE = 'openhands.runtime.action_execution_server'

def get_action_execution_server_startup_command_with_self_update(
    server_port: int,
    plugins: list[PluginRequirement],
    app_config: OpenHandsConfig,
    python_prefix: list[str] = DEFAULT_PYTHON_PREFIX,
    override_user_id: int | None = None,
    override_username: str | None = None,
    main_module: str = DEFAULT_MAIN_MODULE,
) -> list[str]:
    # First, try to use the bundled entrypoint.sh if it exists in the container image.
    # If it doesn't exist, fall back to downloading start.sh from the remote repository.
    # The entrypoint.sh can call or update start.sh as needed for upgrades.
    return [
        "sh",
        "-c",
        "if [ -f /opt/runtime/bootstrap/entrypoint.sh ]; then "
        "bash /opt/runtime/bootstrap/entrypoint.sh; "
        "else "
        "mkdir -p /opt/runtime/bootstrap && "
        "curl -fsSL --max-time 10 -o /opt/runtime/bootstrap/start.sh.new "
        "https://raw.githubusercontent.com/nenus-ai/public-resource-hub/master/runtime/bootstrap/start.sh?$(date +%s) && "
        "mv /opt/runtime/bootstrap/start.sh.new /opt/runtime/bootstrap/start.sh || true; "
        "bash /opt/runtime/bootstrap/start.sh; "
        "fi"
    ]

def get_action_execution_server_startup_command(
    server_port: int,
    plugins: list[PluginRequirement],
    app_config: OpenHandsConfig,
    python_prefix: list[str] = DEFAULT_PYTHON_PREFIX,
    override_user_id: int | None = None,
    override_username: str | None = None,
    main_module: str = DEFAULT_MAIN_MODULE,
) -> list[str]:
    sandbox_config = app_config.sandbox

    # Plugin args
    plugin_args = []
    if plugins is not None and len(plugins) > 0:
        plugin_args = ['--plugins'] + [plugin.name for plugin in plugins]

    # Browsergym stuffs
    browsergym_args = []
    if sandbox_config.browsergym_eval_env is not None:
        browsergym_args = [
            '--browsergym-eval-env'
        ] + sandbox_config.browsergym_eval_env.split(' ')

    username = override_username or (
        'kepilot' if app_config.run_as_openhands else 'root'
    )
    user_id = override_user_id or (
        sandbox_config.user_id if app_config.run_as_openhands else 0
    )

    debug_runtime_enabled = (
        os.getenv('OAIS_DEBUG_RUNTIME', 'false').lower() in ['true', '1', 'yes']
    )
    debugpy_args: list[str] = []
    if debug_runtime_enabled:
        debug_host = os.getenv('OAIS_DEBUG_RUNTIME_HOST', '0.0.0.0')
        debug_port = os.getenv('OAIS_DEBUG_RUNTIME_PORT', '5678')
        debugpy_args = [
            '-m',
            'debugpy',
            '--listen',
            f'{debug_host}:{debug_port}',
            '--wait-for-client',
            '-m',
            main_module,
        ]

    base_cmd = [
        *python_prefix,
        'python',
        '-u',
        *(debugpy_args or ['-m', main_module]),
        str(server_port),
        '--working-dir',
        app_config.workspace_mount_path_in_sandbox,
        *plugin_args,
        '--username',
        username,
        '--user-id',
        str(user_id),
        *browsergym_args,
    ]

    return base_cmd
