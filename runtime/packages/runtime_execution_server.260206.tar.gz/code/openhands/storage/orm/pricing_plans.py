# openhands/storage/orm/pricing_plans.py

import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

from sqlalchemy import JSON, TEXT, Boolean, DateTime, Integer, Numeric, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from openhands.storage.db import Base

if TYPE_CHECKING:
    from openhands.storage.orm.user_subscriptions import UserSubscriptionsORM


class PricingPlansORM(Base):
    __tablename__ = 'oais_pricing_plans'

    id: Mapped[str] = mapped_column(
        String(32), primary_key=True, default=lambda: uuid.uuid4().hex
    )
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    desc: Mapped[str] = mapped_column(TEXT, nullable=True)

    max_workspaces: Mapped[int] = mapped_column(Integer, nullable=False)
    max_cpus: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    max_memory_gb: Mapped[int] = mapped_column(Integer, nullable=False, default=2)
    max_gpus: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    price: Mapped[float] = mapped_column(Numeric(10, 2), nullable=True, default=0.00)
    billing_cycle: Mapped[float] = mapped_column(
        Numeric(4, 0), nullable=False, default=30
    )  # max is 9999 days per cycle, default is 30 days, negative or zero is one-time purchase
    currency: Mapped[str] = mapped_column(
        String(3), default='USD', nullable=False
    )  # ISO 4217
    credits_per_month: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    features: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=True)

    stripe_price_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    user_subscriptions: Mapped[list['UserSubscriptionsORM']] = relationship(
        'UserSubscriptionsORM',
        back_populates='plan',
        foreign_keys='[UserSubscriptionsORM.plan_id]',
        cascade='all, delete-orphan',
    )
