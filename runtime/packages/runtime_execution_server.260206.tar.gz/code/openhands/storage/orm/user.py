# models/user.py
import uuid
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING

from sqlalchemy import DateTime, ForeignKey, String, func
from sqlalchemy import Enum as PgEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from openhands.storage.db import Base

if TYPE_CHECKING:
    from openhands.storage.orm.refer import ReferLinkORM
    from openhands.storage.orm.user_subscriptions import UserSubscriptionsORM
    from openhands.storage.orm.workspace import WorkspaceORM


class AuthProvider(str, Enum):
    github = 'github'
    gitlab = 'gitlab'
    email = 'email'
    google = 'google'
    facebook = 'facebook'
    twitter = 'twitter'
    linkedin = 'linkedin'
    apple = 'apple'
    microsoft = 'microsoft'
    okta = 'okta'


class UserORM(Base):
    __tablename__ = 'oais_users'

    id: Mapped[str] = mapped_column(
        String(32), primary_key=True, default=lambda: uuid.uuid4().hex
    )
    username: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    email: Mapped[str] = mapped_column(String(255), index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    authentications = relationship(
        'UserAuthORM', back_populates='user', cascade='all, delete-orphan'
    )

    subscriptions: Mapped[list['UserSubscriptionsORM']] = relationship(
        'UserSubscriptionsORM',
        back_populates='user',
        cascade='all, delete-orphan',
        lazy='selectin',
    )

    settings = relationship(
        'SettingsORM',
        back_populates='user',
        uselist=False,
        cascade='all, delete-orphan',
    )
    secrets = relationship(
        'UserSecretsORM',
        back_populates='user',
        uselist=False,
        cascade='all, delete-orphan',
    )
    conversation_metadata = relationship(
        'ConversationMetadataORM', back_populates='user', cascade='all, delete-orphan'
    )

    workspaces: Mapped[list['WorkspaceORM']] = relationship(
        'WorkspaceORM',
        back_populates='user',  # This refers to the 'user' attribute in WorkspaceORM
        cascade='all, delete-orphan',  # If a user is deleted, delete their workspaces
    )

    refer_links: Mapped[list['ReferLinkORM']] = relationship(
        'ReferLinkORM', back_populates='user', cascade='all, delete-orphan'
    )

    # add next auth user id for linking
    auth_user_id: Mapped[str] = mapped_column(
        String(255), unique=True, index=True, nullable=True
    )

    def __repr__(self):
        return f"<UserORM(id='{self.id}', username='{self.username}', email='{self.email}')>"


class UserAuthORM(Base):
    __tablename__ = 'oais_user_auth'

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: uuid.uuid4().hex
    )
    user_id: Mapped[str] = mapped_column(
        ForeignKey('oais_users.id', ondelete='CASCADE'), nullable=False
    )
    provider: Mapped[AuthProvider] = mapped_column(PgEnum(AuthProvider), nullable=False)
    provider_account_id: Mapped[str] = mapped_column(
        String(255), nullable=False
    )  # GitHub ID, GitLab ID, or email
    access_token: Mapped[str] = mapped_column(String(512), nullable=True)
    refresh_token: Mapped[str] = mapped_column(String(512), nullable=True)
    password_hash: Mapped[str] = mapped_column(
        String(255), nullable=True
    )  # only used for email login
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    user = relationship('UserORM', back_populates='authentications')

    def __repr__(self):
        return (
            f"<UserAuthORM(id='{self.id}', user_id='{self.user_id}', "
            f"provider='{self.provider.value}')>"
        )
