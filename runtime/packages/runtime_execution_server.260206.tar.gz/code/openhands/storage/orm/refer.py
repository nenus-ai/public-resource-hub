# models/refer.py
import secrets
import string
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from openhands.storage.db import Base


class ReferLinkORM(Base):
    """Refer Link Table"""

    __tablename__ = 'oais_refer_links'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(
        String(32), ForeignKey('oais_users.id'), nullable=False
    )
    code: Mapped[str] = mapped_column(
        String(32), unique=True, nullable=False, default=lambda: _generate_refer_code()
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    total_clicks: Mapped[int] = mapped_column(Integer, default=0, server_default='0')
    total_conversions: Mapped[int] = mapped_column(
        Integer, default=0, server_default='0'
    )

    # Relationships
    user = relationship('UserORM', back_populates='refer_links')
    tracking_records = relationship(
        'ReferTrackingORM', back_populates='refer_link', cascade='all, delete-orphan'
    )

    def __repr__(self):
        return f'<ReferLinkORM(id={self.id}, user_id={self.user_id}, code={self.code})>'


class ReferTrackingORM(Base):
    """Referral Tracking Table"""

    __tablename__ = 'oais_refer_tracking'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    refer_link_id: Mapped[int] = mapped_column(
        Integer, ForeignKey('oais_refer_links.id'), nullable=False
    )
    session_id: Mapped[str] = mapped_column(
        String(64), nullable=True
    )  # Browser session ID
    clicked_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    converted_user_id: Mapped[str] = mapped_column(
        String(32), ForeignKey('oais_users.id'), nullable=True
    )
    converted_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    reward_given: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default='false'
    )

    # Relationships
    refer_link = relationship('ReferLinkORM', back_populates='tracking_records')
    converted_user = relationship('UserORM', foreign_keys=[converted_user_id])

    def __repr__(self):
        return f'<ReferTrackingORM(id={self.id}, refer_link_id={self.refer_link_id}, converted={self.converted_user_id})>'


def _generate_refer_code() -> str:
    """Generate 8-character random referral code"""
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(8))
