# openhands/storage/orm/user_subscription.py

import uuid
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from openhands.storage.db import Base

from .pricing_plans import PricingPlansORM
from .user import UserORM


class SubscriptionStatus(Enum):
    ACTIVE = 'active'
    PAUSED = 'paused'
    CANCELLED = 'cancelled'
    CANCELLED_AT_PERIOD_END = 'cancelled_at_period_end'

    UNPAID = 'unpaid'
    INCOMPLETE = 'transaction_incomplete'
    PAST_DUE = 'past_due'
    PAID = 'paid'
    EXPIRED = 'expired'  # Manual subscription expired, awaiting renewal


class TrialStatus(Enum):
    NOT_STARTED = 'not_started'
    TRIALLING = 'trialling'
    EXPIRED = 'expired'  # users whose trial period has expired with no payment
    CONVERTED = 'converted'  # users who once converted from trial to paid


class UserSubscriptionsORM(Base):
    __tablename__ = 'oais_user_subscriptions'

    subscription_id: Mapped[str] = mapped_column(
        String(32), primary_key=True, default=lambda: uuid.uuid4().hex
    )
    user_id: Mapped[str] = mapped_column(
        String(32), ForeignKey('oais_users.id'), nullable=False, index=True
    )
    plan_id: Mapped[str] = mapped_column(
        String(32),
        ForeignKey('oais_pricing_plans.id', name='fk_user_subscriptions_plan_id'),
        nullable=False,
        index=True,
    )

    user: Mapped['UserORM'] = relationship('UserORM', back_populates='subscriptions')

    plan: Mapped['PricingPlansORM'] = relationship(
        'PricingPlansORM', back_populates='user_subscriptions', foreign_keys=[plan_id]
    )

    status: Mapped[SubscriptionStatus] = mapped_column(
        String(50), nullable=False, default=SubscriptionStatus.UNPAID.value
    )
    trial_status: Mapped[TrialStatus] = mapped_column(
        String(50), nullable=False, default=TrialStatus.NOT_STARTED.value
    )

    start_date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    current_period_start: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    current_period_end: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )  # This is the renewal date
    cancel_at_period_end: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False
    )
    cancellation_reason: Mapped[Optional[str]] = mapped_column(
        String(210), nullable=True
    )

    previous_plan_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)

    # Payment api fields here
    stripe_customer_id: Mapped[Optional[str]] = mapped_column(
        String(255), nullable=True, index=True
    )
    stripe_subscription_id: Mapped[Optional[str]] = mapped_column(
        String(255), nullable=True, index=True
    )
    stripe_subscription_item_id: Mapped[Optional[str]] = mapped_column(
        String(255), nullable=True
    )  # ID for the subscription item (important for updates)

    # Manual subscription fields (for Alipay/WeChat Payment Mode)
    # NULL = normal Stripe-managed subscription, True = manual subscription (Alipay/WeChat)
    is_manual_subscription: Mapped[Optional[bool]] = mapped_column(
        Boolean, nullable=True
    )
    payment_method: Mapped[Optional[str]] = mapped_column(
        String(50), nullable=True
    )  # 'card', 'alipay', 'wechat_pay'
    last_payment_intent_id: Mapped[Optional[str]] = mapped_column(
        String(255), nullable=True
    )
    renewal_reminder_sent_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    def __repr__(self):
        return (
            f"<UserSubscriptionORM(id='{self.subscription_id}', user_id='{self.user_id}', "
            f"plan_id='{self.plan_id}', status='{self.status}', "
            f"current_period_end='{self.current_period_end}')>"
        )
