from openhands.agenthub.webapp_agent.webapp_agent import WebAppAgent
from openhands.controller.agent import Agent

Agent.register('WebAppAgent', WebAppAgent)
