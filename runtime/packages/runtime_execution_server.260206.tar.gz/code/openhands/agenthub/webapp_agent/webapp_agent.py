import os
from typing import TYPE_CHECKING

import openhands.agenthub.codeact_agent.function_calling as codeact_function_calling
from openhands.agenthub.codeact_agent.codeact_agent import CodeActAgent
from openhands.agenthub.codeact_agent.tools.webapp_delegate import WebAppDelegateTool
from openhands.core.config import AgentConfig
from openhands.events.action import AgentFinishAction
from openhands.llm.llm import LLM
from openhands.utils.prompt import PromptManager

if TYPE_CHECKING:
    from litellm import ModelResponse

    from openhands.events.action import Action


class WebAppAgent(CodeActAgent):
    """A specialized delegate agent for launching web applications correctly.

    This agent ensures web applications are started with:
    - The correct runtime-provided ports (APP_PORT_1 / APP_PORT_2)
    - Proper host binding (0.0.0.0)
    - Correct allowed-hosts configuration for Traefik routing
    - Background execution so the user can continue interacting
    - The correct public URL reported back to the user
    """

    VERSION = '1.0'

    def __init__(
        self,
        llm: LLM,
        config: AgentConfig,
    ) -> None:
        super().__init__(llm, config)
        # Remove the webapp delegate tool to avoid infinite delegation loops
        self.tools = [
            t
            for t in self.tools
            if t['function']['name'] != WebAppDelegateTool['function']['name']
        ]

    @property
    def prompt_manager(self) -> PromptManager:
        if self._prompt_manager is None:
            self._prompt_manager = PromptManager(
                prompt_dir=os.path.join(os.path.dirname(__file__), 'prompts'),
            )
        return self._prompt_manager

    def response_to_actions(self, response: 'ModelResponse') -> list['Action']:
        actions = codeact_function_calling.response_to_actions(
            response,
            mcp_tool_names=list(self.mcp_tools.keys()),
        )
        # Ensure final_thought is propagated into outputs so the parent
        # CodeActAgent receives meaningful content in AgentDelegateObservation.
        # AgentController.end_delegate() builds its observation from state.outputs
        # (set from AgentFinishAction.outputs), so without this the parent would
        # only see "WebAppAgent finishes task with " with no URL/port/PID details.
        for action in actions:
            if (
                isinstance(action, AgentFinishAction)
                and action.final_thought
                and 'message' not in action.outputs
            ):
                action.outputs['message'] = action.final_thought
        return actions
