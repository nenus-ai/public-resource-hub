"""ReviewAgent implementation for monitoring and intervention."""

import os

from openhands.controller.agent import Agent
from openhands.controller.state.state import State
from openhands.core.config import AgentConfig
from openhands.core.logger import openhands_logger as logger
from openhands.core.message import Message
from openhands.events.action import Action, FileEditAction, MessageAction
from openhands.events.action.message import SystemMessageAction
from openhands.events.event import Event, EventSource
from openhands.events.observation.error import ErrorObservation
from openhands.llm.llm import LLM
from openhands.memory.condenser.condenser import Condenser
from openhands.memory.conversation_memory import ConversationMemory
from openhands.utils.prompt import PromptManager


class ReviewAgent(Agent):
    """A parallel monitoring agent that provides intervention when needed.

    This agent analyzes the conversation history periodically to detect
    dead-end situations and provides constructive suggestions to help
    the main agent move forward.
    """

    VERSION = '1.0'
    DEPRECATED = False

    # No sandbox plugins required
    sandbox_plugins: list = []

    # This is a monitoring agent, not a primary agent
    is_review_agent: bool = True
    # Create a ConversationMemory instance

    def __init__(self, llm: LLM, config: AgentConfig | None = None):
        """Initialize the review agent.

        Args:
            llm: Language model instance for analysis
            config: Agent configuration (optional)
        """
        from openhands.core.config import AgentConfig

        if config is None:
            config = AgentConfig()

        super().__init__(llm, config)
        self.last_review_iteration = -1
        self.conversation_memory = ConversationMemory(self.config, self.prompt_manager)

        self.condenser = Condenser.from_config(self.config.condenser)
        logger.info(f'[{self.name}] ReviewAgent initialized')

    @property
    def prompt_manager(self) -> PromptManager:
        if self._prompt_manager is None:
            self._prompt_manager = PromptManager(
                prompt_dir=os.path.join(os.path.dirname(__file__), 'prompts'),
            )

        return self._prompt_manager

    def step(self, state: State) -> Action:
        """This method should not be called directly.

        ReviewAgent operates through check_and_intervene() method.
        """
        raise NotImplementedError(
            'ReviewAgent.step() should not be called directly. '
            'Use check_and_intervene() instead.'
        )

    def check_and_intervene(
        self, state: State, min_iterations_since_last: int = 5
    ) -> tuple[bool, str | None]:
        """Check if intervention is needed and return suggestion.

        Args:
            state: Current state with conversation history
            min_iterations_since_last: Minimum iterations since last review

        Returns:
            Tuple of (should_intervene: bool, suggestion: str | None)
        """
        # Don't review too frequently
        if state.iteration - self.last_review_iteration < min_iterations_since_last:
            return False, None

        # Don't review if there's not enough history
        if state.iteration < 3:
            return False, None

        self.last_review_iteration = state.iteration

        # Build analysis from recent history
        recent_history = self._get_recent_history(state.history, max_events=600)
        initial_user_message = self._get_initial_user_message(state.history)

        # Use ConversationMemory to process events (including SystemMessageAction)
        messages = self.conversation_memory.process_events(
            condensed_history=recent_history,
            initial_user_action=initial_user_message,
            max_message_chars=self.llm.config.max_message_chars,
            vision_is_active=self.llm.vision_is_active(),
        )
        if not messages:
            return False, None

        try:
            # Get LLM assessment
            formatted_messages = self.llm.format_messages_for_llm(messages)
            response = self.llm.completion(messages=formatted_messages)

            content = response['choices'][0]['message']['content'].strip()

            # Parse response
            if content.startswith('INTERVENE:'):
                suggestion = content.replace('INTERVENE:', '').strip()
                logger.info(f'[ReviewAgent] Intervention recommended: {suggestion}')
                return True, suggestion
            else:
                logger.debug('[ReviewAgent] No intervention needed')
                return False, None

        except Exception as e:
            logger.error(f'[ReviewAgent] Error during review: {e}')
            return False, None

    def _get_recent_history(
        self, history: list[Event], max_events: int = 600
    ) -> list[Event]:
        """Get recent relevant events from history.

        Args:
            history: Full event history
            max_events: Maximum number of events to return

        Returns:
            List of recent relevant events
        """
        # Filter to relevant event types and get the most recent ones
        relevant_events: list[Event] = []

        for event in reversed(history):
            # Include user messages, agent messages, errors, and file edit actions
            if isinstance(event, (MessageAction, ErrorObservation, FileEditAction)):
                relevant_events.append(event)
            elif hasattr(event, 'message') and event.message:
                relevant_events.append(event)

            if len(relevant_events) >= max_events:
                break

        # Reverse to chronological order
        return list(reversed(relevant_events))

    def get_system_message(self) -> SystemMessageAction:
        """Get system message for this agent."""
        return SystemMessageAction(content=self.prompt_manager.get_system_message())

    def reset(self) -> None:
        """Reset agent state."""
        self.last_review_iteration = -1
        logger.debug('[ReviewAgent] Reset')
