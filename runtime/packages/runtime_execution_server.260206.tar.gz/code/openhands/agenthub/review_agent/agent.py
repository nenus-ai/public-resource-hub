"""ReviewAgent implementation for monitoring and intervention."""

from openhands.controller.agent import Agent
from openhands.controller.state.state import State
from openhands.core.config import AgentConfig
from openhands.core.logger import openhands_logger as logger
from openhands.core.message import Message
from openhands.events.action import Action, FileEditAction, MessageAction
from openhands.events.action.message import SystemMessageAction
from openhands.events.event import Event, EventSource
from openhands.events.observation.error import ErrorObservation
from openhands.llm.llm import LLM

REVIEW_SYSTEM_PROMPT = """You are a review agent monitoring the conversation between a user and an AI assistant working on a task.

Your role is to detect when the conversation is going to a dead end or losing focus, and provide constructive intervention.

Analyze the recent conversation history and determine if intervention is needed based on:
1. Is the agent stuck in a loop or repeatedly trying the same failed approach?
2. Is the agent losing focus from the original task?
3. Is there an unrecoverable error situation?
4. Is the agent going in the wrong direction despite user feedback?
5. Has the agent stopped making meaningful progress?

If intervention is needed, respond with:
INTERVENE: <specific, constructive suggestion to move forward>

If the conversation is progressing well, respond with:
OK

Keep your intervention suggestions brief, actionable, and focused on helping the agent move forward.
"""


class ReviewAgent(Agent):
    """A parallel monitoring agent that provides intervention when needed.

    This agent analyzes the conversation history periodically to detect
    dead-end situations and provides constructive suggestions to help
    the main agent move forward.
    """

    VERSION = '1.0'
    DEPRECATED = False

    # No sandbox plugins required
    sandbox_plugins: list = []

    # This is a monitoring agent, not a primary agent
    is_review_agent: bool = True

    def __init__(self, llm: LLM, config: AgentConfig | None = None):
        """Initialize the review agent.

        Args:
            llm: Language model instance for analysis
            config: Agent configuration (optional)
        """
        from openhands.core.config import AgentConfig

        if config is None:
            config = AgentConfig()

        super().__init__(llm, config)
        self._prompt_manager = None
        self.last_review_iteration = -1

        logger.info(f'[{self.name}] ReviewAgent initialized')

    def step(self, state: State) -> Action:
        """This method should not be called directly.

        ReviewAgent operates through check_and_intervene() method.
        """
        raise NotImplementedError(
            'ReviewAgent.step() should not be called directly. '
            'Use check_and_intervene() instead.'
        )

    def check_and_intervene(
        self, state: State, min_iterations_since_last: int = 5
    ) -> tuple[bool, str | None]:
        """Check if intervention is needed and return suggestion.

        Args:
            state: Current state with conversation history
            min_iterations_since_last: Minimum iterations since last review

        Returns:
            Tuple of (should_intervene: bool, suggestion: str | None)
        """
        # Don't review too frequently
        if state.iteration - self.last_review_iteration < min_iterations_since_last:
            return False, None

        # Don't review if there's not enough history
        if state.iteration < 3:
            return False, None

        self.last_review_iteration = state.iteration

        # Build analysis from recent history
        recent_history = self._get_recent_history(state.history, max_events=20)

        if not recent_history:
            return False, None

        # Prepare messages for LLM
        messages = self._build_review_messages(state, recent_history)

        try:
            # Get LLM assessment
            formatted_messages = self.llm.format_messages_for_llm(messages)
            response = self.llm.completion(messages=formatted_messages)

            content = response['choices'][0]['message']['content'].strip()

            # Parse response
            if content.startswith('INTERVENE:'):
                suggestion = content.replace('INTERVENE:', '').strip()
                logger.info(f'[ReviewAgent] Intervention recommended: {suggestion}')
                return True, suggestion
            else:
                logger.debug('[ReviewAgent] No intervention needed')
                return False, None

        except Exception as e:
            logger.error(f'[ReviewAgent] Error during review: {e}')
            return False, None

    def _get_recent_history(
        self, history: list[Event], max_events: int = 400
    ) -> list[Event]:
        """Get recent relevant events from history.

        Args:
            history: Full event history
            max_events: Maximum number of events to return

        Returns:
            List of recent relevant events
        """
        # Filter to relevant event types and get the most recent ones
        relevant_events: list[Event] = []

        for event in reversed(history):
            # Include user messages, agent messages, errors, and file edit actions
            if isinstance(event, (MessageAction, ErrorObservation, FileEditAction)):
                relevant_events.append(event)
            elif hasattr(event, 'message') and event.message:
                relevant_events.append(event)

            if len(relevant_events) >= max_events:
                break

        # Reverse to chronological order
        return list(reversed(relevant_events))

    def _build_review_messages(
        self, state: State, recent_history: list[Event]
    ) -> list[Message]:
        """Build messages for LLM review.

        Args:
            state: Current state
            recent_history: Recent events to analyze

        Returns:
            List of messages for LLM
        """
        from openhands.core.message import Message, TextContent

        messages: list[Message] = []

        # System prompt
        messages.append(
            Message(role='system', content=[TextContent(text=REVIEW_SYSTEM_PROMPT)])
        )

        context = """
Recent conversation history:
"""

        # Add recent events
        for i, event in enumerate(recent_history, start=1):
            event_summary = self._summarize_event(event)
            if event_summary:
                context += f'\n{i}. {event_summary}'

        messages.append(Message(role='user', content=[TextContent(text=context)]))

        return messages

    def _summarize_event(self, event: Event) -> str | None:
        """Create a brief summary of an event.

        Args:
            event: Event to summarize

        Returns:
            String summary or None if not relevant
        """
        if isinstance(event, MessageAction):
            source = 'User' if event.source == EventSource.USER else 'Agent'
            content = event.content[:200] if event.content else ''
            return f'[{source}] {content}'
        elif isinstance(event, ErrorObservation):
            content = event.content[:200] if event.content else 'Error occurred'
            return f'[Error] {content}'
        elif isinstance(event, FileEditAction):
            # Include file path and edit details for better context
            path = event.path
            summary = f'[FileEdit] {path}'

            # Add command type and relevant details
            if event.command == 'str_replace':
                # Show what's being replaced (truncated for brevity)
                old_preview = (
                    (event.old_str[:50] + '...')
                    if event.old_str and len(event.old_str) > 50
                    else (event.old_str or '')
                )
                new_preview = (
                    (event.new_str[:50] + '...')
                    if event.new_str and len(event.new_str) > 50
                    else (event.new_str or '')
                )
                summary += f' - Replace: "{old_preview}" → "{new_preview}"'
            elif event.command == 'create':
                summary += ' - Create new file'
            elif event.command == 'insert':
                summary += f' - Insert at line {event.insert_line}'
            elif event.command == 'undo_edit':
                summary += ' - Undo last edit'

            return summary
        elif hasattr(event, 'message'):
            msg = event.message[:200] if event.message else ''
            if msg:
                return f'[Event] {msg}'

        return None

    def get_system_message(self) -> SystemMessageAction:
        """Get system message for this agent."""
        return SystemMessageAction(content=REVIEW_SYSTEM_PROMPT)

    def reset(self) -> None:
        """Reset agent state."""
        self.last_review_iteration = -1
        logger.debug('[ReviewAgent] Reset')
