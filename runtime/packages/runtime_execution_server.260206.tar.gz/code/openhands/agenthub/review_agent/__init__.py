"""ReviewAgent: A parallel agent that monitors task progress and provides intervention.

This agent monitors the conversation between user and agent to detect:
- Dead-end situations (agent stuck or going in wrong direction)
- Loss of focus from the original task
- Unrecoverable error states

When such situations are detected, it injects constructive suggestions
to help the agent move forward. When things are going well, it stays silent.
"""

from openhands.agenthub.review_agent.agent import ReviewAgent

__all__ = ['ReviewAgent']
