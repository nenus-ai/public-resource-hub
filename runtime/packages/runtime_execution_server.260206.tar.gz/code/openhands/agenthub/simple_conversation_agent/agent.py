"""SimpleConversationAgent: A lightweight chat-only agent for fast startup.

This agent provides immediate conversational capabilities without requiring
a runtime environment. It's designed for quick user engagement while the
full CodeAct agent and runtime are being initialized in the background.

Key features:
- Fast startup (1-2 seconds)
- No runtime dependency
- Pure conversational capabilities
- Seamless upgrade path to CodeActAgent
"""

from openhands.controller.agent import Agent
from openhands.controller.state.state import State
from openhands.core.config import AgentConfig
from openhands.core.logger import openhands_logger as logger
from openhands.events.action import Action, MessageAction
from openhands.events.action.message import SystemMessageAction
from openhands.events.event import EventSource
from openhands.llm.llm import LLM

SIMPLE_AGENT_SYSTEM_PROMPT = """I'm Keplore, an exceptional research engineer dedicated to supporting and advancing every aspect of your research and engineering efforts.

Currently, you are in **conversation mode**. You can:
- Answer questions about research and programming concepts
- Explain code and algorithms
- Provide guidance and best practices
- Discuss technical and research topics

Note: Your full development environment is being prepared in the background and will be available shortly.
When the environment is ready, you'll have enhanced capabilities including:
- Execute code in a sandbox environment
- Modify and create files
- Run terminal commands
- Install packages and dependencies

For now, let's chat! How can I assist you today?
"""


class SimpleConversationAgent(Agent):
    """A lightweight conversational agent optimized for fast startup.

    This agent handles pure text conversations without code execution.
    It's designed to provide immediate user engagement while a full
    CodeAct agent is being initialized with runtime in the background.
    """

    VERSION = '1.0'
    DEPRECATED = False

    # No sandbox plugins required for conversation-only mode
    sandbox_plugins: list = []

    # Mark this agent as a fast-start agent to disable stuck detection
    # during the initial conversation phase
    is_fast_start_agent: bool = True

    def __init__(self, llm: LLM, config: AgentConfig | None = None):
        """Initialize the simple conversation agent.

        Args:
            llm: Language model instance (typically a fast, cheap model like GPT-3.5)
            config: Agent configuration (optional)
        """
        from openhands.core.config import AgentConfig

        if config is None:
            config = AgentConfig()

        super().__init__(llm, config)

        # SimpleConversationAgent uses hardcoded system prompt,
        # so we don't need PromptManager
        self._prompt_manager = None

        logger.info(
            f'[{self.name}] Initialized in conversation-only mode '
            f'(model: {llm.config.model})'
        )

    def step(self, state: State) -> Action:
        """Generate a conversational response.

        This method creates a simple text response without any code execution.

        Args:
            state: Current agent state containing conversation history

        Returns:
            MessageAction with the AI's text response
        """
        logger.info(
            f'[{self.name}] SimpleConversationAgent.step() called '
            f'(iteration: {state.iteration})'
        )

        # Check if there's a user message to respond to
        # SimpleConversationAgent should only respond when there's actual user input
        # that hasn't been responded to yet
        last_user_msg = state.get_last_user_message()
        if not last_user_msg or not last_user_msg.content.strip():
            logger.warning(f'[{self.name}] No user message found, skipping response')
            # Return a ChangeAgentStateAction to transition to AWAITING_USER_INPUT
            from openhands.controller.state.state import AgentState
            from openhands.events.action import ChangeAgentStateAction

            return ChangeAgentStateAction(AgentState.AWAITING_USER_INPUT)

        # Check if we've already responded to this message
        # by looking for any agent messages after the last user message
        user_msg_index = -1
        for i, event in enumerate(state.history):
            if event == last_user_msg:
                user_msg_index = i
                break

        if user_msg_index >= 0:
            # Check if there's already an agent response after this user message
            for event in state.history[user_msg_index + 1 :]:
                if (
                    isinstance(event, MessageAction)
                    and event.source == EventSource.AGENT
                ):
                    logger.info(
                        f'[{self.name}] Already responded to latest user message, '
                        f'waiting for new input'
                    )
                    from openhands.controller.state.state import AgentState
                    from openhands.events.action import ChangeAgentStateAction

                    return ChangeAgentStateAction(AgentState.AWAITING_USER_INPUT)

        # Build messages from history
        logger.debug(
            f'[{self.name}] Processing history with {len(state.history)} events'
        )
        messages = self._get_messages_from_history(state.history)

        logger.debug(f'[{self.name}] Extracted {len(messages)} messages from history')

        # Add system message if not present
        if not messages or messages[0].get('role') != 'system':
            messages.insert(
                0, {'role': 'system', 'content': SIMPLE_AGENT_SYSTEM_PROMPT}
            )

        logger.debug(
            f'[{self.name}] Generating response '
            f'(conversation length: {len(messages)} messages)'
        )

        # Log the messages being sent to LLM for debugging
        logger.debug(f'[{self.name}] Messages to LLM: {messages}')

        # Call LLM
        try:
            response = self.llm.completion(
                messages=messages,
                # No tools in conversation mode
                tools=None,
            )

            content = response.choices[0].message.content or ''

            logger.info(f'[{self.name}] Generated response ({len(content)} chars)')

            # If LLM returns empty content, log warning but still return it
            # Empty responses should be handled by the controller, not masked here
            if not content or not content.strip():
                logger.warning(f'[{self.name}] LLM returned empty response')

            # Return pure message action (even if empty)
            # This allows the controller to detect issues rather than masking them
            action = MessageAction(content=content)
            action._source = EventSource.AGENT  # type: ignore

            return action

        except Exception as e:
            logger.error(f'[{self.name}] Error generating response: {e}')
            # Return error message
            error_action = MessageAction(
                content=f"I'm sorry, I encountered an error: {str(e)}"
            )
            error_action._source = EventSource.AGENT  # type: ignore
            return error_action

    def _get_messages_from_history(self, history: list) -> list[dict]:
        """Convert event history to LLM message format.

        Only includes recent message history to avoid overwhelming the LLM
        with too much context during fast-start conversation mode.

        Args:
            history: List of events from the conversation

        Returns:
            List of message dictionaries for LLM API (limited to recent messages)
        """
        messages = []

        for event in history:
            if isinstance(event, MessageAction):
                # Skip empty messages to prevent API errors
                if not event.content or not event.content.strip():
                    continue

                # ⭐ Skip messages marked with skip_llm: True (UI-only messages)
                # These include FastStart ready notification, stop acknowledgment, etc.
                if hasattr(event, 'extra_metadata') and event.extra_metadata:
                    if event.extra_metadata.get('skip_llm'):
                        logger.info(
                            f'[{self.name}] Skipping message with skip_llm=True (UI-only)'
                        )
                        continue
                    # ⭐ Skip pinned initial messages - these are for display only
                    # They should only be processed by CodeActAgent after upgrade
                    if event.extra_metadata.get('is_pinned_initial'):
                        logger.info(
                            f'[{self.name}] Skipping pinned initial message (for CodeActAgent only)'
                        )
                        continue

                # Use EventSource enum for reliable comparison
                role = 'user' if event.source == EventSource.USER else 'assistant'
                messages.append({'role': role, 'content': event.content})

        # Limit history window to prevent overwhelming LLM with too much context
        # Keep only the most recent 10 messages (5 turns) for conversation mode
        # This prevents issues where LLM sees extensive previous responses and
        # gives minimal answers thinking it already addressed the questions
        MAX_HISTORY_MESSAGES = 10

        if len(messages) > MAX_HISTORY_MESSAGES:
            logger.info(
                f'[{self.name}] Limiting history from {len(messages)} to {MAX_HISTORY_MESSAGES} messages'
            )
            messages = messages[-MAX_HISTORY_MESSAGES:]

        # Ensure there's at least one user message for LLM API compatibility
        # If no user messages exist, add a generic greeting
        has_user_message = any(msg['role'] == 'user' for msg in messages)
        if not has_user_message:
            logger.warning(
                f'[{self.name}] No user messages found in history, adding default greeting'
            )
            messages.insert(0, {'role': 'user', 'content': 'Hello'})

        return messages

    def get_system_message(self) -> SystemMessageAction:
        """Get the system message for this agent.

        Returns:
            SystemMessageAction with conversation-mode instructions
        """
        system_message_action = SystemMessageAction(
            content=SIMPLE_AGENT_SYSTEM_PROMPT,
            tools=None,  # No tools in simple mode
            agent_class=self.name,
        )
        system_message_action._source = EventSource.AGENT  # type: ignore

        return system_message_action

    def reset(self) -> None:
        """Reset agent state."""
        super().reset()
        logger.debug(f'[{self.name}] Agent reset')


# Register the agent
Agent.register('SimpleConversationAgent', SimpleConversationAgent)
