"""SimpleConversationAgent - Fast startup agent for immediate user engagement.

This agent provides instant text-based conversation while Runtime initializes.
"""

from openhands.agenthub.simple_conversation_agent.agent import (  # noqa: F401
    SimpleConversationAgent,
)

__all__ = ['SimpleConversationAgent']
