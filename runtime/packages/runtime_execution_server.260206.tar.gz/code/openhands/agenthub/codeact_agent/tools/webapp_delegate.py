from litellm import ChatCompletionToolParam, ChatCompletionToolParamFunctionChunk

WebAppDelegateTool: ChatCompletionToolParam = ChatCompletionToolParam(
    type='function',
    function=ChatCompletionToolParamFunctionChunk(
        name='delegate_to_webapp_agent',
        description=(
            'Delegate a web application launch task to the WebAppAgent. '
            'Use this tool whenever the user asks you to start, run, serve, or deploy '
            'a web application, web server, or frontend/backend app. '
            'The WebAppAgent will use the correct runtime ports, bind to 0.0.0.0, '
            'configure allowed hosts for the Traefik proxy, start the app in the '
            'background, and report the correct access URL to the user.'
        ),
        parameters={
            'type': 'object',
            'properties': {
                'task': {
                    'type': 'string',
                    'description': (
                        'A clear description of the web app launch task, including '
                        'the type of app (React, Flask, Django, Node, etc.), '
                        'the working directory if known, and any specific requirements '
                        '(e.g. port preference, environment variables to set).'
                    ),
                },
            },
            'required': ['task'],
        },
    ),
)
