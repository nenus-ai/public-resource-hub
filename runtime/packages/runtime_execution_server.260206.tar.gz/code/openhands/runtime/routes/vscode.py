from __future__ import annotations

from typing import Callable

from fastapi import APIRouter

from openhands.runtime.action_execution.executor.executor import ActionExecutor
from openhands.runtime.plugins import VSCodePlugin


def create_vscode_router(
    *, get_client: Callable[[], ActionExecutor | None]
) -> APIRouter:
    router = APIRouter()

    @router.get('/vscode/connection_token')
    async def get_vscode_connection_token():
        """Get the current VSCode connection token.

        This returns the token that was generated when the VSCode server was initialized.
        The token is immutable for the lifetime of the VSCode server process.
        """
        client = get_client()
        assert client is not None
        await client._ensure_vscode_ready()

        if 'vscode' in client.plugins:
            plugin: VSCodePlugin = client.plugins['vscode']  # type: ignore
            return {'token': plugin.vscode_connection_token}

        return {'token': None}

    return router
