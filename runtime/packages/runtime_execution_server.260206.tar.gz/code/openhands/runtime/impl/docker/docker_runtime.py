import os
import time
from functools import lru_cache
from typing import Callable
from uuid import UUID

import docker
import httpx
import tenacity
from docker.models.containers import Container

from openhands.core.config import OpenHandsConfig
from openhands.core.exceptions import (
    AgentRuntimeContainerStartError,
    AgentRuntimeDisconnectedError,
    AgentRuntimeNotFoundError,
    AgentRuntimeOutOfMemoryError,
)
from openhands.core.logger import DEBUG, DEBUG_RUNTIME
from openhands.core.logger import openhands_logger as logger
from openhands.events import EventStream
from openhands.runtime.builder import DockerRuntimeBuilder
from openhands.runtime.impl.action_execution.action_execution_client import (
    ActionExecutionClient,
)
from openhands.runtime.impl.docker.containers import stop_all_containers
from openhands.runtime.model.runtime_commit import (
    RuntimeCommitRequest,
    RuntimeCommitResponse,
)
from openhands.runtime.options import RuntimeOptions
from openhands.runtime.plugins import PluginRequirement
from openhands.runtime.utils import find_available_tcp_port
from openhands.runtime.utils.command import (
    DEFAULT_MAIN_MODULE,
    get_action_execution_server_startup_command,
)
from openhands.runtime.utils.log_streamer import LogStreamer
from openhands.runtime.utils.runtime_build import build_runtime_image
from openhands.runtime.utils.runtime_source_mount import (
    apply_runtime_source_mount,
    get_runtime_source_path_env,
)
from openhands.server.services.workspace_settings import get_workspace_close_delay
from openhands.utils.async_utils import call_sync_from_async
from openhands.utils.shutdown_listener import add_shutdown_listener
from openhands.utils.tenacity_stop import stop_if_should_exit

CONTAINER_NAME_PREFIX = 'openhands-runtime-'

EXECUTION_SERVER_PORT_RANGE = (30000, 39999)
VSCODE_PORT_RANGE = (40000, 49999)
APP_PORT_RANGE_1 = (50000, 54999)
APP_PORT_RANGE_2 = (55000, 59999)


def _is_retryablewait_until_alive_error(exception: Exception) -> bool:
    if isinstance(exception, tenacity.RetryError):
        cause = exception.last_attempt.exception()
        return _is_retryablewait_until_alive_error(cause)

    return isinstance(
        exception,
        (
            ConnectionError,
            httpx.ConnectTimeout,
            httpx.NetworkError,
            httpx.RemoteProtocolError,
            httpx.HTTPStatusError,
            httpx.ReadTimeout,
        ),
    )


class DockerRuntime(ActionExecutionClient):
    """This runtime will subscribe the event stream.

    When receive an event, it will send the event to runtime-client which run inside the docker environment.

    Args:
        config (OpenHandsConfig): The application configuration.
        event_stream (EventStream): The event stream to subscribe to.
        sid (str, optional): The session ID. Defaults to 'default'.
        plugins (list[PluginRequirement] | None, optional): List of plugin requirements. Defaults to None.
        env_vars (dict[str, str] | None, optional): Environment variables to set. Defaults to None.
    """

    _shutdown_listener_id: UUID | None = None

    def __init__(
        self,
        config: OpenHandsConfig,
        event_stream: EventStream,
        sid: str = 'default',
        plugins: list[PluginRequirement] | None = None,
        env_vars: dict[str, str] | None = None,
        status_callback: Callable | None = None,
        attach_to_existing: bool = False,
        headless_mode: bool = True,
        main_module: str = DEFAULT_MAIN_MODULE,
        options: RuntimeOptions | None = None,
    ):
        if not DockerRuntime._shutdown_listener_id:
            DockerRuntime._shutdown_listener_id = add_shutdown_listener(
                lambda: stop_all_containers(CONTAINER_NAME_PREFIX)
            )

        self.config = config
        self.status_callback = status_callback

        self._host_port = -1
        self._container_port = -1
        self._vscode_port = -1
        self._app_ports: list[int] = []

        if os.environ.get('DOCKER_HOST_ADDR'):
            logger.info(
                f'Using DOCKER_HOST_IP: {os.environ["DOCKER_HOST_ADDR"]} for local_runtime_url'
            )
            self.config.sandbox.local_runtime_url = f'{os.environ["DOCKER_HOST_ADDR"]}'

        self.docker_client: docker.DockerClient = self._init_docker_client()
        self.api_url = f'{self.config.sandbox.local_runtime_url}:{self._container_port}'

        self.base_container_image = self.config.sandbox.base_container_image
        self.runtime_container_image = self.config.sandbox.runtime_container_image
        if options:
            self.runtime_container_image = (
                options.runtime_container_image or self.runtime_container_image
            )
        self.container_name = CONTAINER_NAME_PREFIX + sid
        self.container: Container | None = None
        self.main_module = main_module
        self.options = options  # Store RuntimeOptions for later use

        self.runtime_builder = DockerRuntimeBuilder(self.docker_client)

        # Progress tracking for startup
        self._check_attempt = 0
        self._startup_start_time: float | None = None

        # Buffer for container logs
        self.log_streamer: LogStreamer | None = None

        super().__init__(
            config,
            event_stream,
            sid,
            plugins,
            env_vars,
            status_callback,
            attach_to_existing,
            headless_mode,
        )

        # Log runtime_extra_deps after base class initialization so self.sid is available
        if self.config.sandbox.runtime_extra_deps:
            self.log(
                'debug',
                f'Installing extra user-provided dependencies in the runtime image: {self.config.sandbox.runtime_extra_deps}',
            )

    @property
    def action_execution_server_url(self) -> str:
        return self.api_url

    async def connect(self) -> None:
        self.send_status_message('STATUS$STARTING_RUNTIME')
        try:
            await call_sync_from_async(self._attach_to_container)
        except docker.errors.NotFound as e:
            if self.attach_to_existing:
                self.log(
                    'warning',
                    f'Container {self.container_name} not found.',
                )
                raise AgentRuntimeDisconnectedError from e
            self.maybe_build_runtime_container_image()
            self.log(
                'info', f'Starting runtime with image: {self.runtime_container_image}'
            )
            await call_sync_from_async(self.init_container)
            self.log(
                'info',
                f'Container started: {self.container_name}. VSCode URL: {self.vscode_url}',
            )

        if DEBUG_RUNTIME and self.container:
            self.log_streamer = LogStreamer(self.container, self.log)
        else:
            self.log_streamer = None

        if not self.attach_to_existing:
            self.log('info', f'Waiting for client to become ready at {self.api_url}...')
            self.send_status_message('STATUS$WAITING_FOR_CLIENT')
            # Track start time for progress calculation
            self._startup_start_time = time.time()

        await call_sync_from_async(self.wait_until_alive)

        # Best-effort capability probe (legacy runtimes will fallback to core).
        await call_sync_from_async(self.refresh_capabilities)

        if not self.attach_to_existing:
            self.log('info', 'Runtime is ready.')

        if not self.attach_to_existing:
            await call_sync_from_async(self.setup_initial_env)

        self.log(
            'debug',
            f'Container initialized with plugins: {[plugin.name for plugin in self.plugins]}. VSCode URL: {self.vscode_url}',
        )
        if not self.attach_to_existing:
            self.send_status_message(' ')
        self._runtime_initialized = True

    async def commit(
        self, conversation_id: str, request: RuntimeCommitRequest
    ) -> RuntimeCommitResponse:
        container_name = CONTAINER_NAME_PREFIX + conversation_id
        container = self.docker_client.containers.get(container_name)

        # Perform the actual Docker commit
        snapshot_image = container.commit(
            repository=request.repository,
            tag=request.tag,
            message=request.message,
            author=request.author,
        )

        container_id = container.id
        base_image = container.attrs['Config']['Image']

        # Get image size
        image_info = self.docker_client.api.inspect_image(snapshot_image.id)
        image_size_mb = int(image_info['Size'] / (1024 * 1024))

        return RuntimeCommitResponse(
            image_size_mb=image_size_mb,
            container_id=container_id,
            base_image=base_image,
        )

    def maybe_build_runtime_container_image(self):
        if self.runtime_container_image is None:
            if self.base_container_image is None:
                raise ValueError(
                    'Neither runtime container image nor base container image is set'
                )
            self.send_status_message('STATUS$STARTING_CONTAINER')
            self.runtime_container_image = build_runtime_image(
                self.base_container_image,
                self.runtime_builder,
                platform=self.config.sandbox.platform,
                extra_deps=self.config.sandbox.runtime_extra_deps,
                force_rebuild=self.config.sandbox.force_rebuild_runtime,
                extra_build_args=self.config.sandbox.runtime_extra_build_args,
            )

    @staticmethod
    @lru_cache(maxsize=1)
    def _init_docker_client() -> docker.DockerClient:
        try:
            # Initialize Docker client with extended timeout for large operations
            # 20 minutes timeout to support committing large images
            return docker.from_env(timeout=1200)
        except Exception as ex:
            logger.error(
                'Launch docker client failed. Please make sure you have installed docker and started docker desktop/daemon.',
            )
            raise ex

    def _process_volumes(self) -> dict[str, dict[str, str]]:
        """Process volume mounts based on configuration.

        Returns:
            A dictionary mapping host paths to container bind mounts with their modes.
        """
        # Initialize volumes dictionary
        volumes: dict[str, dict[str, str]] = {}

        # Process volumes (comma-delimited)
        if self.config.sandbox.volumes is not None:
            # Handle multiple mounts with comma delimiter
            mounts = self.config.sandbox.volumes.split(',')

            for mount in mounts:
                parts = mount.split(':')
                if len(parts) >= 2:
                    host_path = os.path.abspath(parts[0])
                    container_path = parts[1]
                    # Default mode is 'rw' if not specified
                    mount_mode = parts[2] if len(parts) > 2 else 'rw'

                    volumes[host_path] = {
                        'bind': container_path,
                        'mode': mount_mode,
                    }
                    logger.debug(
                        f'Mount dir (sandbox.volumes): {host_path} to {container_path} with mode: {mount_mode}'
                    )

        # Legacy mounting with workspace_* parameters
        elif (
            self.config.workspace_mount_path is not None
            and self.config.workspace_mount_path_in_sandbox is not None
        ):
            mount_mode = 'rw'  # Default mode

            # e.g. result would be: {"/home/user/openhands/workspace": {'bind': "/workspace", 'mode': 'rw'}}
            volumes[self.config.workspace_mount_path] = {
                'bind': self.config.workspace_mount_path_in_sandbox,
                'mode': mount_mode,
            }
            logger.debug(
                f'Mount dir (legacy): {self.config.workspace_mount_path} with mode: {mount_mode}'
            )
        runtime_source_path = get_runtime_source_path_env()
        if runtime_source_path:
            apply_runtime_source_mount(
                volumes,
                runtime_source_path,
                require_abs=False,
                resolve_abspath=True,
                validate_dir_if_exists=True,
                allow_nonexistent=False,
            )
        return volumes

    def init_container(self) -> None:
        self.log('debug', 'Preparing to start container...')
        self.send_status_message('STATUS$PREPARING_CONTAINER')
        self._host_port = self._find_available_port(EXECUTION_SERVER_PORT_RANGE)
        self._container_port = self._host_port
        # Use the configured vscode_port if provided, otherwise find an available port
        self._vscode_port = (
            self.config.sandbox.vscode_port
            or self._find_available_port(VSCODE_PORT_RANGE)
        )
        self._app_ports = [
            self._find_available_port(APP_PORT_RANGE_1),
            self._find_available_port(APP_PORT_RANGE_2),
        ]
        self.api_url = f'{self.config.sandbox.local_runtime_url}:{self._container_port}'

        use_host_network = self.config.sandbox.use_host_network

        # Initialize port mappings
        port_mapping: dict[str, list[dict[str, str]]] | None = None
        if not use_host_network:
            port_mapping = {
                f'{self._container_port}/tcp': [
                    {
                        'HostPort': str(self._host_port),
                        'HostIp': self.config.sandbox.runtime_binding_address,
                    }
                ],
            }

            if self.vscode_enabled:
                port_mapping[f'{self._vscode_port}/tcp'] = [
                    {
                        'HostPort': str(self._vscode_port),
                        'HostIp': self.config.sandbox.runtime_binding_address,
                    }
                ]

            for port in self._app_ports:
                port_mapping[f'{port}/tcp'] = [
                    {
                        'HostPort': str(port),
                        'HostIp': self.config.sandbox.runtime_binding_address,
                    }
                ]
        else:
            self.log(
                'warn',
                'Using host network mode. If you are using MacOS, please make sure you have the latest version of Docker Desktop and enabled host network feature: https://docs.docker.com/network/drivers/host/#docker-desktop',
            )

        idle_life = (
            get_workspace_close_delay(self.sid) or self.config.sandbox.close_delay
        )

        # Combine environment variables
        environment = dict(**self.initial_env_vars)
        environment.update(
            {
                'port': str(self._container_port),
                'PYTHONUNBUFFERED': '1',
                # Passing in the ports means nested runtimes do not come up with their own ports!
                'VSCODE_PORT': str(self._vscode_port),
                'APP_PORT_1': str(self._app_ports[0]),
                'APP_PORT_2': str(self._app_ports[1]),
                'PIP_BREAK_SYSTEM_PACKAGES': '1',
                'SANDBOX_IDLE_LIFE': str(idle_life),
            }
        )
        if self.config.debug or DEBUG:
            environment['DEBUG'] = 'true'
        # also update with runtime_startup_env_vars
        environment.update(self.config.sandbox.runtime_startup_env_vars)

        debug_runtime_enabled = environment.get(
            'OAIS_DEBUG_RUNTIME', 'false'
        ).lower() in ['true', '1', 'yes']
        debug_runtime_port = environment.get('OAIS_DEBUG_RUNTIME_PORT', '5678')
        if debug_runtime_enabled and port_mapping is not None:
            debug_port_key = f'{debug_runtime_port}/tcp'
            if debug_port_key not in port_mapping:
                port_mapping[debug_port_key] = [
                    {
                        'HostPort': str(debug_runtime_port),
                        'HostIp': self.config.sandbox.runtime_binding_address,
                    }
                ]

        self.log('debug', f'Workspace Base: {self.config.workspace_base}')

        # Process volumes for mounting
        volumes = self._process_volumes()

        # If no volumes were configured, set to None
        if not volumes:
            logger.debug(
                'Mount dir is not set, will not mount the workspace directory to the container'
            )
            volumes = {}  # Empty dict instead of None to satisfy mypy
        self.log(
            'debug',
            f'Sandbox workspace: {self.config.workspace_mount_path_in_sandbox}',
        )

        command = self.get_action_execution_server_startup_command()

        try:
            if self.runtime_container_image is None:
                raise ValueError('Runtime container image is not set')
            # add labels for traefik to route traffic to this container
            # random name to avoid conflicts with other runtimes
            traefik_runtime_name = self.runtime_name
            labels = {
                'traefik.enable': 'true',
                f'traefik.http.routers.{traefik_runtime_name}.rule': f'Host(`{self.runtime_host}`)',
                f'traefik.http.routers.{traefik_runtime_name}.entrypoints': 'web',
                f'traefik.http.services.{traefik_runtime_name}.loadbalancer.server.port': str(
                    self._vscode_port
                ),
                f'traefik.http.routers.{traefik_runtime_name}.service': traefik_runtime_name,
            }

            # add the web_hosts to the traefik labels
            for i, host in enumerate(self.web_hosts.keys()):
                host_name = host.split('://')[1]
                service_name = f'{traefik_runtime_name}-web{i + 1}'
                labels[f'traefik.http.routers.{service_name}.rule'] = (
                    f'Host(`{host_name}`)'
                )
                labels[f'traefik.http.routers.{service_name}.entrypoints'] = 'web'
                labels[
                    f'traefik.http.services.{service_name}.loadbalancer.server.port'
                ] = str(self.web_hosts[host])
                labels[f'traefik.http.routers.{service_name}.service'] = service_name

            # Get resource limits from RuntimeOptions or config
            docker_kwargs: dict = {}

            # First apply config-based limits (if any)
            if self.config.sandbox.docker_runtime_kwargs:
                docker_kwargs.update(self.config.sandbox.docker_runtime_kwargs)

            # Then apply RuntimeOptions limits (which take precedence)
            if self.options:
                if self.options.memory_limit:
                    docker_kwargs['mem_limit'] = self.options.memory_limit
                    # remove the unit from the memory limit option and get the number as GB
                    self.log(
                        'info',
                        f'Applying memory limit from RuntimeOptions: {self.options.memory_limit}',
                    )

                if self.options.cpu_limit:
                    requested = float(self.options.cpu_limit)
                    # Convert CPU limit to nano_cpus for Docker Python SDK
                    docker_kwargs['nano_cpus'] = int(requested * 1_000_000_000)
                    self.log(
                        'info',
                        f'Applying CPU limit from RuntimeOptions: {requested} CPUs',
                    )

            # Clamp resource limits to host capacity
            self.clamp_resource_limit_to_host(docker_kwargs)

            self.log('info', f'Applying Docker resource limits: {docker_kwargs}')

            # add env var RUNTIME_MEMORY_MONITOR to container
            self.container = self.docker_client.containers.run(
                self.runtime_container_image,
                command=command,
                # Override the default 'bash' entrypoint because the command is a binary.
                entrypoint=[],
                network='traefik-shared',
                ports=port_mapping,
                working_dir='/kepilot/code/',  # do not change this!
                name=self.container_name,
                detach=True,
                environment=environment,
                volumes=volumes,  # type: ignore
                device_requests=self._get_gpu_device_requests(),
                labels=labels,
                **docker_kwargs,
            )
            self.log('debug', f'Container started. Server url: {self.api_url}')

            # Verify resource limits were applied
            if docker_kwargs and self.container:
                container_info = self.container.attrs
                host_config = container_info.get('HostConfig', {})
                actual_memory = host_config.get('Memory', 0)
                actual_nano_cpus = host_config.get('NanoCpus', 0)
                actual_cpu_quota = host_config.get('CpuQuota', 0)
                actual_cpu_period = host_config.get('CpuPeriod', 0)

                if actual_memory > 0:
                    self.log(
                        'info',
                        f'Container memory limit applied: {actual_memory / (1024**3):.2f}GB',
                    )

                # Check both nano_cpus and cpu_quota/cpu_period methods
                if actual_nano_cpus > 0:
                    cpu_limit = actual_nano_cpus / 1_000_000_000
                    self.log(
                        'info',
                        f'Container CPU limit applied: {cpu_limit:.2f} CPUs (via nano_cpus)',
                    )
                elif actual_cpu_quota > 0 and actual_cpu_period > 0:
                    cpu_limit = actual_cpu_quota / actual_cpu_period
                    self.log(
                        'info',
                        f'Container CPU limit applied: {cpu_limit:.2f} CPUs (via cpu_quota)',
                    )
            self.send_status_message('STATUS$CONTAINER_STARTED')
        except Exception as e:
            self.log(
                'error',
                f'Error: Instance {self.container_name} FAILED to start container!\n',
            )

            analyzed_error = self._analyze_container_failure(self.container_name, e)
            if isinstance(analyzed_error, AgentRuntimeOutOfMemoryError):
                # For OOM errors, don't clean up the container (user might want to inspect it)
                # Just release port locks and raise the OOM error
                self.log(
                    'error', 'Container startup failed due to insufficient memory (OOM)'
                )
                self.send_error_message(
                    'STATUS$ERROR_CONTAINER_OOM', str(analyzed_error)
                )
                raise analyzed_error
            else:
                self.log(
                    'info',
                    'Container startup failed for non-OOM reasons, cleaning up container',
                )
                self.send_error_message(
                    'STATUS$ERROR_CONTAINER_START_FAILED', str(analyzed_error)
                )
                self._cleanup_failed_container(self.container_name)
                self.close()
                raise analyzed_error

    def _attach_to_container(self) -> None:
        self.container = self.docker_client.containers.get(self.container_name)
        if self.container.status == 'exited':
            self.container.start()

        config = self.container.attrs['Config']
        for env_var in config['Env']:
            if env_var.startswith('port='):
                self._host_port = int(env_var.split('port=')[1])
                self._container_port = self._host_port
            elif env_var.startswith('VSCODE_PORT='):
                self._vscode_port = int(env_var.split('VSCODE_PORT=')[1])

        self._app_ports = []
        exposed_ports = config.get('ExposedPorts')
        if exposed_ports:
            for exposed_port in exposed_ports.keys():
                exposed_port = int(exposed_port.split('/tcp')[0])
                if (
                    exposed_port != self._host_port
                    and exposed_port != self._vscode_port
                ):
                    self._app_ports.append(exposed_port)

        self.api_url = f'{self.config.sandbox.local_runtime_url}:{self._container_port}'
        self.log(
            'debug',
            f'attached to container: {self.container_name} {self._container_port} {self.api_url}',
        )

    @tenacity.retry(
        stop=tenacity.stop_after_delay(120) | stop_if_should_exit(),
        retry=tenacity.retry_if_exception(_is_retryablewait_until_alive_error),
        reraise=True,
        wait=tenacity.wait_fixed(2),
    )
    def wait_until_alive(self) -> None:
        # Track attempt number for progress feedback
        self._check_attempt += 1

        # Update progress status every few attempts
        if hasattr(self, '_startup_start_time') and self._startup_start_time:
            elapsed_time = time.time() - self._startup_start_time

            # Show different progress messages based on elapsed time
            if elapsed_time < 5:
                status_msg = 'STATUS$RUNTIME_INIT_10'
            elif elapsed_time < 10:
                status_msg = 'STATUS$RUNTIME_INIT_25'
            elif elapsed_time < 15:
                status_msg = 'STATUS$RUNTIME_INIT_40'
            elif elapsed_time < 20:
                status_msg = 'STATUS$RUNTIME_INIT_60'
            elif elapsed_time < 25:
                status_msg = 'STATUS$RUNTIME_INIT_80'
            else:
                status_msg = 'STATUS$RUNTIME_INIT_90'

            # Update status every 3 attempts to avoid too frequent updates
            if self._check_attempt % 3 == 0:
                self.send_status_message(status_msg)

            # Log progress every 5 attempts
            if self._check_attempt % 5 == 0:
                self.log(
                    'info',
                    f'Still waiting for runtime to be ready... (attempt {self._check_attempt}, {elapsed_time:.1f}s elapsed)',
                )

        try:
            container = self.docker_client.containers.get(self.container_name)
            if container.status == 'exited':
                raise AgentRuntimeDisconnectedError(
                    f'Container {self.container_name} has exited.'
                )
        except docker.errors.NotFound:
            raise AgentRuntimeNotFoundError(
                f'Container {self.container_name} not found.'
            )

        self.check_if_alive()

    def close(self, rm_all_containers: bool | None = None) -> None:
        """Closes the DockerRuntime and associated objects

        Parameters:
        - rm_all_containers (bool): Whether to remove all containers with the 'openhands-sandbox-' prefix
        """
        super().close()
        if self.log_streamer:
            self.log_streamer.close()

        if rm_all_containers is None:
            rm_all_containers = self.config.sandbox.rm_all_containers

        if self.config.sandbox.keep_runtime_alive or self.attach_to_existing:
            return
        close_prefix = (
            CONTAINER_NAME_PREFIX if rm_all_containers else self.container_name
        )
        stop_all_containers(close_prefix)

    def _is_port_in_use_docker(self, port: int) -> bool:
        containers = self.docker_client.containers.list()
        for container in containers:
            container_ports = container.ports
            if str(port) in str(container_ports):
                return True
        return False

    def clamp_resource_limit_to_host(self, docker_kwargs: dict) -> None:
        """Clamp CPU and memory limits in docker_kwargs so they don't exceed host capacity."""
        # CPU clamp
        host_cpus = os.cpu_count() or 1

        # Collect any CPU settings that may be present
        cpu_values: dict[str, float] = {}

        if 'nano_cpus' in docker_kwargs:
            try:
                cpu_values['nano_cpus'] = (
                    float(docker_kwargs['nano_cpus']) / 1_000_000_000
                )
            except (TypeError, ValueError):
                pass

        if 'cpus' in docker_kwargs:
            try:
                cpu_values['cpus'] = float(docker_kwargs['cpus'])
            except (TypeError, ValueError):
                pass

        if 'cpu_count' in docker_kwargs:
            try:
                cpu_values['cpu_count'] = float(docker_kwargs['cpu_count'])
            except (TypeError, ValueError):
                pass

        if 'cpu_quota' in docker_kwargs and 'cpu_period' in docker_kwargs:
            try:
                period = float(docker_kwargs['cpu_period'])
                if period > 0:
                    cpu_values['cpu_quota'] = float(docker_kwargs['cpu_quota']) / period
            except (TypeError, ValueError, ZeroDivisionError):
                pass

        if cpu_values:
            # Use the highest requested CPU value as the effective request.
            requested_cpus = max(cpu_values.values())
            original_requested = requested_cpus

            # Upper bound: can't exceed physical CPUs
            if requested_cpus > host_cpus:
                self.log(
                    'warning',
                    (
                        f'Requested CPU limit {requested_cpus} exceeds host CPUs {host_cpus}, '
                        f'clamping to {host_cpus}.'
                    ),
                )
                requested_cpus = float(host_cpus)

            # Lower bound: avoid absurdly tiny values
            if requested_cpus < 0.25:
                self.log(
                    'warning',
                    (
                        f'Requested CPU limit {original_requested} is too low, '
                        'clamping to 0.25.'
                    ),
                )
                requested_cpus = 0.25

            # Write the clamped value back in the same formats that were present.
            if 'nano_cpus' in cpu_values:
                docker_kwargs['nano_cpus'] = int(requested_cpus * 1_000_000_000)

            if 'cpus' in cpu_values:
                docker_kwargs['cpus'] = requested_cpus

            if 'cpu_count' in cpu_values:
                # cpu_count is integral, but we still respect the clamped float.
                docker_kwargs['cpu_count'] = max(1, int(requested_cpus))

            if 'cpu_quota' in cpu_values and 'cpu_period' in docker_kwargs:
                try:
                    period = float(docker_kwargs['cpu_period']) or 100_000.0
                except (TypeError, ValueError):
                    period = 100_000.0
                docker_kwargs['cpu_quota'] = int(requested_cpus * period)

        # Memory clamp
        if 'mem_limit' in docker_kwargs:
            mem = docker_kwargs['mem_limit']

            if isinstance(mem, str) and mem.lower().endswith('g'):
                try:
                    num_gb = float(mem[:-1])
                except ValueError:
                    num_gb = None

                if num_gb is not None and num_gb > 8:
                    self.log(
                        'warning',
                        f'docker_kwargs mem_limit is {mem}, clamping to 8g for local dev.',
                    )
                    docker_kwargs['mem_limit'] = '8g'

    def _get_gpu_device_requests(self):
        """Get GPU device requests based on user's allocation and sandbox configuration."""
        # Only enable GPU if sandbox allows it
        if not self.config.sandbox.enable_gpu:
            self.log('debug', 'GPU disabled by sandbox configuration')
            return None

        # Check if user has GPU allocation from RuntimeOptions
        gpu_count = None
        if self.options and hasattr(self.options, 'gpu_count'):
            gpu_count = self.options.gpu_count

        if gpu_count is None:
            self.log(
                'warning',
                'No GPU count specified in RuntimeOptions, GPU access disabled',
            )
            return None

        if gpu_count == 0:
            self.log(
                'info', 'User has no GPU allocation (Free Tier), GPU access disabled'
            )
            return None

        if gpu_count > 0:
            self.log('info', f'Allocating {gpu_count} GPU(s) to container')
            return [docker.types.DeviceRequest(capabilities=[['gpu']], count=gpu_count)]

        return None

    def _find_available_port(
        self, port_range: tuple[int, int], max_attempts: int = 5
    ) -> int:
        port = port_range[1]
        for _ in range(max_attempts):
            port = find_available_tcp_port(port_range[0], port_range[1])
            if not self._is_port_in_use_docker(port):
                return port
        # If no port is found after max_attempts, return the last tried port
        return port

    def _analyze_container_failure(
        self, container_name: str, original_error: Exception
    ) -> Exception:
        try:
            container = self.docker_client.containers.get(container_name)
            logs = container.logs(tail=100).decode('utf-8', errors='ignore')

            container.reload()
            exit_code = container.attrs.get('State', {}).get('ExitCode', 0)
            oom_killed = container.attrs.get('State', {}).get('OOMKilled', False)

            self.log(
                'debug',
                f'Container {container_name} exit code: {exit_code}, OOMKilled: {oom_killed}',
            )
            self.log('debug', f'Container logs (last 100 lines):\n{logs}')

            if oom_killed or exit_code == 137:  # 137 is typical OOM exit code
                return AgentRuntimeOutOfMemoryError(
                    f'Container {container_name} failed to start due to insufficient memory (OOM). '
                    f'Exit code: {exit_code}, OOMKilled: {oom_killed}'
                )

            # Check logs for memory-related errors
            oom_indicators = [
                'out of memory',
                'oom',
                'killed by signal 9',
                'memory allocation failed',
                'cannot allocate memory',
                'fatal: out of memory',
            ]

            logs_lower = logs.lower()
            for indicator in oom_indicators:
                if indicator in logs_lower:
                    return AgentRuntimeOutOfMemoryError(
                        f'Container {container_name} failed to start due to insufficient memory. '
                        f'Found memory-related error in logs: "{indicator}"'
                    )

            # For other failures, return generic container start error
            return AgentRuntimeContainerStartError(
                f'Container {container_name} failed to start. Exit code: {exit_code}. '
                f'Check logs for details: {logs[-500:] if logs else "No logs available"}',
                original_error=original_error,
            )

        except docker.errors.NotFound:
            # Container was never created or already removed
            return AgentRuntimeContainerStartError(
                f'Container {container_name} was not created or already removed',
                original_error=original_error,
            )
        except Exception as e:
            # If we can't analyze the failure, return generic error
            self.log('warning', f'Failed to analyze container failure: {e}')
            return AgentRuntimeContainerStartError(
                f'Container {container_name} failed to start and failure analysis failed',
                original_error=original_error,
            )

    def _cleanup_failed_container(self, container_name: str) -> None:
        try:
            container = self.docker_client.containers.get(container_name)
            self.log('info', f'Removing failed container: {container_name}')

            # Stop the container if it's still running
            if container.status in ['running', 'paused']:
                container.stop(timeout=5)

            # Remove the container
            container.remove(force=True)
            self.log(
                'debug', f'Successfully removed failed container: {container_name}'
            )

        except docker.errors.NotFound:
            # Container doesn't exist, nothing to clean up
            self.log(
                'debug', f'Container {container_name} not found, nothing to clean up'
            )
        except Exception as e:
            # Log the error but don't raise it, as this is cleanup
            self.log('warning', f'Failed to clean up container {container_name}: {e}')

    @property
    def vscode_url(self) -> str | None:
        token = super().get_vscode_token()
        if not token:
            return None
        if self.runtime_host == 'localhost':
            # If running locally, use localhost directly
            vscode_url = f'http://localhost:{self._vscode_port}/?tkn={token}&folder={self.config.workspace_mount_path_in_sandbox}'
        else:
            # If running in a different domain, use the domain
            # This is useful for production or staging environments
            # where the runtime is not running on localhost
            # todo: https or http
            vscode_url = f'{self.http_schema}://{self.runtime_host}/?tkn={token}&folder={self.config.workspace_mount_path_in_sandbox}'
        return vscode_url

    @property
    def runtime_host(self) -> str | None:
        """Returns the host for the runtime, used for Traefik routing."""
        oais_domain = os.getenv('OAIS_DOMAIN', 'localhost')
        if oais_domain == 'localhost':
            return 'localhost'
        return self.runtime_name + '.prod-runtime.app.' + oais_domain

    @property
    def http_schema(self) -> str:
        """Returns the HTTP schema for the runtime, used for Traefik routing."""
        # If env is not set, use http, otherwise use https
        return 'http' if os.getenv('OAIS_USE_TLS', 'false') == 'false' else 'https'

    @property
    def runtime_name(self) -> str:
        """Returns the subdomain for the runtime, used for Traefik routing."""
        return f'runtime-{self.container_name[-8:]}'.replace('_', '-').replace('.', '-')

    @property
    def web_hosts(self) -> dict[str, int]:
        hosts: dict[str, int] = {}
        # todo: support production env
        os.environ.get('DOCKER_HOST_ADDR', 'localhost')
        for i, port in enumerate(self._app_ports):
            if self.runtime_host == 'localhost':
                hosts[f'http://localhost:{port}'] = port
            else:
                hosts[f'{self.http_schema}://app-{i + 1}-{self.runtime_host}'] = port

        return hosts

    def pause(self) -> None:
        """Pause the runtime by stopping the container.
        This is different from container.stop() as it ensures environment variables are properly preserved.
        """
        if not self.container:
            raise RuntimeError('Container not initialized')

        # First, ensure all environment variables are properly persisted in .bashrc
        # This is already handled by add_env_vars in base.py

        # Stop the container
        self.container.stop()
        self.log('debug', f'Container {self.container_name} paused')

    def resume(self) -> None:
        """Resume the runtime by starting the container.
        This is different from container.start() as it ensures environment variables are properly restored.
        """
        if not self.container:
            raise RuntimeError('Container not initialized')

        # Start the container
        self.container.start()
        self.log('debug', f'Container {self.container_name} resumed')

        # Wait for the container to be ready
        self.wait_until_alive()

    @classmethod
    async def delete(cls, conversation_id: str, config: OpenHandsConfig) -> None:
        docker_client = cls._init_docker_client()
        try:
            container_name = CONTAINER_NAME_PREFIX + conversation_id
            container = docker_client.containers.get(container_name)
            container.remove(force=True)
        except docker.errors.APIError:
            pass
        except docker.errors.NotFound:
            pass
        finally:
            docker_client.close()

    def get_action_execution_server_startup_command(self) -> list[str]:
        return get_action_execution_server_startup_command(
            server_port=self._container_port,
            plugins=self.plugins,
            app_config=self.config,
            main_module=self.main_module,
        )
